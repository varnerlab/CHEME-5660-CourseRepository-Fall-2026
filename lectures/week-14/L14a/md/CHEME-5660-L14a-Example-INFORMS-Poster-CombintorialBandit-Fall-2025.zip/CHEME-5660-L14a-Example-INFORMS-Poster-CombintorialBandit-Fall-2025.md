# Example: Online Stochastic Bandit Algorithms for Portfolio Rebalancing
In this example, we'll propose a stochastic multi-armed bandit approach to portfolio rebalancing where a bandit algorithm selects which assets to include in the portfolio, and an optimal Utility Maximization (UM) approach is used to determine the optimal weights for the selected assets. Thus, we simultaneously address the asset selection and weight allocation problems in portfolio management.

> __Learning Objectives__
> 
> By the end of this example, you should be able to:
> * __Apply multi-armed bandit algorithms__ to explore different portfolio compositions by balancing exploration of uncertain subsets with exploitation of known high-utility combinations.
> * __Formulate and solve utility maximization problems__ using Cobb-Douglas utility functions to determine optimal asset share counts for a selected portfolio, with the understanding that this has an analytical solution for asset selections.
> * __Integrate bandit selection with utility maximization__ to demonstrate how these two approaches work together to simultaneously address asset selection and weight allocation problems in portfolio management.

This material will be presented at the upcoming [INFORMS Annual Meeting 2025](https://meetings.informs.org/wordpress/annual/) in Atlanta, GA on October 26-29, 2025. Let's get started!
___

## Setup, Data, and Prerequisites
First, we set up the computational environment by including the `Include.jl` file and loading any needed resources.

> __Include:__ The [`include(...)` command](https://docs.julialang.org/en/v1/base/base/#include) evaluates the contents of the input source file, `Include.jl`, in the notebook's global scope. The `Include.jl` file sets paths, loads required external packages, etc. For additional information on functions and types used in this material, see the [Julia programming language documentation](https://docs.julialang.org/en/v1/). 

Let's set up our code environment:


```julia
include(joinpath(@__DIR__, "Include-informs.jl")); # include the Include.jl file
```

For additional information on functions and types used in this material, see the [Julia programming language documentation](https://docs.julialang.org/en/v1/) and the [VLQuantitativeFinancePackage.jl documentation](https://github.com/varnerlab/VLQuantitativeFinancePackage.jl). 

### Data
We gathered daily open-high-low-close (OHLC) data for each firm in the [S&P 500](https://en.wikipedia.org/wiki/S%26P_500) from `01-03-2025` until `10-17-2025`, along with data for several exchange-traded funds and volatility products during that time period.

Let's load the `original_dataset::DataFrame` by calling [the `MyTestingMarketDataSet()` function](https://varnerlab.github.io/VLQuantitativeFinancePackage.jl/dev/data/#VLQuantitativeFinancePackage.MyTestingMarketDataSet).


```julia
original_out_of_sample_dataset = MyTestingMarketDataSet() |> x-> x["dataset"] # load the original dataset (testing)
```




    Dict{String, DataFrame} with 483 entries:
      "NI"   => [1m220×8 DataFrame[0m[0m…
      "EMR"  => [1m220×8 DataFrame[0m[0m…
      "CTAS" => [1m220×8 DataFrame[0m[0m…
      "HSIC" => [1m220×8 DataFrame[0m[0m…
      "KIM"  => [1m220×8 DataFrame[0m[0m…
      "PLD"  => [1m220×8 DataFrame[0m[0m…
      "IEX"  => [1m220×8 DataFrame[0m[0m…
      "BAC"  => [1m220×8 DataFrame[0m[0m…
      "CBOE" => [1m220×8 DataFrame[0m[0m…
      "EXR"  => [1m220×8 DataFrame[0m[0m…
      "NCLH" => [1m220×8 DataFrame[0m[0m…
      "CVS"  => [1m220×8 DataFrame[0m[0m…
      "DRI"  => [1m220×8 DataFrame[0m[0m…
      "DTE"  => [1m220×8 DataFrame[0m[0m…
      "ZION" => [1m220×8 DataFrame[0m[0m…
      "AVY"  => [1m220×8 DataFrame[0m[0m…
      "EW"   => [1m220×8 DataFrame[0m[0m…
      "EA"   => [1m220×8 DataFrame[0m[0m…
      "NWSA" => [1m220×8 DataFrame[0m[0m…
      "BBWI" => [1m220×8 DataFrame[0m[0m…
      "CAG"  => [1m220×8 DataFrame[0m[0m…
      "GPC"  => [1m220×8 DataFrame[0m[0m…
      "FCX"  => [1m220×8 DataFrame[0m[0m…
      "GILD" => [1m220×8 DataFrame[0m[0m…
      "INFO" => [1m220×8 DataFrame[0m[0m…
      ⋮      => ⋮



Not all tickers in our dataset have the maximum number of trading days for various reasons, such as acquisition or delisting events. Let's collect only those tickers with the maximum number of trading days.

First, let's compute the number of records for a firm that we know has the maximum value, e.g., `AAPL`, and save that value in the `maximum_number_trading_out_of_sample_days::Int64` variable:


```julia
maximum_number_trading_out_of_sample_days = original_out_of_sample_dataset["AAPL"] |> nrow; # maximum number of trading days in our dataset 
```

Now, let's iterate through our data and collect only tickers with `maximum_number_trading_out_of_sample_days` records. We'll save that data in the `dataset::Dict{String,DataFrame}` variable:


```julia
dataset = let

    # initialize -
    dataset = Dict{String, DataFrame}();

    # iterate through the dictionary; we can't guarantee a particular order
    for (ticker, data) ∈ original_out_of_sample_dataset  # we get each (K, V) pair!
        if (nrow(data) == maximum_number_trading_out_of_sample_days) # check if ticker has maximum trading days
            dataset[ticker] = data;
        end
    end
    dataset; # return
end;
```

Let's get a list of the firms in our cleaned dataset and sort them alphabetically. We'll store the sorted firm ticker symbols in the `list_of_tickers_price_data::Array{String,1}` variable:


```julia
list_of_tickers_price_data = keys(dataset) |> collect |> sort;
```

Finally, let's load the single index model parameters that we computed in the previous example. We'll store this data in the `sim_model_parameters::Dict{String,NamedTuple}` variable. In addition, we return a few other useful variables, such as the historical market growth rate, the mean and variance of the market growth, etc.


```julia
sim_model_parameters,Gₘ,Ḡₘ, Varₘ = let

    # initialize -
    path_to_sim_model_parameters = joinpath(_PATH_TO_DATA,"SIMs-SPY-SP500-01-03-14-to-12-31-24.jld2");
    sim_model_parameters = JLD2.load(path_to_sim_model_parameters);
    parameters = sim_model_parameters["data"]; # return

    Gₘ = sim_model_parameters["Gₘ"]; # Get the past market growth rate 
    Ḡₘ = sim_model_parameters["Ḡₘ"]; # mean of market growth rates
    Varₘ = sim_model_parameters["Varₘ"]; # variance of market growth

    # return -
    parameters,  Gₘ , Ḡₘ, Varₘ;
end;
```

Now let's get a list of all tickers for which we have single index model parameters:


```julia
tickers_that_we_sim_sim_data_for = keys(sim_model_parameters) |> collect |> sort;
```

We need to use only the tickers for which we have both price data and SIM parameters. We'll compute [the intersection of the two lists](https://docs.julialang.org/en/v1/base/collections/#Base.intersect) and store the result in the `list_of_tickers::Vector{String}` variable:


```julia
list_of_tickers = intersect(tickers_that_we_sim_sim_data_for, list_of_tickers_price_data);
```

Finally, we need to compute the projection matrix `X̄::Array{Float64,2}` = $(\mathbf{X}^{\top}\mathbf{X})^{-1}\mathbf{X}^{\top}$ (which will be handy for later) where $\mathbf{X}$ is the market factor matrix:


```julia
X̄ = let
    
    
    Rₘ = Gₘ; # get Gₘ from the sim model parameters
    max_length = length(Rₘ);
    X = [ones(max_length) Rₘ];

    a = inv(transpose(X)*X)*transpose(X)
    a;
end
```




    2×2766 Matrix{Float64}:
      0.000367293  0.000355057  0.0003607   …   0.000382956   0.000370094
     -5.4289e-5    6.10402e-5   7.85216e-6     -0.000201909  -8.06852e-5



### Constants
Finally, let's set some constants we'll use later in this notebook. The comments describe the constants, their units, and permissible values:


```julia
Δt = (1/252); # time-step
total_number_of_tickers = length(list_of_tickers); # how many tickers do we have in my dataset?
investment_budget = 10000.0; # initial budget of the agent
risk_free_rate = 0.0418; # risk free rate
μₘ =  Ḡₘ; # expected growth for SPY
B = investment_budget; # TODO: Budget for portfolio. We can change this later if we want
ϵ = 0.001; # hyperparameter: minimum share number for each asset
α::Float64 = 0.80; # learning rate for moving average calculation
Tₘ::Int64 = 10; # how many days for market time
λ::Float64 = 0.0; # risk scale
number_of_days_to_simulate = maximum_number_trading_out_of_sample_days; # how many days to simulate
```

### Implementation
Next, build the `world(...)` function. The `world(...)` function takes the action vector `a::Vector{Int64}` where the elements of `a::Vector{Int64}` are binary variables indicating whether to select an asset (`1`) or not (`0`). The length of the action vector `a` is $|\dim\mathcal{P}|$, i.e., the total number of assets available for selection.

> __What's in the action vector?__ The action vector `a::Vector{Int64}` is a binary vector of length $|\dim\mathcal{P}|$ where each element indicates whether to include (`1`) or exclude (`0`) the corresponding asset from the portfolio. For example, if we have 5 assets and the action vector is `[1, 0, 1, 0, 1]`, it means we are selecting assets 1, 3, and 5 for inclusion in the portfolio while excluding assets 2 and 4.

The `world(...)` function returns the portfolio Utility, the optimal number of shares for each selected asset, the fill price for each selected asset, and the user preference values $\gamma_i$ for each selected asset. 


```julia
function world(t::Int, a::Vector{Int64}, context::MyDynamicBanditPortfolioAllocationContextModel)

    # initialize -
    total_number_of_assets = context.number_of_assets; # total number of assets that we *could* purchase
    bounds = context.bounds; # bounds for how much we purchase
    B = context.B; # budget for this period
    mylocaltickers = context.tickers; # tickers for the assets in this portfolio
    localdataset = context.dataset; # dataset for the assets in this portfolio
    singleindexmodels = context.singleindexmodels; # single index models for the assets in this portfolio
    X̄ = context.X̄;
    number_of_samples_to_draw = context.number_of_samples_to_draw;

    # what is the min share purchase?
    min_share_purchase = bounds[1,1];

    # Compute the fill price vector -
    pₒ = zeros(total_number_of_assets);
    for i ∈ eachindex(mylocaltickers)
        ticker = mylocaltickers[i];
        O = localdataset[ticker][t,:open];
        H = localdataset[ticker][t,:high];
        L = localdataset[ticker][t,:low];
        f = rand();
        pₒ[i] = f*H + (1-f)*L; # randomness in the fill price
        # pₒ[i] = O; # use open price as fill price
    end

    # next, compute the preference parameters γ -
    γ = zeros(total_number_of_assets);
    for i ∈ eachindex(mylocaltickers)
        ticker = mylocaltickers[i];

        # get the model -
        simmodel = singleindexmodels[ticker];
        α = simmodel.alpha;
        β = simmodel.beta;
        CI_alpha_L = simmodel.alpha_95_CI_lower;
        CI_alpha_U = simmodel.alpha_95_CI_upper;
        CI_beta_L = simmodel.beta_95_CI_lower;
        CI_beta_U = simmodel.beta_95_CI_upper;

        # compute random parameters -
        # αᵢ = rand(Uniform(CI_alpha_L, CI_alpha_U)); # sample from the confidence interval
        # βᵢ = rand(Uniform(CI_beta_L, CI_beta_U));
        αᵢ = α; # use the mean value
        βᵢ = β; # use the mean value

        # Compute the alpha and beta values -
        R = αᵢ + βᵢ*μₘ; # draw random value from the error distribution -
        γ[i] = tanh_fast(R/(βᵢ^λ));
    end

    # Compute the optimal share count -
    n = zeros(total_number_of_assets); # initialize space for optimal solution
    S = findall(aᵢ -> aᵢ == 1, a); # Which assets does our bandit want us to buy?
    number_of_selected_arms = length(S);

    # In the set of assets to explore, do we have any non-preferred assets?
    negative_gamma_flag = any(γ[S] .< 0);
    if (negative_gamma_flag == false)
        
        # easy case: all of my potential assets are preferred.
        γ̄ = sum(γ[S]);
        B̄ = B;
        for s ∈ S
            n[s] = (γ[s]/γ̄)*(B̄/pₒ[s]);
        end
    else

        # hard case: some assets are *not* preferred. 
        
        # Prep work for non-preferred case
        # First: the non-preferred assets are min_share_purchase -
        # Second: Compute the adjusted budget
        # Third: Compute γ̄
        B̄ = B;
        γ̄ = 0.0;
        for s ∈ S
            if (γ[s] < 0.0)
                B̄ += -min_share_purchase*pₒ[s];
                n[s] = min_share_purchase;
            else
                γ̄ += γ[s];
            end
        end

        # compute the optimal preferred assets -
        for s ∈ S
            if (γ[s] ≥ 0.0)
                n[s] = (γ[s]/γ̄)*(B̄/pₒ[s]);
            end
        end
    end

    # premultiplier -
    κ = negative_gamma_flag == true ? -1.0 : 1.0;
    
    # Compute the optimal utility -
    U = κ;
    for s ∈ S
        U *= (n[s]^γ[s])
    end
    
    # Return the utility and the share count that we allocated
    return U, n, pₒ, γ
end;
```

___

## Task 1: Maximum Utility Portfolio Optimization Problem
In this task, we'll solve the maximum utility portfolio optimization problem for a given set that we select such that we have the maximum __investor satisfaction__, i.e., maximum Utility. Let's start by specifying the possible tickers that our online stochastic bandit algorithm can choose from. We'll store these tickers in the `my_test_portfolio_tickers::Array{String,1}` variable:


```julia
my_test_portfolio_tickers = ["AAPL", "MSFT", "INTC", "MU", "AMD", "GS", "BAC", "WFC", "C", "F", "GM", 
    "JNJ", "PG", "UPS", "COST", "TGT", "WMT", "MRK", "PFE", "ADBE"]; # tickers selected for portfolio
```


```julia
length(my_test_portfolio_tickers) # how many tickers do we have?
```




    20



Given this set of possible tickers, let's compute the expected growth rate vector and the covariance matrix for these assets using their single index model parameters. We don't use these values in the bandit calculation, but we will need them to compute the Sharpe ratio of the resulting portfolio later. 

We'll store these in the `μ̂_sim::Array{Float64,1}` and `Σ̂_sim::Array{Float64,2}` variables:


```julia
μ̂_sim, Σ̂_sim = let

    # initialize -
    N = length(my_test_portfolio_tickers); # number of assets in portfolio
    μ_sim = Array{Float64,1}(); # drift vector
    Σ̂_sim = Array{Float64,2}(undef, N, N); # covariance matrix for *our* portfolio
    
    # Ḡₘ = mean(Gₘ); # mean of market factor # TODO: already loaded above, we'll use 2014 - 2024 data value
    σ²ₘ = Varₘ; # variance of market factor # TODO: already loaded above, we'll use 2014 - 2024 data value

    # compute the expected growth rate (return) for each of our tickers -
    for i ∈ eachindex(my_test_portfolio_tickers)
        ticker = my_test_portfolio_tickers[i];
        data = sim_model_parameters[ticker]; # get the data for this ticker
        αᵢ = data.alpha; # get alpha
        βᵢ = data.beta; # get beta
        Ḡᵢ = αᵢ + βᵢ* Ḡₘ; # compute the growth rate for this ticker
        push!(μ_sim, Ḡᵢ); # append growth rate value to μ_sim
    end

    # compute the covariance matrix using the single index model -
    for i ∈ eachindex(my_test_portfolio_tickers)

        ticker_i = my_test_portfolio_tickers[i];
        data_i = sim_model_parameters[ticker_i]; # get the data for ticker i
        βᵢ = data_i.beta; # get beta for ticker i
        σ²_εᵢ = (Δt)*data_i.training_variance; # residual variance for ticker i

        for j ∈ eachindex(my_test_portfolio_tickers)
            
            ticker_j = my_test_portfolio_tickers[j];
            data_j = sim_model_parameters[ticker_j]; # get the data for ticker j
            βⱼ = data_j.beta; # get beta for ticker j
            σ²_εⱼ = (Δt)*data_j.training_variance; # residual variance for ticker j
            
            if i == j
                Σ̂_sim[i,j] = βᵢ*βⱼ*σ²ₘ + σ²_εᵢ; # diagonal elements
            else
                Σ̂_sim[i,j] = βᵢ*βⱼ*σ²ₘ; # off-diagonal elements
            end
        end
    end

    (μ_sim, Σ̂_sim*Δt); # return
end;
```

To implement our bandit strategy, we first build the epsilon-greedy dynamic noise algorithm model. This model holds some information about the problem, e.g., the number of assets available for selection, and the learning rate $\alpha$. We store this model in the `dynamic_algorithm_model::MyEpsilonGreedyDynamicNoiseAlgorithmModel` variable:


```julia
dynamic_algorithm_model = let

    # initialize -
    algorithm = nothing; # Initialize the algorithm variable to nothing; this variable will be used to store the algorithm model
    K = length(my_test_portfolio_tickers); # TODO: Number of tickers to consider
    
    # TODO: Build an algorithm model by uncommenting the code block below
    algorithm = build(MyEpsilonGreedyDynamicNoiseAlgorithmModel, (
        K = K, # arms 
        α = α, # learning rate
    ));

    # return the algorithm -
    algorithm;
end;
```

Next, we set bounds on the number of shares that we can hold for each asset in our portfolio. The lower bound `ϵ::Float64` represents the __minimum number of shares__ required for portfolio inclusion, while the upper bound is unbounded to allow for flexible allocation. 

> __Why a non-zero lower bound?__ Setting a non-zero lower bound `ϵ::Float64` follows from the form of the Cobb-Douglas utility function, if any asset has zero allocation, the overall utility becomes zero which does not reflect realistic investor behavior. Thus, we set a small positive value for `ϵ::Float64` to ensure that each selected asset contributes positively to the portfolio's utility.

We'll store this in the `static_share_bounds::Array{Float64,2}` variable:


```julia
static_share_bounds = let

    # initialize -
    K = length(my_test_portfolio_tickers); # TODO: Number of tickers to consider
    bounds = Array{Float64,2}(undef, K, 2);
    
    # build my bounds array -
    for i ∈ eachindex(my_test_portfolio_tickers)
        bounds[i,1] = ϵ; # min shares that we can hold of this asset
        bounds[i,2] = Inf; # max number of shares, Inf says this is unbounded
    end
    bounds;
end;
```

Now we build the context model that encapsulates all the data and parameters needed for the bandit algorithm to make portfolio decisions. The context includes the market data, single index model parameters, ticker symbols, budget constraints, and bounds on share purchases. We'll store this in the `dynamic_context_model::MyDynamicBanditPortfolioAllocationContextModel` variable:


```julia
dynamic_context_model = let

    # initialize -
    K = length(my_test_portfolio_tickers); # TODO: Number of tickers to consider
    nₒ = ones(K); # initial guess, assume 1 x share for each
    path_to_save = joinpath(_PATH_TO_DATA, "IMFORMS-InitialGuess-N20.jld2");

    IV = nothing; # initial value array -
    if (isfile(path_to_save) == true)
        data = JLD2.load(path_to_save);
        IV = data["IC"];
    else
        IV = zeros(2^K); # default initial guess
    end

    # build -
    contextmodel = build(MyDynamicBanditPortfolioAllocationContextModel, (
        dataset = dataset,
        singleindexmodels = sim_model_parameters,
        tickers = my_test_portfolio_tickers,
        nₒ = nₒ,
        B = B,
        bounds = static_share_bounds,
        X̄ = X̄,
        R̄ₘ = Ḡₘ,
        number_of_samples_to_draw = size(X̄,2),
        μₒ = IV # initially we have *no* idea which arm is best
    ));

    contextmodel;
end;
```

Finally, we test our approach by solving the utility maximization problem for the case where we select all available assets (by setting the action vector `a::Vector{Int64}` to all ones). This gives us a baseline utility `U::Float64` we could achieve with our full portfolio. 

> __Expectation:__ If this doesn't blow up, then it will return a finite utility value, optimal share counts, fill prices, and preference parameters for each asset in the portfolio. Then we can move on to implementing the bandit algorithm to select subsets of assets dynamically.

So what do we see?


```julia
(U, n, pₒ, γ) = let
   
    # call my world function to test -
    K = length(my_test_portfolio_tickers); # TODO: Number of tickers to consider
    t = 1; # what time period are we in?

    # call the world function directly -
    U, n, pₒ, γ = world(t, ones(Int64,K), dynamic_context_model);
end;
```

__Preferred versus Non-Preferred Assets:__ The `γ::Array{Float64,1}` vector computed above indicates whether an asset is preferred or non-preferred. If $\gamma_i \geq 0$, then the asset is preferred; otherwise, it is non-preferred. Let's look at what assets are preferred versus non-preferred:


```julia
let

    # initialize -
    df = DataFrame();

    for i ∈ eachindex(my_test_portfolio_tickers)
        ticker = my_test_portfolio_tickers[i];

        # get the model -
        row_df = (
            ticker = ticker,
            γᵢ = γ[i],
            preferred = γ[i] >= 0 ? "Yes" : "No",

        );
        push!(df, row_df);
    end

    # make a table -
     pretty_table(df, backend = :text, fit_table_in_display_vertically = false, fit_table_in_display_horizontally = false,
         table_format = TextTableFormat(borders = text_table_borders__compact)
    );
end
```

     -------- ------------ -----------
     [1m ticker [0m [1m         γᵢ [0m [1m preferred [0m
     [90m String [0m [90m    Float64 [0m [90m    String [0m
     -------- ------------ -----------
        AAPL     0.228685         Yes
        MSFT     0.218571         Yes
        INTC   -0.0227793          No
          MU     0.125969         Yes
         AMD     0.302247         Yes
          GS     0.106039         Yes
         BAC    0.0894799         Yes
         WFC     0.039957         Yes
           C    0.0257888         Yes
           F   -0.0406376          No
          GM    0.0268428         Yes
         JNJ    0.0410149         Yes
          PG    0.0666208         Yes
         UPS    0.0176955         Yes
        COST     0.184949         Yes
         TGT     0.068546         Yes
         WMT     0.112145         Yes
         MRK    0.0627781         Yes
         PFE   -0.0131007          No
        ADBE     0.181536         Yes
     -------- ------------ -----------


___

## Task 2: Solve the Online Bandit Portfolio Optimization Problem
In this task, we use the epsilon-greedy bandit algorithm to explore different portfolio combinations and learn which asset subsets maximize investor utility. 

The algorithm iteratively selects actions (portfolio compositions), observes the resulting utility, and updates its beliefs about the reward distribution. The results are stored in the return variables `R::Array{Float64,2}`, `μ::Array{Float64,1}`, `S::Array{Float64,2}`, `P::Array{Float64,2}`, and `G::Array{Float64,2}`. 

Let's run the algorithm for 2500 iterations:


```julia
R, μ, S, P, G = my_bandit_solve(dynamic_algorithm_model, T = 2500, world = world, context = dynamic_context_model); # check the world function
```


```julia
let
    path_to_save = joinpath(_PATH_TO_DATA, "IMFORMS-InitialGuess-N20.jld2");
    if (isfile(path_to_save) == false)
        save(path_to_save, Dict("IC" => μ)) # if we don't have the array saved, save it
    end
end
```


```julia
S # share counts over for each trial
```




    2500×20 Matrix{Float64}:
      4.95283  2.72444  0.001   7.37488  …   6.50386   3.3277   0.001  2.23248
      6.70815  3.69831  0.001   0.0          8.79718   4.49486  0.001  3.01839
      0.0      0.0      0.0     0.0          0.0       7.79613  0.001  0.0
      8.1652   0.0      0.001   0.0          0.0       0.0      0.0    3.66942
      0.0      3.84246  0.001  10.3491       9.17066   0.0      0.001  0.0
      9.14127  5.04926  0.001   0.0      …  12.1057    0.0      0.001  4.14442
      0.0      3.78604  0.001  10.4391       8.98662   4.59333  0.001  0.0
      8.85863  0.0      0.001  13.1979      11.7407    5.95764  0.001  0.0
      0.0      6.22373  0.0     0.0          0.0       0.0      0.0    5.04153
     26.374    0.0      0.001   0.0          0.0      17.7151   0.0    0.0
      0.0      0.0      0.001  15.16     …   0.0       0.0      0.001  0.0
      0.0      0.0      0.001  12.3154       0.0       5.43799  0.001  3.62988
      0.0      7.61593  0.0    20.5524       0.0       0.0      0.0    0.0
      ⋮                                  ⋱                             
      6.05908  3.34177  0.0     9.05321      7.97599   4.08932  0.0    2.75032
      6.06767  3.35549  0.0     9.04292      7.93318   4.07641  0.0    2.75118
      6.05522  3.35506  0.0     9.03765  …   7.96437   4.08818  0.0    2.72412
      6.06271  3.36029  0.0     9.24288      7.99661   4.06507  0.0    2.71609
      6.08216  3.33458  0.0     9.03749      7.99031   4.10143  0.0    2.73639
      0.0      7.59799  0.0    20.716        0.0       0.0      0.001  0.0
      6.09649  3.33623  0.0     9.21107      7.93078   4.10386  0.0    2.74713
      6.09411  3.35236  0.0     9.22041  …   7.99365   4.07324  0.0    2.72067
      6.05986  3.36246  0.0     9.15318      8.02369   4.08888  0.0    2.73551
      6.05666  3.3616   0.0     9.14268      7.94444   4.07451  0.0    2.70516
      0.0      5.23299  0.001  14.5626       0.0       0.0      0.0    4.28475
      6.08785  3.359    0.0     9.17383      7.96787   4.08191  0.0    2.72254



We can sort the possible portfolio compositions by the estimated average utility `μ::Array{Float64,1}` to see which portfolios the bandit algorithm thinks are best:


```julia
sorted_reward_index_array = sortperm(μ, rev=true) # sort the index of the rewards
```




    1048576-element Vector{Int64}:
      759259
      625145
      615643
      735321
      107737
      695771
      154907
      669849
      696531
      546163
      246202
      652792
       82387
           ⋮
      356447
      731997
      862877
      482005
      861723
      329687
      620127
      465627
      102013
     1032926
      897661
      498271



#### What's in the best Bandit portfolio?  
Let's build a table that shows the optimal Bandit portfolio composition identified by the bandit algorithm after 250 periods of exploration. 

The utility value `U::Float64` indicates the investor satisfaction level for this portfolio, while the weights `wᵢ::Float64` show the proportion of budget allocated to each asset. Notice that the bandit algorithm may have selected a portfolio subset (where some `nᵢ::Float64` values are near zero) rather than including all assets, demonstrating how the algorithm balances portfolio complexity with investor utility.


```julia
let

    # initialize -
    df = DataFrame();
    CS = 0;
    t = 1;
    K = length(my_test_portfolio_tickers); # TODO: Number of tickers to consider
    context = dynamic_context_model;
    total_number_of_assets = context.number_of_assets; # total number of assets that we *could* purchase
    bounds = context.bounds; # bounds for how much we purchase
    B = context.B; # budget for this period
    mylocaltickers = context.tickers; # tickers for the assets in this portfolio
    localdataset = context.dataset; # dataset for the assets in this portfolio
    singleindexmodels = context.singleindexmodels; # single index models for the assets in this portfolio
    N = 2^K; # number of possible portfolios

    # compute the best portfolio -
    j = sorted_reward_index_array[1]; # get a portfolio index 
    a = digits(j, base=2, pad=K); # generate a binary representation of the number, with K digits  
    if (j == N)
        a = digits(j - 1, base=2, pad=K); # generate a binary representation of the number, with K digits  
    end

    # call world -
    U, n, pₒ, γ = world(t, a, dynamic_context_model);

    @show U,j

    for i ∈ 1:K

        CS += n[i]*pₒ[i];
        wᵢ = (n[i]*pₒ[i]/B);

        row_df = (
            ticker = my_test_portfolio_tickers[i],
            Sᵢ = pₒ[i],
            γᵢ = γ[i],
            nᵢ = n[i],
            wᵢ = wᵢ,
            UC = n[i]*pₒ[i],
            CS = CS,
        );
        push!(df, row_df);
    end

     pretty_table(df, backend = :text, fit_table_in_display_vertically = false, fit_table_in_display_horizontally = false,
         table_format = TextTableFormat(borders = text_table_borders__compact)
    );
end
```

    (U, j) = (15.910553284390556, 759259)
     -------- --------- ------------ --------- ----------- --------- ---------
     [1m ticker [0m [1m      Sᵢ [0m [1m         γᵢ [0m [1m      nᵢ [0m [1m        wᵢ [0m [1m      UC [0m [1m      CS [0m
     [90m String [0m [90m Float64 [0m [90m    Float64 [0m [90m Float64 [0m [90m   Float64 [0m [90m Float64 [0m [90m Float64 [0m
     -------- --------- ------------ --------- ----------- --------- ---------
        AAPL   241.965     0.228685   6.10079    0.147618   1476.18   1476.18
        MSFT   422.758     0.218571   3.33736    0.141089   1410.89   2887.07
        INTC   20.6059   -0.0227793       0.0         0.0       0.0   2887.07
          MU   90.1644     0.125969   9.01845   0.0813143   813.143   3700.22
         AMD   125.397     0.302247   15.5588    0.195103   1951.03   5651.24
          GS   576.244     0.106039       0.0         0.0       0.0   5651.24
         BAC   44.8276    0.0894799   12.8849   0.0577601   577.601   6228.84
         WFC   71.0856     0.039957   3.62838   0.0257926   257.926   6486.77
           C   70.4111    0.0257888   2.36424   0.0166469   166.469   6653.24
           F   9.60499   -0.0406376       0.0         0.0       0.0   6653.24
          GM   51.7198    0.0268428   3.35022   0.0173273   173.273   6826.51
         JNJ   144.316    0.0410149       0.0         0.0       0.0   6826.51
          PG   165.926    0.0666208   2.59177   0.0430043   430.043   7256.55
         UPS   123.787    0.0176955       0.0         0.0       0.0   7256.55
        COST   916.498     0.184949       0.0         0.0       0.0   7256.55
         TGT   135.752     0.068546    3.2594    0.044247    442.47   7699.02
         WMT   90.1738     0.112145   8.02791   0.0723907   723.907   8422.93
         MRK   98.8145    0.0627781     4.101   0.0405238   405.238   8828.17
         PFE    26.654   -0.0131007       0.0         0.0       0.0   8828.17
        ADBE   430.139     0.181536   2.72431    0.117183   1171.83   10000.0
     -------- --------- ------------ --------- ----------- --------- ---------


___

### Maximium Sharpe Ratio Portfolio
For comparison, we'll compute the maximum Sharpe ratio portfolio using the expected returns and covariance matrix derived from the single index model parameters. This will serve as a benchmark to compare against the portfolios generated by our bandit algorithm.

To solve the maximum Sharpe ratio problem, we reformulate it as a Second Order Cone Program (SOCP). We need to specify a lower bound for an auxiliary variable $\tau$ (where $\text{SR}(w)\ge \tau$), and build an optimization problem model.

We'll compute the maximum Sharpe ratio portfolio by constructing an optimization problem. We need to build a `MySharpeRatioPortfolioChoiceProblem` object to hold the parameters and bounds for the portfolio optimization problem. We'll store this in the `model::MySharpeRatioPortfolioChoiceProblem` variable:


```julia
model = let

    # initialize - 
    my_list_of_tickers = my_test_portfolio_tickers;
    N = length(my_list_of_tickers); # number of assets in portfolio
    α = zeros(N);
    β = zeros(N);

    # grab alphas and betas for our tickers -
    for i ∈ eachindex(my_list_of_tickers)
        ticker = my_list_of_tickers[i];
        data = sim_model_parameters[ticker]; # get the data for this ticker
        α[i] = data.alpha; # get alpha
        β[i] = data.beta; # get beta
    end

    # build the model
    model = VLQuantitativeFinancePackage.build(MySharpeRatioPortfolioChoiceProblem, (
        Σ = Σ̂_sim,
        risk_free_rate = risk_free_rate,
        gₘ = Ḡₘ,
        α = α,
        β = β,
        τ = 1.0, # placeholder, will be set later
    ));

    model; # return -
end;
```

 We compute the (initial value) of the lower bound $L$ by finding the maximum ratio of excess growth to standard deviation for __each individual asset__:
$$
L = \max_i \left\{\frac{\alpha_i + \beta_i \mathbb{E}[g_M] - r_f}{\sqrt{\Sigma_{ii}}} \right\}\quad\forall{i}\in\mathcal{P}
$$
where $\alpha_i$ is the asset's alpha, $\beta_i$ is the asset's beta, $\mathbb{E}[g_M]$ is the expected market return, $r_f$ is the risk-free rate, and $\Sigma_{ii}$ is the asset's variance.
This bound is stored in the `L::Float64` variable. The parameter $\tau$ must be at least as large as this lower bound for the SOCP to have an optimal solution with a well-defined Sharpe ratio.


```julia
L = let

    # initialize -
    α = model.α
    β = model.β
    rfr = model.risk_free_rate
    gₘ = model.gₘ
    Σ = model.Σ
    d = length(α)
    c = α .+ β .* gₘ .- rfr .* ones(d); # vector c

    tau_lower_bound_array = Array{Float64,1}();
    for i ∈ 1:d
        value = c[i]/sqrt(Σ[i,i]);
        push!(tau_lower_bound_array, value);
    end

    L = max(0, maximum(tau_lower_bound_array) ); # return
end
```




    0.8369487745462407



Now we solve the maximum Sharpe ratio portfolio problem using the [solve(...) method](https://varnerlab.github.io/VLQuantitativeFinancePackage.jl/dev/portfolio/#VLQuantitativeFinancePackage.solve-Tuple{MySharpeRatioPortfolioChoiceProblem}). The solution is stored in the `sharpe_solution::NamedTuple` variable, which contains the risk value, reward value, allocation weights, and the Sharpe ratio for the optimal portfolio. 

> __Solver note:__ The [solve(...) method](https://varnerlab.github.io/VLQuantitativeFinancePackage.jl/dev/portfolio/#VLQuantitativeFinancePackage.solve-Tuple{MySharpeRatioPortfolioChoiceProblem}) uses the [JuMP.jl package](https://jump.dev/JuMP.jl/stable/) to formulate and solve the optimization problem. JuMP provides a high-level interface for defining optimization problems and supports various solvers. In this case, we use the [`COSMO.jl` solver from the University of Oxford](https://oxfordcontrol.github.io/COSMO.jl/stable/). 

In the code blow below, we compute the optimal Sharpe ratio portfolio by iteratively increasing the lower bound $L$ until until we no longer have an optimal solution, i.e., until our problem is no longer feasible.


```julia
sharpe_solution = let
   
    # initialize -
    solution = nothing;
    Lᵢ = L; # store initial lower bound value
    should_stop_loop = false; # we'll keep iterating until we are no longer optimal

    while should_stop_loop == false
         
        # solve the problem with τ = L (the computed lower bound)
        model.τ = Lᵢ; # set the lower bound on the desired Sharpe ratio for this iteration
        solution_dictionary = VLQuantitativeFinancePackage.solve(model) # solve for this Lᵢ
        status_flag = solution_dictionary["status"]; # get the status flag
        
        if (status_flag == MathOptInterface.OPTIMAL) # if optimal solution found, grab the results
            risk_value = solution_dictionary["denominator"]; # risk value (denominator of Sharpe ratio)
            reward_value = solution_dictionary["numerator"]; # reward value (numerator of Sharpe ratio)
            allocation = solution_dictionary["argmax"]; # allocation weights
            sharpe_ratio = solution_dictionary["sharpe_ratio"]; # computed Sharpe ratio
        
            solution = (risk = risk_value, reward = reward_value, w = allocation, 
                sharpe_ratio = sharpe_ratio, status = status_flag);

            # update the Sharpe ratio lower bound -
            Lᵢ += 0.001; # increment lower bound and go around again
        else
            should_stop_loop = true; # Bam! We blew up. Exit the loop.
        end
    end

    solution; # return
end;
```

    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 623.65ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-2.8301e-01	5.9955e-01	3.1560e-01	1.0000e-01
    25	-2.2880e-01	4.4356e-03	3.1793e-03	1.0000e-01
    50	-2.2125e-01	2.0074e-08	3.5673e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2212
    Runtime: 1.675s (1675.31ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.19ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-2.8336e-01	5.9955e-01	3.1558e-01	1.0000e-01
    25	-2.2902e-01	4.5611e-03	3.2047e-03	1.0000e-01
    50	-2.2110e-01	3.0808e-08	4.4300e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2211
    Runtime: 0.001s (1.12ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.1ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-2.8371e-01	5.9955e-01	3.1557e-01	1.0000e-01
    25	-2.2932e-01	4.7254e-03	3.2263e-03	1.0000e-01
    50	-2.2096e-01	2.9154e-08	3.4716e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.221
    Runtime: 0.001s (0.73ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-2.8406e-01	5.9955e-01	3.1555e-01	1.0000e-01
    25	-2.2967e-01	4.9294e-03	3.2418e-03	1.0000e-01
    50	-2.2081e-01	2.7520e-08	2.6993e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2208
    Runtime: 0.001s (0.71ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.1ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-2.8441e-01	5.9955e-01	3.1554e-01	1.0000e-01
    25	-2.3010e-01	5.1722e-03	3.2489e-03	1.0000e-01
    50	-2.2067e-01	2.7102e-08	1.9983e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2207
    Runtime: 0.001s (0.76ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.11ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-2.8476e-01	5.9955e-01	3.1553e-01	1.0000e-01
    25	-2.3058e-01	5.4504e-03	3.2463e-03	1.0000e-01
    50	-2.2052e-01	2.8443e-08	1.2619e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2205
    Runtime: 0.001s (0.76ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-2.8511e-01	5.9955e-01	3.1551e-01	1.0000e-01
    25	-2.3110e-01	5.7591e-03	3.2329e-03	1.0000e-01
    50	-2.2038e-01	3.0454e-08	8.3783e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2204
    Runtime: 0.001s (0.72ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.08ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-2.8546e-01	5.9955e-01	3.1550e-01	1.0000e-01
    25	-2.3166e-01	6.0919e-03	3.2089e-03	1.0000e-01
    50	-2.2023e-01	3.0101e-08	5.7252e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2202
    Runtime: 0.001s (0.76ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-2.8581e-01	5.9955e-01	3.1548e-01	1.0000e-01
    25	-2.3223e-01	6.4419e-03	3.1750e-03	1.0000e-01
    50	-2.2009e-01	2.3403e-08	6.6064e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2201
    Runtime: 0.001s (0.92ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-2.8616e-01	5.9955e-01	3.1547e-01	1.0000e-01
    25	-2.3282e-01	6.8020e-03	3.1328e-03	1.0000e-01
    50	-2.1994e-01	2.0099e-08	6.8941e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2199
    Runtime: 0.001s (0.78ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.1ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-2.8651e-01	5.9955e-01	3.1546e-01	1.0000e-01
    25	-2.3339e-01	7.1656e-03	3.0840e-03	1.0000e-01
    50	-2.1980e-01	1.6674e-08	8.6107e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2198
    Runtime: 0.001s (0.84ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.08ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-2.8686e-01	5.9955e-01	3.1544e-01	1.0000e-01
    25	-2.3395e-01	7.5272e-03	3.0311e-03	1.0000e-01
    50	-2.1965e-01	1.2804e-08	1.0805e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2197
    Runtime: 0.001s (0.81ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.1ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-2.8720e-01	5.9955e-01	3.1543e-01	1.0000e-01
    25	-2.3449e-01	7.8820e-03	2.9761e-03	1.0000e-01
    50	-2.1951e-01	1.3004e-08	1.2542e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2195
    Runtime: 0.001s (0.96ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.08ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-2.8755e-01	5.9955e-01	3.1541e-01	1.0000e-01
    25	-2.3499e-01	8.2262e-03	2.9211e-03	1.0000e-01
    50	-2.1936e-01	1.0979e-08	1.3680e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2194
    Runtime: 0.001s (0.8ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.11ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-2.8790e-01	5.9955e-01	3.1540e-01	1.0000e-01
    25	-2.3545e-01	8.5572e-03	2.8679e-03	1.0000e-01
    50	-2.1922e-01	1.0153e-08	1.3670e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2192
    Runtime: 0.001s (0.78ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-2.8824e-01	5.9955e-01	3.1539e-01	1.0000e-01
    25	-2.3587e-01	8.8728e-03	2.8179e-03	1.0000e-01
    50	-2.1907e-01	1.0884e-08	1.2448e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2191
    Runtime: 0.001s (0.71ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-2.8859e-01	5.9955e-01	3.1537e-01	1.0000e-01
    25	-2.3626e-01	9.1782e-03	2.7712e-03	1.0000e-01
    50	-2.1893e-01	1.0409e-08	1.0347e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2189
    Runtime: 0.001s (1.0ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.1ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-2.8894e-01	5.9955e-01	3.1536e-01	1.0000e-01
    25	-2.3664e-01	9.4847e-03	2.7280e-03	1.0000e-01
    50	-2.1878e-01	8.0439e-09	7.4497e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2188
    Runtime: 0.001s (0.73ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-2.8928e-01	5.9955e-01	3.1534e-01	1.0000e-01
    25	-2.3697e-01	9.7687e-03	2.6910e-03	1.0000e-01
    50	-2.1864e-01	5.7651e-09	4.1339e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2186
    Runtime: 0.001s (0.71ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-2.8963e-01	5.9955e-01	3.1533e-01	1.0000e-01
    25	-2.3723e-01	1.0028e-02	2.6600e-03	1.0000e-01
    50	-2.1849e-01	5.2085e-09	1.7274e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2185
    Runtime: 0.001s (0.82ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.1ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-2.8997e-01	5.9955e-01	3.1532e-01	1.0000e-01
    25	-2.3741e-01	1.0239e-02	2.6325e-03	1.0000e-01
    50	-2.1835e-01	4.2544e-09	1.0625e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2183
    Runtime: 0.001s (0.75ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.1ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-2.9031e-01	5.9955e-01	3.1530e-01	1.0000e-01
    25	-2.3729e-01	1.0236e-02	2.5880e-03	1.0000e-01
    50	-2.1820e-01	5.0363e-09	7.9272e-10	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2182
    Runtime: 0.001s (0.77ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.08ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-2.9066e-01	5.9955e-01	3.1529e-01	1.0000e-01
    25	-2.3715e-01	1.0222e-02	2.5466e-03	1.0000e-01
    50	-2.1806e-01	6.7264e-09	1.1658e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2181
    Runtime: 0.001s (0.69ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-2.9100e-01	5.9955e-01	3.1528e-01	1.0000e-01
    25	-2.3698e-01	1.0199e-02	2.5084e-03	1.0000e-01
    50	-2.1791e-01	7.8452e-09	3.2694e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2179
    Runtime: 0.001s (1.02ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.15ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-2.9135e-01	5.9955e-01	3.1526e-01	1.0000e-01
    25	-2.3679e-01	1.0167e-02	2.4734e-03	1.0000e-01
    50	-2.1777e-01	2.9308e-08	5.9849e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2178
    Runtime: 0.012s (12.25ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.12ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-2.9169e-01	5.9955e-01	3.1525e-01	1.0000e-01
    25	-2.3659e-01	1.0126e-02	2.4416e-03	1.0000e-01
    50	-2.1762e-01	3.5843e-08	3.1884e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2176
    Runtime: 0.001s (1.2ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.14ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-2.9203e-01	5.9955e-01	3.1523e-01	1.0000e-01
    25	-2.3636e-01	1.0077e-02	2.4130e-03	1.0000e-01
    50	-2.1748e-01	3.0664e-08	1.6525e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2175
    Runtime: 0.001s (0.83ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.11ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-2.9237e-01	5.9955e-01	3.1522e-01	1.0000e-01
    25	-2.3612e-01	1.0020e-02	2.3875e-03	1.0000e-01
    50	-2.1733e-01	2.5826e-08	4.5346e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2173
    Runtime: 0.001s (0.82ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-2.9271e-01	5.9955e-01	3.1521e-01	1.0000e-01
    25	-2.3588e-01	9.9567e-03	2.3651e-03	1.0000e-01
    50	-2.1719e-01	2.2403e-08	2.8642e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2172
    Runtime: 0.001s (0.84ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-2.9306e-01	5.9955e-01	3.1519e-01	1.0000e-01
    25	-2.3562e-01	9.8870e-03	2.3456e-03	1.0000e-01
    50	-2.1704e-01	2.1014e-08	2.7215e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.217
    Runtime: 0.001s (0.72ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.16ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-2.9340e-01	5.9955e-01	3.1518e-01	1.0000e-01
    25	-2.3535e-01	9.8118e-03	2.3289e-03	1.0000e-01
    50	-2.1689e-01	1.9801e-08	2.9341e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2169
    Runtime: 0.001s (0.76ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.1ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-2.9374e-01	5.9955e-01	3.1517e-01	1.0000e-01
    25	-2.3508e-01	9.7318e-03	2.3150e-03	1.0000e-01
    50	-2.1675e-01	1.7661e-08	2.8421e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2167
    Runtime: 0.001s (0.83ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.1ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-2.9408e-01	5.9955e-01	3.1515e-01	1.0000e-01
    25	-2.3481e-01	9.6477e-03	2.3037e-03	1.0000e-01
    50	-2.1660e-01	1.3365e-08	2.4799e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2166
    Runtime: 0.001s (1.03ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.11ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-2.9442e-01	5.9955e-01	3.1514e-01	1.0000e-01
    25	-2.3454e-01	9.5604e-03	2.2950e-03	1.0000e-01
    50	-2.1646e-01	6.4375e-09	1.2521e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2165
    Runtime: 0.001s (0.83ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-2.9476e-01	5.9955e-01	3.1512e-01	1.0000e-01
    25	-2.3427e-01	9.4706e-03	2.2888e-03	1.0000e-01
    50	-2.1631e-01	8.1960e-09	3.4265e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2163
    Runtime: 0.001s (0.74ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-2.9509e-01	5.9955e-01	3.1511e-01	1.0000e-01
    25	-2.3370e-01	9.1641e-03	2.2269e-03	1.0000e-01
    50	-2.1616e-01	2.1646e-08	1.0548e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2162
    Runtime: 0.001s (0.73ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.08ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-2.9543e-01	5.9955e-01	3.1510e-01	1.0000e-01
    25	-2.3286e-01	8.6838e-03	2.1184e-03	1.0000e-01
    50	-2.1602e-01	3.1496e-08	1.5156e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.216
    Runtime: 0.001s (0.69ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.11ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-2.9577e-01	5.9955e-01	3.1508e-01	1.0000e-01
    25	-2.3297e-01	8.7924e-03	2.3458e-03	1.0000e-01
    50	-2.1587e-01	2.5488e-08	1.1178e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2159
    Runtime: 0.001s (0.78ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-2.9611e-01	5.9955e-01	3.1507e-01	1.0000e-01
    25	-2.3337e-01	9.0827e-03	2.7062e-03	1.0000e-01
    50	-2.1573e-01	1.3851e-08	7.4539e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2157
    Runtime: 0.001s (0.68ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.1ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-2.9645e-01	5.9955e-01	3.1506e-01	1.0000e-01
    25	-2.3358e-01	9.2504e-03	3.0439e-03	1.0000e-01
    50	-2.1558e-01	1.1110e-08	3.7313e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2156
    Runtime: 0.001s (0.87ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.14ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-2.9678e-01	5.9955e-01	3.1504e-01	1.0000e-01
    25	-2.3362e-01	9.2823e-03	3.3553e-03	1.0000e-01
    50	-2.1543e-01	6.0866e-09	4.6670e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2154
    Runtime: 0.001s (1.08ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.1ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-2.9712e-01	5.9955e-01	3.1503e-01	1.0000e-01
    25	-2.3349e-01	9.1768e-03	3.6325e-03	1.0000e-01
    50	-2.1528e-01	3.6042e-09	1.3916e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2153
    Runtime: 0.001s (0.81ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-2.9746e-01	5.9955e-01	3.1502e-01	1.0000e-01
    25	-2.3324e-01	8.9445e-03	3.8614e-03	1.0000e-01
    50	-2.1514e-01	3.1934e-09	8.9668e-10	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2151
    Runtime: 0.001s (0.71ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.1ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-2.9779e-01	5.9955e-01	3.1500e-01	1.0000e-01
    25	-2.3290e-01	8.6030e-03	4.0218e-03	1.0000e-01
    50	-2.1499e-01	3.6857e-09	2.0410e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.215
    Runtime: 0.001s (0.75ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.11ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-2.9813e-01	5.9955e-01	3.1499e-01	1.0000e-01
    25	-2.3249e-01	8.1724e-03	4.0869e-03	1.0000e-01
    50	-2.1484e-01	1.1133e-09	1.1199e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2148
    Runtime: 0.001s (0.79ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.11ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-2.9846e-01	5.9955e-01	3.1498e-01	1.0000e-01
    25	-2.3204e-01	7.6751e-03	4.0261e-03	1.0000e-01
    50	-2.1469e-01	9.0868e-10	7.3963e-10	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2147
    Runtime: 0.001s (0.96ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.13ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-2.9880e-01	5.9955e-01	3.1496e-01	1.0000e-01
    25	-2.3158e-01	7.1420e-03	3.8127e-03	1.0000e-01
    50	-2.1455e-01	8.6951e-10	9.7481e-10	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2145
    Runtime: 0.002s (1.57ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.12ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-2.9913e-01	5.9955e-01	3.1495e-01	1.0000e-01
    25	-2.3114e-01	6.6141e-03	3.4363e-03	1.0000e-01
    50	-2.1440e-01	2.0217e-09	1.6611e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2144
    Runtime: 0.001s (1.09ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.1ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-2.9946e-01	5.9955e-01	3.1494e-01	1.0000e-01
    25	-2.3076e-01	6.1354e-03	2.9108e-03	1.0000e-01
    50	-2.1425e-01	1.7277e-08	2.9786e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2142
    Runtime: 0.001s (0.92ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.08ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-2.9980e-01	5.9955e-01	3.1492e-01	1.0000e-01
    25	-2.3045e-01	5.7821e-03	2.2673e-03	1.0000e-01
    50	-2.1410e-01	2.4581e-09	2.6118e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2141
    Runtime: 0.001s (0.75ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.1ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.0013e-01	5.9955e-01	3.1491e-01	1.0000e-01
    25	-2.3021e-01	5.8586e-03	1.5391e-03	1.0000e-01
    50	-2.1395e-01	1.7561e-09	5.5944e-10	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.214
    Runtime: 0.001s (0.71ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.1ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.0046e-01	5.9955e-01	3.1490e-01	1.0000e-01
    25	-2.3001e-01	5.9984e-03	1.8132e-03	1.0000e-01
    50	-2.1380e-01	3.3229e-09	1.0831e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2138
    Runtime: 0.001s (0.78ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.0080e-01	5.9955e-01	3.1488e-01	1.0000e-01
    25	-2.2982e-01	6.0737e-03	2.4745e-03	1.0000e-01
    50	-2.1365e-01	9.1907e-10	5.6445e-10	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2137
    Runtime: 0.001s (0.73ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.1ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.0113e-01	5.9955e-01	3.1487e-01	1.0000e-01
    25	-2.2962e-01	6.0851e-03	3.1565e-03	1.0000e-01
    50	-2.1350e-01	7.7357e-09	4.3109e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2135
    Runtime: 0.001s (0.73ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.0146e-01	5.9955e-01	3.1486e-01	1.0000e-01
    25	-2.2935e-01	6.0221e-03	3.7985e-03	1.0000e-01
    50	-2.1335e-01	2.1582e-09	4.2195e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2134
    Runtime: 0.001s (0.73ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.13ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.0179e-01	5.9955e-01	3.1484e-01	1.0000e-01
    25	-2.2897e-01	5.8534e-03	4.1997e-03	1.0000e-01
    50	-2.1320e-01	3.8520e-09	2.4270e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2132
    Runtime: 0.001s (1.05ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.0212e-01	5.9955e-01	3.1483e-01	1.0000e-01
    25	-2.2847e-01	5.5268e-03	3.7430e-03	1.0000e-01
    50	-2.1305e-01	1.5651e-09	1.1162e-10	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2131
    Runtime: 0.001s (0.78ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.0245e-01	5.9955e-01	3.1482e-01	1.0000e-01
    25	-2.2802e-01	5.4041e-03	1.4274e-03	1.0000e-01
    50	-2.1290e-01	1.4005e-09	1.0492e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2129
    Runtime: 0.001s (0.76ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.08ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.0278e-01	5.9955e-01	3.1480e-01	1.0000e-01
    25	-2.2798e-01	6.1543e-03	4.1567e-03	1.0000e-01
    50	-2.1275e-01	2.7937e-09	1.0689e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2127
    Runtime: 0.001s (0.73ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.0311e-01	5.9955e-01	3.1479e-01	1.0000e-01
    25	-2.2842e-01	7.0122e-03	8.3395e-03	1.0000e-01
    50	-2.1260e-01	3.2531e-09	1.9887e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2126
    Runtime: 0.001s (0.77ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.13ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.0344e-01	5.9955e-01	3.1478e-01	1.0000e-01
    25	-2.2899e-01	7.6546e-03	1.0663e-02	1.0000e-01
    50	-2.1245e-01	3.1856e-09	2.2746e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2124
    Runtime: 0.001s (0.81ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.11ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.0377e-01	5.9955e-01	3.1476e-01	1.0000e-01
    25	-2.2941e-01	8.0375e-03	1.1174e-02	1.0000e-01
    50	-2.1229e-01	2.0899e-09	9.6377e-10	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2123
    Runtime: 0.001s (0.74ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.08ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.0410e-01	5.9955e-01	3.1475e-01	1.0000e-01
    25	-2.2965e-01	8.2509e-03	1.0630e-02	1.0000e-01
    50	-2.1214e-01	7.3940e-10	5.0293e-10	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2121
    Runtime: 0.001s (0.75ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.0443e-01	5.9955e-01	3.1474e-01	1.0000e-01
    25	-2.2977e-01	8.3742e-03	9.6186e-03	1.0000e-01
    50	-2.1199e-01	8.2368e-10	5.5864e-10	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.212
    Runtime: 0.001s (1.0ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.13ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.0476e-01	5.9955e-01	3.1472e-01	1.0000e-01
    25	-2.2980e-01	8.4540e-03	8.4774e-03	1.0000e-01
    50	-2.1183e-01	3.7959e-09	1.5637e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2118
    Runtime: 0.001s (0.84ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.0508e-01	5.9955e-01	3.1471e-01	1.0000e-01
    25	-2.2979e-01	8.5142e-03	7.3732e-03	1.0000e-01
    50	-2.1168e-01	6.7938e-09	3.3596e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2117
    Runtime: 0.001s (0.71ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.08ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.0541e-01	5.9955e-01	3.1470e-01	1.0000e-01
    25	-2.2974e-01	8.5660e-03	6.3760e-03	1.0000e-01
    50	-2.1152e-01	1.0644e-08	6.9929e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2115
    Runtime: 0.001s (0.7ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.1ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.0574e-01	5.9956e-01	3.1469e-01	1.0000e-01
    25	-2.2968e-01	8.6143e-03	5.5040e-03	1.0000e-01
    50	-2.1137e-01	1.9075e-08	8.0618e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2114
    Runtime: 0.001s (0.74ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.1ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.0606e-01	5.9956e-01	3.1467e-01	1.0000e-01
    25	-2.2961e-01	8.6609e-03	4.7515e-03	1.0000e-01
    50	-2.1121e-01	1.2331e-08	5.0516e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2112
    Runtime: 0.001s (0.76ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.1ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.0639e-01	5.9956e-01	3.1466e-01	1.0000e-01
    25	-2.2954e-01	8.7059e-03	4.1036e-03	1.0000e-01
    50	-2.1106e-01	1.1751e-08	7.8855e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2111
    Runtime: 0.001s (0.79ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.0671e-01	5.9956e-01	3.1465e-01	1.0000e-01
    25	-2.2946e-01	8.7489e-03	3.5440e-03	1.0000e-01
    50	-2.1090e-01	1.0815e-08	1.9113e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2109
    Runtime: 0.001s (0.96ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.1ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.0704e-01	5.9956e-01	3.1463e-01	1.0000e-01
    25	-2.2937e-01	8.7895e-03	3.0577e-03	1.0000e-01
    50	-2.1074e-01	1.2604e-08	2.5213e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2107
    Runtime: 0.001s (0.76ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.0736e-01	5.9956e-01	3.1462e-01	1.0000e-01
    25	-2.2929e-01	8.8270e-03	2.6322e-03	1.0000e-01
    50	-2.1059e-01	1.7943e-08	5.0538e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2106
    Runtime: 0.001s (0.79ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.11ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.0769e-01	5.9956e-01	3.1461e-01	1.0000e-01
    25	-2.2919e-01	8.8613e-03	2.2587e-03	1.0000e-01
    50	-2.1043e-01	3.7502e-09	2.3203e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2104
    Runtime: 0.001s (0.88ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.11ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.0801e-01	5.9956e-01	3.1459e-01	1.0000e-01
    25	-2.2909e-01	8.8958e-03	2.0484e-03	1.0000e-01
    50	-2.1027e-01	4.1261e-08	1.6398e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2103
    Runtime: 0.001s (0.75ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.0834e-01	5.9956e-01	3.1458e-01	1.0000e-01
    25	-2.2898e-01	8.9256e-03	1.8648e-03	1.0000e-01
    50	-2.1011e-01	8.7094e-08	9.0907e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2101
    Runtime: 0.001s (1.14ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.1ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.0866e-01	5.9956e-01	3.1457e-01	1.0000e-01
    25	-2.2886e-01	8.9502e-03	1.7045e-03	1.0000e-01
    50	-2.0995e-01	1.3575e-07	4.0130e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.21
    Runtime: 0.001s (0.77ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.11ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.0898e-01	5.9956e-01	3.1456e-01	1.0000e-01
    25	-2.2874e-01	8.9691e-03	1.5647e-03	1.0000e-01
    50	-2.0979e-01	1.3758e-07	6.0416e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2098
    Runtime: 0.001s (0.76ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.0930e-01	5.9956e-01	3.1454e-01	1.0000e-01
    25	-2.2861e-01	8.9821e-03	1.4431e-03	1.0000e-01
    50	-2.0963e-01	1.0616e-08	1.2209e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2096
    Runtime: 0.001s (0.69ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.08ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.0963e-01	5.9956e-01	3.1453e-01	1.0000e-01
    25	-2.2847e-01	8.9887e-03	1.3377e-03	1.0000e-01
    50	-2.0947e-01	2.8130e-08	9.8785e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2095
    Runtime: 0.001s (0.69ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.1ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.0995e-01	5.9956e-01	3.1452e-01	1.0000e-01
    25	-2.2832e-01	8.9886e-03	1.2471e-03	1.0000e-01
    50	-2.0931e-01	1.9161e-08	6.8349e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2093
    Runtime: 0.001s (0.74ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.1027e-01	5.9956e-01	3.1450e-01	1.0000e-01
    25	-2.2817e-01	8.9818e-03	1.1701e-03	1.0000e-01
    50	-2.0914e-01	3.8391e-08	1.1886e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2091
    Runtime: 0.001s (0.74ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.13ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.1059e-01	5.9956e-01	3.1449e-01	1.0000e-01
    25	-2.2801e-01	8.9681e-03	1.1057e-03	1.0000e-01
    50	-2.0898e-01	5.0762e-08	1.1026e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.209
    Runtime: 0.001s (1.11ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.1ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.1091e-01	5.9956e-01	3.1448e-01	1.0000e-01
    25	-2.2784e-01	8.9476e-03	1.0533e-03	1.0000e-01
    50	-2.0881e-01	3.9560e-08	1.8955e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2088
    Runtime: 0.001s (0.76ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.1123e-01	5.9956e-01	3.1447e-01	1.0000e-01
    25	-2.2766e-01	8.9205e-03	1.0127e-03	1.0000e-01
    50	-2.0865e-01	3.4888e-08	9.5004e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2086
    Runtime: 0.001s (0.79ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.1155e-01	5.9956e-01	3.1445e-01	1.0000e-01
    25	-2.2748e-01	8.8874e-03	9.8385e-04	1.0000e-01
    50	-2.0848e-01	4.8454e-08	4.0451e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2085
    Runtime: 0.001s (0.75ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.11ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.1187e-01	5.9956e-01	3.1444e-01	1.0000e-01
    25	-2.2729e-01	8.8489e-03	9.6689e-04	1.0000e-01
    50	-2.0831e-01	7.5110e-08	5.1784e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2083
    Runtime: 0.001s (0.78ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.1219e-01	5.9956e-01	3.1443e-01	1.0000e-01
    25	-2.2710e-01	8.8060e-03	9.6228e-04	1.0000e-01
    50	-2.0815e-01	9.1145e-08	1.2484e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2081
    Runtime: 0.001s (0.7ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.1251e-01	5.9956e-01	3.1442e-01	1.0000e-01
    25	-2.2690e-01	8.7599e-03	9.7065e-04	1.0000e-01
    50	-2.0798e-01	7.2964e-08	2.0684e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.208
    Runtime: 0.001s (0.69ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.1283e-01	5.9956e-01	3.1440e-01	1.0000e-01
    25	-2.2670e-01	8.7119e-03	9.9266e-04	1.0000e-01
    50	-2.0781e-01	3.9107e-08	1.2100e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2078
    Runtime: 0.001s (0.72ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.1314e-01	5.9956e-01	3.1439e-01	1.0000e-01
    25	-2.2650e-01	8.6635e-03	1.0289e-03	1.0000e-01
    50	-2.0763e-01	6.0166e-08	1.3929e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2076
    Runtime: 0.001s (0.99ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.1346e-01	5.9956e-01	3.1438e-01	1.0000e-01
    25	-2.2631e-01	8.6164e-03	1.0797e-03	1.0000e-01
    50	-2.0746e-01	1.3289e-07	3.4052e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2075
    Runtime: 0.001s (0.71ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.1ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.1378e-01	5.9956e-01	3.1436e-01	1.0000e-01
    25	-2.2611e-01	8.5718e-03	1.1447e-03	1.0000e-01
    50	-2.0729e-01	1.5505e-07	4.4212e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2073
    Runtime: 0.001s (0.74ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.1ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.1409e-01	5.9956e-01	3.1435e-01	1.0000e-01
    25	-2.2592e-01	8.5309e-03	1.2233e-03	1.0000e-01
    50	-2.0711e-01	1.3850e-07	3.9905e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2071
    Runtime: 0.001s (0.73ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.12ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.1441e-01	5.9956e-01	3.1434e-01	1.0000e-01
    25	-2.2572e-01	8.4945e-03	1.3140e-03	1.0000e-01
    50	-2.0694e-01	5.1068e-08	1.6305e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2069
    Runtime: 0.001s (0.75ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.1473e-01	5.9956e-01	3.1433e-01	1.0000e-01
    25	-2.2554e-01	8.4630e-03	1.4150e-03	1.0000e-01
    50	-2.0676e-01	6.2709e-08	2.7174e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2068
    Runtime: 0.001s (0.75ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.1ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.1504e-01	5.9956e-01	3.1431e-01	1.0000e-01
    25	-2.2535e-01	8.4366e-03	1.5247e-03	1.0000e-01
    50	-2.0658e-01	9.8893e-08	1.5908e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2066
    Runtime: 0.001s (0.73ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.08ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.1536e-01	5.9956e-01	3.1430e-01	1.0000e-01
    25	-2.2517e-01	8.4152e-03	1.6417e-03	1.0000e-01
    50	-2.0640e-01	1.4958e-07	1.1158e-07	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2064
    Runtime: 0.001s (0.95ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.1ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.1567e-01	5.9956e-01	3.1429e-01	1.0000e-01
    25	-2.2500e-01	8.3987e-03	1.7654e-03	1.0000e-01
    50	-2.0622e-01	3.5847e-07	1.1807e-07	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2062
    Runtime: 0.001s (0.73ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.1599e-01	5.9956e-01	3.1428e-01	1.0000e-01
    25	-2.2483e-01	8.3869e-03	1.8955e-03	1.0000e-01
    50	-2.0604e-01	1.2301e-06	2.8329e-07	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.206
    Runtime: 0.001s (0.72ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.1ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.1630e-01	5.9956e-01	3.1426e-01	1.0000e-01
    25	-2.2467e-01	8.3796e-03	2.0324e-03	1.0000e-01
    50	-2.0604e-01	5.9545e-05	5.4698e-06	1.0000e-01
    75	-2.0585e-01	1.0100e-10	3.1917e-11	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 86 (incl. 11 safeguarding iter)
    Optimal objective: -0.2059
    Runtime: 0.001s (0.9ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.1661e-01	5.9956e-01	3.1425e-01	1.0000e-01
    25	-2.2452e-01	8.3767e-03	2.1760e-03	1.0000e-01
    50	-2.0583e-01	5.0838e-05	1.3771e-06	1.0000e-01
    75	-2.0567e-01	1.4327e-08	9.1441e-10	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 87 (incl. 12 safeguarding iter)
    Optimal objective: -0.2057
    Runtime: 0.001s (0.82ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.12ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.1693e-01	5.9956e-01	3.1424e-01	1.0000e-01
    25	-2.2439e-01	8.3776e-03	2.3259e-03	1.0000e-01
    50	-2.0652e-01	3.9307e-04	6.2602e-05	1.0000e-01
    75	-2.0549e-01	7.3196e-09	6.1203e-10	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 80 (incl. 5 safeguarding iter)
    Optimal objective: -0.2055
    Runtime: 0.003s (3.0ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.12ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.1724e-01	5.9956e-01	3.1423e-01	1.0000e-01
    25	-2.2428e-01	8.3815e-03	2.4802e-03	1.0000e-01
    50	-2.0696e-01	6.8312e-04	5.6809e-05	1.0000e-01
    75	-2.0530e-01	7.4389e-08	1.0346e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 83 (incl. 8 safeguarding iter)
    Optimal objective: -0.2053
    Runtime: 0.001s (0.99ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.1ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.1755e-01	5.9956e-01	3.1421e-01	1.0000e-01
    25	-2.2420e-01	8.3864e-03	2.6346e-03	1.0000e-01
    50	-2.0710e-01	7.4982e-04	8.8161e-05	1.0000e-01
    75	-2.0512e-01	7.5299e-08	4.5491e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 80 (incl. 5 safeguarding iter)
    Optimal objective: -0.2051
    Runtime: 0.012s (12.49ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.12ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.1787e-01	5.9956e-01	3.1420e-01	1.0000e-01
    25	-2.2415e-01	8.3890e-03	2.7812e-03	1.0000e-01
    50	-2.0689e-01	8.0137e-04	1.7010e-04	1.0000e-01
    75	-2.0494e-01	8.5399e-09	3.6403e-10	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 81 (incl. 6 safeguarding iter)
    Optimal objective: -0.2049
    Runtime: 0.001s (0.98ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.12ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.1818e-01	5.9956e-01	3.1419e-01	1.0000e-01
    25	-2.2412e-01	8.3845e-03	2.9077e-03	1.0000e-01
    50	-2.0503e-01	9.5007e-05	6.6296e-06	1.0000e-01
    75	-2.0475e-01	4.4550e-08	1.2983e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 77 (incl. 2 safeguarding iter)
    Optimal objective: -0.2048
    Runtime: 0.001s (1.01ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.11ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.1849e-01	5.9956e-01	3.1418e-01	1.0000e-01
    25	-2.2411e-01	8.3679e-03	2.9949e-03	1.0000e-01
    50	-2.0461e-01	5.8713e-05	2.1528e-05	1.0000e-01
    75	-2.0457e-01	1.9343e-09	1.9438e-10	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 76 (incl. 1 safeguarding iter)
    Optimal objective: -0.2046
    Runtime: 0.03s (29.88ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.11ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.1880e-01	5.9956e-01	3.1417e-01	1.0000e-01
    25	-2.2406e-01	8.4135e-03	2.9009e-03	1.0000e-01
    50	-2.0439e-01	4.5410e-06	3.0772e-06	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 51 (incl. 1 safeguarding iter)
    Optimal objective: -0.2044
    Runtime: 0.001s (0.75ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.1ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.1911e-01	5.9956e-01	3.1415e-01	1.0000e-01
    25	-2.2397e-01	8.4745e-03	2.7951e-03	1.0000e-01
    50	-2.0422e-01	7.0342e-06	9.5880e-07	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 51 (incl. 1 safeguarding iter)
    Optimal objective: -0.2042
    Runtime: 0.001s (0.74ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.1ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.1942e-01	5.9956e-01	3.1414e-01	1.0000e-01
    25	-2.2388e-01	8.5290e-03	2.6885e-03	1.0000e-01
    50	-2.0402e-01	2.3251e-06	1.4624e-06	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.204
    Runtime: 0.001s (0.74ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.1973e-01	5.9956e-01	3.1413e-01	1.0000e-01
    25	-2.2379e-01	8.5764e-03	2.5813e-03	1.0000e-01
    50	-2.0636e-01	1.1314e-03	1.2283e-04	1.0000e-01
    75	-2.0383e-01	2.1538e-09	8.5324e-11	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 84 (incl. 9 safeguarding iter)
    Optimal objective: -0.2038
    Runtime: 0.001s (0.9ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.15ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.2004e-01	5.9956e-01	3.1412e-01	1.0000e-01
    25	-2.2369e-01	8.6171e-03	2.4738e-03	1.0000e-01
    50	-2.0485e-01	4.7612e-04	2.6161e-04	1.0000e-01
    75	-2.0365e-01	2.3586e-07	1.2494e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 84 (incl. 9 safeguarding iter)
    Optimal objective: -0.2036
    Runtime: 0.001s (1.0ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.08ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.2035e-01	5.9956e-01	3.1410e-01	1.0000e-01
    25	-2.2360e-01	8.6513e-03	2.3669e-03	1.0000e-01
    50	-2.0437e-01	2.8971e-04	4.0311e-05	1.0000e-01
    75	-2.0346e-01	1.0221e-07	9.6331e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 79 (incl. 4 safeguarding iter)
    Optimal objective: -0.2035
    Runtime: 0.001s (0.83ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.12ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.2066e-01	5.9956e-01	3.1409e-01	1.0000e-01
    25	-2.2351e-01	8.6797e-03	2.2616e-03	1.0000e-01
    50	-2.0736e-01	1.7080e-03	5.0005e-04	1.0000e-01
    75	-2.0328e-01	2.3727e-08	6.9144e-10	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 85 (incl. 10 safeguarding iter)
    Optimal objective: -0.2033
    Runtime: 0.001s (0.96ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.2097e-01	5.9956e-01	3.1408e-01	1.0000e-01
    25	-2.2341e-01	8.7029e-03	2.1588e-03	1.0000e-01
    50	-2.0321e-01	1.1085e-04	4.1073e-05	1.0000e-01
    75	-2.0309e-01	1.7720e-08	3.5301e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 77 (incl. 2 safeguarding iter)
    Optimal objective: -0.2031
    Runtime: 0.001s (1.04ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.1ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.2127e-01	5.9956e-01	3.1407e-01	1.0000e-01
    25	-2.2332e-01	8.7212e-03	2.0593e-03	1.0000e-01
    50	-2.0291e-01	7.3651e-06	1.7350e-06	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 52 (incl. 2 safeguarding iter)
    Optimal objective: -0.2029
    Runtime: 0.001s (0.73ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.08ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.2158e-01	5.9956e-01	3.1405e-01	1.0000e-01
    25	-2.2323e-01	8.7350e-03	1.9631e-03	1.0000e-01
    50	-2.0273e-01	2.8219e-05	8.7262e-06	1.0000e-01
    75	-2.0272e-01	3.0818e-09	1.2023e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.2027
    Runtime: 0.001s (0.85ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.08ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.2189e-01	5.9956e-01	3.1404e-01	1.0000e-01
    25	-2.2314e-01	8.7441e-03	1.8694e-03	1.0000e-01
    50	-2.0254e-01	1.3312e-06	5.1809e-07	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2025
    Runtime: 0.001s (0.75ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.2220e-01	5.9956e-01	3.1403e-01	1.0000e-01
    25	-2.2305e-01	8.7482e-03	1.7760e-03	1.0000e-01
    50	-2.0236e-01	1.1273e-05	9.9743e-07	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2024
    Runtime: 0.001s (0.71ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.08ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.2250e-01	5.9956e-01	3.1402e-01	1.0000e-01
    25	-2.2297e-01	8.7469e-03	1.6794e-03	1.0000e-01
    50	-2.0217e-01	1.2874e-06	1.3712e-06	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.2022
    Runtime: 0.001s (0.68ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.14ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.2281e-01	5.9956e-01	3.1401e-01	1.0000e-01
    25	-2.2290e-01	8.7404e-03	1.5743e-03	1.0000e-01
    50	-2.0199e-01	1.2557e-05	5.7612e-06	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.202
    Runtime: 0.001s (0.74ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.12ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.2311e-01	5.9956e-01	3.1399e-01	1.0000e-01
    25	-2.2284e-01	8.7309e-03	1.4547e-03	1.0000e-01
    50	-2.0417e-01	7.5587e-04	5.6272e-04	1.0000e-01
    75	-2.0180e-01	6.2531e-08	2.4410e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 89 (incl. 14 safeguarding iter)
    Optimal objective: -0.2018
    Runtime: 0.001s (0.96ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.2342e-01	5.9956e-01	3.1398e-01	1.0000e-01
    25	-2.2280e-01	8.7239e-03	1.3166e-03	1.0000e-01
    50	-2.0161e-01	3.2786e-05	5.8868e-06	1.0000e-01
    75	-2.0161e-01	1.7345e-08	2.1089e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 79 (incl. 4 safeguarding iter)
    Optimal objective: -0.2016
    Runtime: 0.001s (1.15ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.1ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.2372e-01	5.9956e-01	3.1397e-01	1.0000e-01
    25	-2.2277e-01	8.7300e-03	1.1631e-03	1.0000e-01
    50	-2.0142e-01	2.2084e-05	1.1724e-05	1.0000e-01
    75	-2.0143e-01	4.1690e-09	4.5477e-10	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 79 (incl. 4 safeguarding iter)
    Optimal objective: -0.2014
    Runtime: 0.001s (0.89ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.2403e-01	5.9956e-01	3.1396e-01	1.0000e-01
    25	-2.2275e-01	8.7614e-03	1.0092e-03	1.0000e-01
    50	-2.0354e-01	8.5272e-04	7.1701e-04	1.0000e-01
    75	-2.0124e-01	1.1047e-07	1.1088e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 90 (incl. 15 safeguarding iter)
    Optimal objective: -0.2012
    Runtime: 0.001s (0.86ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.08ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.2433e-01	5.9956e-01	3.1395e-01	1.0000e-01
    25	-2.2273e-01	8.8238e-03	8.7773e-04	1.0000e-01
    50	-2.0243e-01	6.4639e-04	6.2491e-04	1.0000e-01
    75	-2.0106e-01	5.9512e-07	1.3693e-07	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 88 (incl. 13 safeguarding iter)
    Optimal objective: -0.2011
    Runtime: 0.001s (0.87ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.12ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.2464e-01	5.9956e-01	3.1393e-01	1.0000e-01
    25	-2.2271e-01	8.9114e-03	7.8527e-04	1.0000e-01
    50	-2.0210e-01	1.3846e-03	2.8403e-04	1.0000e-01
    75	-2.0087e-01	1.2712e-06	5.6606e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 88 (incl. 13 safeguarding iter)
    Optimal objective: -0.2009
    Runtime: 0.001s (0.89ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.2494e-01	5.9956e-01	3.1392e-01	1.0000e-01
    25	-2.2267e-01	9.0104e-03	7.3292e-04	1.0000e-01
    50	-2.0287e-01	7.8441e-04	1.6989e-04	1.0000e-01
    75	-2.0068e-01	2.0380e-07	1.1043e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 89 (incl. 14 safeguarding iter)
    Optimal objective: -0.2007
    Runtime: 0.001s (0.84ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.2524e-01	5.9956e-01	3.1391e-01	1.0000e-01
    25	-2.2261e-01	9.1089e-03	7.2597e-04	1.0000e-01
    50	-2.0180e-01	1.8621e-03	3.3742e-04	1.0000e-01
    75	-2.0050e-01	1.5273e-06	1.0078e-07	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 87 (incl. 12 safeguarding iter)
    Optimal objective: -0.2005
    Runtime: 0.001s (0.84ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.2555e-01	5.9956e-01	3.1390e-01	1.0000e-01
    25	-2.2255e-01	9.2001e-03	7.5117e-04	1.0000e-01
    50	-2.0239e-01	7.8897e-04	6.8213e-04	1.0000e-01
    75	-2.0031e-01	3.2563e-06	2.5559e-07	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 86 (incl. 11 safeguarding iter)
    Optimal objective: -0.2003
    Runtime: 0.001s (1.11ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.2585e-01	5.9956e-01	3.1389e-01	1.0000e-01
    25	-2.2249e-01	9.2820e-03	7.8029e-04	1.0000e-01
    50	-2.0008e-01	2.4477e-05	2.2515e-06	1.0000e-01
    75	-2.0012e-01	7.4115e-09	1.2250e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 80 (incl. 5 safeguarding iter)
    Optimal objective: -0.2001
    Runtime: 0.001s (0.84ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.1ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.2615e-01	5.9956e-01	3.1387e-01	1.0000e-01
    25	-2.2242e-01	9.3550e-03	8.0792e-04	1.0000e-01
    50	-1.9991e-01	2.7968e-05	5.6421e-06	1.0000e-01
    75	-1.9993e-01	1.9009e-08	2.8238e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 80 (incl. 5 safeguarding iter)
    Optimal objective: -0.1999
    Runtime: 0.001s (0.9ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.2645e-01	5.9956e-01	3.1386e-01	1.0000e-01
    25	-2.2235e-01	9.4204e-03	8.3177e-04	1.0000e-01
    50	-1.9972e-01	1.3024e-05	6.0370e-06	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 54 (incl. 4 safeguarding iter)
    Optimal objective: -0.1997
    Runtime: 0.001s (0.71ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.08ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.2675e-01	5.9956e-01	3.1385e-01	1.0000e-01
    25	-2.2227e-01	9.4794e-03	8.5129e-04	1.0000e-01
    50	-1.9955e-01	1.0299e-05	6.5510e-07	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 54 (incl. 4 safeguarding iter)
    Optimal objective: -0.1996
    Runtime: 0.001s (0.71ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.2705e-01	5.9956e-01	3.1384e-01	1.0000e-01
    25	-2.2220e-01	9.5333e-03	8.6669e-04	1.0000e-01
    50	-1.9935e-01	1.2220e-05	4.4000e-06	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 54 (incl. 4 safeguarding iter)
    Optimal objective: -0.1994
    Runtime: 0.001s (0.73ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.08ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.2735e-01	5.9956e-01	3.1383e-01	1.0000e-01
    25	-2.2204e-01	9.5477e-03	8.8763e-04	1.0000e-01
    50	-1.9917e-01	9.5476e-06	3.4046e-06	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 54 (incl. 4 safeguarding iter)
    Optimal objective: -0.1992
    Runtime: 0.001s (0.77ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.2765e-01	5.9956e-01	3.1381e-01	1.0000e-01
    25	-2.2184e-01	9.5254e-03	8.9475e-04	1.0000e-01
    50	-1.9898e-01	4.8286e-06	3.4583e-06	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 52 (incl. 2 safeguarding iter)
    Optimal objective: -0.199
    Runtime: 0.001s (0.96ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.2795e-01	5.9956e-01	3.1380e-01	1.0000e-01
    25	-2.2163e-01	9.4868e-03	8.8820e-04	1.0000e-01
    50	-1.9879e-01	5.2965e-06	2.0705e-06	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.1988
    Runtime: 0.001s (0.74ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.2825e-01	5.9956e-01	3.1379e-01	1.0000e-01
    25	-2.2139e-01	9.4330e-03	8.7956e-04	1.0000e-01
    50	-1.9860e-01	3.6873e-05	7.4883e-06	1.0000e-01
    75	-1.9861e-01	3.0367e-08	2.1437e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 76 (incl. 1 safeguarding iter)
    Optimal objective: -0.1986
    Runtime: 0.001s (0.87ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.08ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.2855e-01	5.9956e-01	3.1378e-01	1.0000e-01
    25	-2.2112e-01	9.3620e-03	9.2096e-04	1.0000e-01
    50	-1.9840e-01	7.4639e-05	1.4201e-05	1.0000e-01
    75	-1.9842e-01	6.4036e-08	4.0628e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 76 (incl. 1 safeguarding iter)
    Optimal objective: -0.1984
    Runtime: 0.001s (0.81ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.08ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.2885e-01	5.9956e-01	3.1377e-01	1.0000e-01
    25	-2.2080e-01	9.2708e-03	9.7002e-04	1.0000e-01
    50	-1.9821e-01	1.2614e-05	5.8010e-06	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.1982
    Runtime: 0.001s (0.67ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.08ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.2915e-01	5.9956e-01	3.1376e-01	1.0000e-01
    25	-2.2042e-01	9.1564e-03	1.0282e-03	1.0000e-01
    50	-1.9803e-01	7.5965e-06	4.1255e-06	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.198
    Runtime: 0.001s (0.68ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.08ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.2945e-01	5.9956e-01	3.1374e-01	1.0000e-01
    25	-2.1996e-01	9.0185e-03	1.0940e-03	1.0000e-01
    50	-1.9784e-01	5.4508e-06	2.1217e-06	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 56 (incl. 6 safeguarding iter)
    Optimal objective: -0.1978
    Runtime: 0.001s (0.76ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.2975e-01	5.9956e-01	3.1373e-01	1.0000e-01
    25	-2.1945e-01	8.8625e-03	1.1621e-03	1.0000e-01
    50	-1.9766e-01	1.2182e-05	3.7526e-06	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.1977
    Runtime: 0.001s (1.08ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.08ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.3004e-01	5.9956e-01	3.1372e-01	1.0000e-01
    25	-2.1893e-01	8.7032e-03	1.2233e-03	1.0000e-01
    50	-1.9746e-01	1.6368e-05	1.8389e-06	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.1975
    Runtime: 0.001s (0.69ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.1ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.3034e-01	5.9956e-01	3.1371e-01	1.0000e-01
    25	-2.1845e-01	8.5661e-03	1.2677e-03	1.0000e-01
    50	-1.9728e-01	8.5954e-06	2.3116e-06	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.1973
    Runtime: 0.001s (0.75ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.3064e-01	5.9956e-01	3.1370e-01	1.0000e-01
    25	-2.1811e-01	8.4818e-03	1.2916e-03	1.0000e-01
    50	-1.9707e-01	2.0167e-05	1.5941e-06	1.0000e-01
    75	-1.9708e-01	9.5208e-09	1.8569e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.1971
    Runtime: 0.001s (0.86ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.1ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.3093e-01	5.9957e-01	3.1369e-01	1.0000e-01
    25	-2.1799e-01	8.4721e-03	1.3000e-03	1.0000e-01
    50	-1.9685e-01	3.4278e-05	3.8638e-06	1.0000e-01
    75	-1.9688e-01	2.7836e-08	6.3639e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 78 (incl. 3 safeguarding iter)
    Optimal objective: -0.1969
    Runtime: 0.001s (0.97ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.3123e-01	5.9957e-01	3.1367e-01	1.0000e-01
    25	-2.1809e-01	8.5383e-03	1.2997e-03	1.0000e-01
    50	-1.9667e-01	1.7860e-05	1.1407e-05	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 53 (incl. 3 safeguarding iter)
    Optimal objective: -0.1967
    Runtime: 0.001s (0.76ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.3152e-01	5.9957e-01	3.1366e-01	1.0000e-01
    25	-2.1837e-01	8.6649e-03	1.2876e-03	1.0000e-01
    50	-1.9652e-01	1.1303e-04	1.5746e-05	1.0000e-01
    75	-1.9649e-01	4.1724e-08	8.0587e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 77 (incl. 2 safeguarding iter)
    Optimal objective: -0.1965
    Runtime: 0.001s (0.94ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.1ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.3182e-01	5.9957e-01	3.1365e-01	1.0000e-01
    25	-2.1875e-01	8.8347e-03	1.2958e-03	1.0000e-01
    50	-1.9637e-01	1.4672e-04	2.3177e-05	1.0000e-01
    75	-1.9630e-01	4.9378e-08	4.6659e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 77 (incl. 2 safeguarding iter)
    Optimal objective: -0.1963
    Runtime: 0.001s (0.87ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.3211e-01	5.9957e-01	3.1364e-01	1.0000e-01
    25	-2.1921e-01	9.0382e-03	1.2484e-03	1.0000e-01
    50	-1.9612e-01	5.8730e-05	5.2042e-06	1.0000e-01
    75	-1.9610e-01	1.0169e-08	1.7471e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.1961
    Runtime: 0.001s (0.86ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.3241e-01	5.9957e-01	3.1363e-01	1.0000e-01
    25	-2.1971e-01	9.2710e-03	1.1131e-03	1.0000e-01
    50	-1.9591e-01	7.0813e-05	9.5628e-06	1.0000e-01
    75	-1.9590e-01	4.0484e-08	2.3237e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.1959
    Runtime: 0.001s (0.81ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.3270e-01	5.9957e-01	3.1362e-01	1.0000e-01
    25	-2.2023e-01	9.5246e-03	8.8183e-04	1.0000e-01
    50	-1.9570e-01	8.3659e-05	1.4144e-05	1.0000e-01
    75	-1.9571e-01	5.7575e-08	2.3235e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.1957
    Runtime: 0.001s (0.82ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.08ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.3299e-01	5.9957e-01	3.1360e-01	1.0000e-01
    25	-2.2075e-01	9.7812e-03	5.8259e-04	1.0000e-01
    50	-1.9549e-01	9.0871e-05	1.5789e-05	1.0000e-01
    75	-1.9551e-01	6.4064e-08	3.0051e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.1955
    Runtime: 0.001s (0.81ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.3329e-01	5.9957e-01	3.1359e-01	1.0000e-01
    25	-2.2126e-01	1.0015e-02	2.7699e-04	1.0000e-01
    50	-1.9529e-01	5.9195e-05	8.2839e-06	1.0000e-01
    75	-1.9531e-01	4.1652e-08	3.0220e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.1953
    Runtime: 0.001s (0.79ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.08ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.3358e-01	5.9957e-01	3.1358e-01	1.0000e-01
    25	-2.2174e-01	1.0208e-02	4.6351e-04	1.0000e-01
    50	-1.9513e-01	3.3593e-05	1.5691e-06	1.0000e-01
    75	-1.9511e-01	1.9868e-08	5.2661e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.1951
    Runtime: 0.001s (0.87ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.3387e-01	5.9957e-01	3.1357e-01	1.0000e-01
    25	-2.2219e-01	1.0369e-02	5.6388e-04	1.0000e-01
    50	-1.9493e-01	1.8135e-05	2.4240e-06	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.1949
    Runtime: 0.001s (0.73ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.3416e-01	5.9957e-01	3.1356e-01	1.0000e-01
    25	-2.2261e-01	1.0531e-02	5.9492e-04	1.0000e-01
    50	-1.9473e-01	1.5584e-05	2.2318e-06	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.1947
    Runtime: 0.001s (0.94ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.3446e-01	5.9957e-01	3.1355e-01	1.0000e-01
    25	-2.2301e-01	1.0712e-02	6.0548e-04	1.0000e-01
    50	-1.9453e-01	1.4150e-05	2.0257e-06	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.1945
    Runtime: 0.001s (0.71ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.11ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.3475e-01	5.9957e-01	3.1354e-01	1.0000e-01
    25	-2.2339e-01	1.0907e-02	6.1678e-04	1.0000e-01
    50	-1.9433e-01	1.3798e-05	2.0175e-06	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.1943
    Runtime: 0.001s (0.75ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.3504e-01	5.9957e-01	3.1352e-01	1.0000e-01
    25	-2.2363e-01	1.1065e-02	6.2954e-04	1.0000e-01
    50	-1.9412e-01	1.9260e-05	1.9270e-06	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 50
    Optimal objective: -0.1941
    Runtime: 0.001s (0.69ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.3533e-01	5.9957e-01	3.1351e-01	1.0000e-01
    25	-2.2377e-01	1.1193e-02	6.4038e-04	1.0000e-01
    50	-1.9392e-01	3.2909e-05	1.4184e-06	1.0000e-01
    75	-1.9390e-01	1.0339e-07	9.3716e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.1939
    Runtime: 0.001s (0.81ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.3562e-01	5.9957e-01	3.1350e-01	1.0000e-01
    25	-2.2390e-01	1.1321e-02	6.4875e-04	1.0000e-01
    50	-1.9371e-01	6.8362e-05	7.6111e-06	1.0000e-01
    75	-1.9369e-01	5.8948e-08	1.9181e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.1937
    Runtime: 0.001s (0.9ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.08ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.3591e-01	5.9957e-01	3.1349e-01	1.0000e-01
    25	-2.2403e-01	1.1449e-02	6.5469e-04	1.0000e-01
    50	-1.9350e-01	1.0855e-04	1.3422e-05	1.0000e-01
    75	-1.9349e-01	1.6954e-07	3.0051e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.1935
    Runtime: 0.001s (0.81ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.3620e-01	5.9957e-01	3.1348e-01	1.0000e-01
    25	-2.2416e-01	1.1578e-02	6.5822e-04	1.0000e-01
    50	-1.9328e-01	1.4992e-04	2.0645e-05	1.0000e-01
    75	-1.9328e-01	2.4637e-07	3.5861e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.1933
    Runtime: 0.001s (1.07ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.1ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.3649e-01	5.9957e-01	3.1347e-01	1.0000e-01
    25	-2.2429e-01	1.1708e-02	6.5933e-04	1.0000e-01
    50	-1.9307e-01	1.8484e-04	2.8063e-05	1.0000e-01
    75	-1.9307e-01	3.3408e-07	3.8850e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.1931
    Runtime: 0.001s (0.86ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.11ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.3677e-01	5.9957e-01	3.1346e-01	1.0000e-01
    25	-2.2442e-01	1.1839e-02	6.5807e-04	1.0000e-01
    50	-1.9286e-01	2.0900e-04	3.3993e-05	1.0000e-01
    75	-1.9286e-01	3.9862e-07	5.5789e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.1929
    Runtime: 0.001s (0.87ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.3706e-01	5.9957e-01	3.1344e-01	1.0000e-01
    25	-2.2455e-01	1.1971e-02	6.5444e-04	1.0000e-01
    50	-1.9267e-01	2.3209e-04	3.8321e-05	1.0000e-01
    75	-1.9265e-01	4.8161e-07	7.2795e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.1927
    Runtime: 0.001s (0.81ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.3735e-01	5.9957e-01	3.1343e-01	1.0000e-01
    25	-2.2458e-01	1.2078e-02	6.5892e-04	1.0000e-01
    50	-1.9246e-01	2.6584e-04	4.2036e-05	1.0000e-01
    75	-1.9244e-01	4.0216e-07	7.4563e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.1924
    Runtime: 0.001s (0.95ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.1ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.3764e-01	5.9957e-01	3.1342e-01	1.0000e-01
    25	-2.2462e-01	1.2190e-02	6.6357e-04	1.0000e-01
    50	-1.9226e-01	2.8083e-04	4.2916e-05	1.0000e-01
    75	-1.9223e-01	5.4936e-07	1.3558e-07	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.1922
    Runtime: 0.001s (0.89ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.11ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.3793e-01	5.9957e-01	3.1341e-01	1.0000e-01
    25	-2.2467e-01	1.2306e-02	6.6802e-04	1.0000e-01
    50	-1.9205e-01	2.4844e-04	3.7665e-05	1.0000e-01
    75	-1.9202e-01	6.8504e-07	8.9216e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.192
    Runtime: 0.001s (1.06ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.3821e-01	5.9957e-01	3.1340e-01	1.0000e-01
    25	-2.2472e-01	1.2427e-02	6.7187e-04	1.0000e-01
    50	-1.9182e-01	1.7223e-04	2.6024e-05	1.0000e-01
    75	-1.9180e-01	4.4880e-07	4.3891e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.1918
    Runtime: 0.001s (0.8ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.1ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.3850e-01	5.9957e-01	3.1339e-01	1.0000e-01
    25	-2.2477e-01	1.2553e-02	6.7462e-04	1.0000e-01
    50	-1.9161e-01	1.0141e-04	1.5635e-05	1.0000e-01
    75	-1.9158e-01	3.1370e-07	2.1973e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.1916
    Runtime: 0.001s (1.5ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.13ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.3879e-01	5.9957e-01	3.1338e-01	1.0000e-01
    25	-2.2484e-01	1.2682e-02	6.7574e-04	1.0000e-01
    50	-1.9140e-01	8.0959e-05	1.3420e-05	1.0000e-01
    75	-1.9137e-01	3.4621e-07	3.5290e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.1914
    Runtime: 0.001s (1.05ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.1ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.3907e-01	5.9957e-01	3.1337e-01	1.0000e-01
    25	-2.2490e-01	1.2816e-02	6.7465e-04	1.0000e-01
    50	-1.9119e-01	9.4690e-05	1.4783e-05	1.0000e-01
    75	-1.9115e-01	4.5603e-07	4.7949e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.1911
    Runtime: 0.001s (1.04ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.3936e-01	5.9957e-01	3.1335e-01	1.0000e-01
    25	-2.2497e-01	1.2953e-02	6.7074e-04	1.0000e-01
    50	-1.9100e-01	1.3573e-04	1.9578e-05	1.0000e-01
    75	-1.9093e-01	3.9609e-07	4.8337e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.1909
    Runtime: 0.001s (0.97ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.12ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.3964e-01	5.9957e-01	3.1334e-01	1.0000e-01
    25	-2.2505e-01	1.3093e-02	6.6346e-04	1.0000e-01
    50	-1.9081e-01	1.8269e-04	2.5833e-05	1.0000e-01
    75	-1.9070e-01	3.0395e-07	5.6224e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.1907
    Runtime: 0.001s (1.21ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.15ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.3993e-01	5.9957e-01	3.1333e-01	1.0000e-01
    25	-2.2514e-01	1.3236e-02	6.5230e-04	1.0000e-01
    50	-1.9062e-01	2.2502e-04	3.1776e-05	1.0000e-01
    75	-1.9048e-01	4.2473e-07	5.9162e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.1905
    Runtime: 0.001s (1.31ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.17ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.4021e-01	5.9957e-01	3.1332e-01	1.0000e-01
    25	-2.2523e-01	1.3382e-02	6.3685e-04	1.0000e-01
    50	-1.9043e-01	2.6268e-04	3.6836e-05	1.0000e-01
    75	-1.9025e-01	5.3987e-07	5.2913e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.1903
    Runtime: 0.001s (0.95ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.11ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.4049e-01	5.9957e-01	3.1331e-01	1.0000e-01
    25	-2.2532e-01	1.3530e-02	6.1683e-04	1.0000e-01
    50	-1.9025e-01	2.9667e-04	4.1025e-05	1.0000e-01
    75	-1.9003e-01	5.8715e-07	5.3153e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.19
    Runtime: 0.001s (0.92ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.1ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.4078e-01	5.9957e-01	3.1330e-01	1.0000e-01
    25	-2.2542e-01	1.3680e-02	5.9209e-04	1.0000e-01
    50	-1.9007e-01	3.2671e-04	4.4323e-05	1.0000e-01
    75	-1.8980e-01	7.2550e-07	8.8347e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.1898
    Runtime: 0.001s (0.86ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.4106e-01	5.9957e-01	3.1329e-01	1.0000e-01
    25	-2.2553e-01	1.3832e-02	5.6266e-04	1.0000e-01
    50	-1.8991e-01	3.7709e-04	5.7633e-05	1.0000e-01
    75	-1.8957e-01	8.9469e-07	9.0232e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.1896
    Runtime: 0.001s (0.8ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.4134e-01	5.9957e-01	3.1328e-01	1.0000e-01
    25	-2.2564e-01	1.3985e-02	5.2871e-04	1.0000e-01
    50	-1.8987e-01	3.4207e-04	5.5838e-05	1.0000e-01
    75	-1.8934e-01	9.5201e-07	7.1062e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.1893
    Runtime: 0.001s (1.06ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.4163e-01	5.9957e-01	3.1327e-01	1.0000e-01
    25	-2.2576e-01	1.4140e-02	5.5291e-04	1.0000e-01
    50	-1.8968e-01	3.0949e-04	5.0186e-05	1.0000e-01
    75	-1.8911e-01	2.4515e-06	1.7106e-07	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.1891
    Runtime: 0.001s (0.88ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.1ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.4191e-01	5.9957e-01	3.1325e-01	1.0000e-01
    25	-2.2588e-01	1.4298e-02	5.8947e-04	1.0000e-01
    50	-1.8941e-01	3.0077e-04	4.8025e-05	1.0000e-01
    75	-1.8887e-01	3.9702e-06	2.5262e-07	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.1889
    Runtime: 0.001s (1.31ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.4219e-01	5.9957e-01	3.1324e-01	1.0000e-01
    25	-2.2601e-01	1.4457e-02	6.1428e-04	1.0000e-01
    50	-1.8909e-01	2.9157e-04	4.7392e-05	1.0000e-01
    75	-1.8863e-01	2.3775e-06	9.0309e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.1886
    Runtime: 0.001s (0.88ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.1ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.4247e-01	5.9957e-01	3.1323e-01	1.0000e-01
    25	-2.2615e-01	1.4619e-02	6.2810e-04	1.0000e-01
    50	-1.8872e-01	2.6323e-04	4.5805e-05	1.0000e-01
    75	-1.8838e-01	8.6081e-07	4.6025e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.1884
    Runtime: 0.001s (0.94ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.4275e-01	5.9957e-01	3.1322e-01	1.0000e-01
    25	-2.2629e-01	1.4785e-02	6.3173e-04	1.0000e-01
    50	-1.8840e-01	2.6340e-04	4.0460e-05	1.0000e-01
    75	-1.8813e-01	8.2105e-07	4.4708e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.1881
    Runtime: 0.001s (0.82ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.4303e-01	5.9957e-01	3.1321e-01	1.0000e-01
    25	-2.2644e-01	1.4954e-02	6.3483e-04	1.0000e-01
    50	-1.8814e-01	2.7564e-04	3.0853e-05	1.0000e-01
    75	-1.8788e-01	1.2959e-06	6.4079e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.1879
    Runtime: 0.001s (0.87ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.4331e-01	5.9957e-01	3.1320e-01	1.0000e-01
    25	-2.2659e-01	1.5128e-02	6.8320e-04	1.0000e-01
    50	-1.8785e-01	2.2158e-04	1.3146e-05	1.0000e-01
    75	-1.8764e-01	2.1861e-06	2.8538e-07	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.1876
    Runtime: 0.001s (0.82ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.08ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.4359e-01	5.9957e-01	3.1319e-01	1.0000e-01
    25	-2.2675e-01	1.5303e-02	7.2837e-04	1.0000e-01
    50	-1.8753e-01	1.5167e-04	1.0395e-05	1.0000e-01
    75	-1.8739e-01	2.8439e-06	4.3921e-07	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.1874
    Runtime: 0.001s (0.83ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.4387e-01	5.9957e-01	3.1318e-01	1.0000e-01
    25	-2.2685e-01	1.5443e-02	7.5921e-04	1.0000e-01
    50	-1.8703e-01	8.3774e-05	1.2855e-05	1.0000e-01
    75	-1.8712e-01	1.5574e-06	2.8599e-07	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.1871
    Runtime: 0.001s (1.15ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.1ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.4415e-01	5.9957e-01	3.1317e-01	1.0000e-01
    25	-2.2695e-01	1.5587e-02	7.8828e-04	1.0000e-01
    50	-1.8670e-01	8.6474e-05	1.9040e-05	1.0000e-01
    75	-1.8685e-01	4.3764e-06	2.9095e-07	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.1869
    Runtime: 0.001s (0.86ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.4443e-01	5.9957e-01	3.1316e-01	1.0000e-01
    25	-2.2706e-01	1.5733e-02	8.3798e-04	1.0000e-01
    50	-1.8660e-01	6.0136e-05	2.0340e-05	1.0000e-01
    75	-1.8660e-01	4.2716e-07	2.9709e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.1866
    Runtime: 0.001s (1.12ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 1.48ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.4471e-01	5.9957e-01	3.1314e-01	1.0000e-01
    25	-2.2717e-01	1.5883e-02	9.0758e-04	1.0000e-01
    50	-1.8663e-01	7.7306e-05	3.4009e-05	1.0000e-01
    75	-1.8633e-01	2.4324e-06	8.2973e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.1863
    Runtime: 0.01s (9.58ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.11ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.4499e-01	5.9957e-01	3.1313e-01	1.0000e-01
    25	-2.2729e-01	1.6036e-02	9.7238e-04	1.0000e-01
    50	-1.8636e-01	1.1160e-04	3.6929e-05	1.0000e-01
    75	-1.8605e-01	2.9166e-07	2.3886e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.1861
    Runtime: 0.001s (0.94ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.12ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.4527e-01	5.9957e-01	3.1312e-01	1.0000e-01
    25	-2.2742e-01	1.6193e-02	1.0325e-03	1.0000e-01
    50	-1.8650e-01	1.4878e-04	8.3142e-05	1.0000e-01
    75	-1.8578e-01	8.9736e-07	2.4911e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.1858
    Runtime: 0.001s (1.2ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.13ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.4554e-01	5.9957e-01	3.1311e-01	1.0000e-01
    25	-2.2755e-01	1.6354e-02	1.0882e-03	1.0000e-01
    50	-1.8662e-01	2.7807e-04	1.2787e-04	1.0000e-01
    75	-1.8550e-01	1.3856e-06	9.8957e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.1855
    Runtime: 0.001s (1.05ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.1ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.4582e-01	5.9957e-01	3.1310e-01	1.0000e-01
    25	-2.2769e-01	1.6519e-02	1.1398e-03	1.0000e-01
    50	-1.8621e-01	2.2811e-04	1.2937e-04	1.0000e-01
    75	-1.8523e-01	7.8947e-06	1.6224e-07	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.1852
    Runtime: 0.001s (0.83ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.13ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.4610e-01	5.9957e-01	3.1309e-01	1.0000e-01
    25	-2.2783e-01	1.6688e-02	1.1877e-03	1.0000e-01
    50	-1.8608e-01	2.7182e-04	1.1695e-04	1.0000e-01
    75	-1.8495e-01	9.5724e-06	3.2618e-07	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.1849
    Runtime: 0.001s (0.98ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.4637e-01	5.9957e-01	3.1308e-01	1.0000e-01
    25	-2.2799e-01	1.6861e-02	1.2327e-03	1.0000e-01
    50	-1.8599e-01	3.3698e-04	1.0959e-04	1.0000e-01
    75	-1.8464e-01	7.5215e-06	2.5345e-07	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.1846
    Runtime: 0.001s (0.87ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.11ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.4665e-01	5.9957e-01	3.1307e-01	1.0000e-01
    25	-2.2815e-01	1.7039e-02	1.2757e-03	1.0000e-01
    50	-1.8591e-01	4.1002e-04	1.0681e-04	1.0000e-01
    75	-1.8433e-01	6.3934e-06	1.1527e-07	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.1843
    Runtime: 0.001s (1.15ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.4692e-01	5.9957e-01	3.1306e-01	1.0000e-01
    25	-2.2833e-01	1.7222e-02	1.3178e-03	1.0000e-01
    50	-1.8585e-01	4.8916e-04	1.0616e-04	1.0000e-01
    75	-1.8401e-01	6.3257e-06	1.2779e-07	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.184
    Runtime: 0.001s (0.85ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.1ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.4720e-01	5.9957e-01	3.1305e-01	1.0000e-01
    25	-2.2851e-01	1.7410e-02	1.3606e-03	1.0000e-01
    50	-1.8588e-01	5.9055e-04	1.1041e-04	1.0000e-01
    75	-1.8369e-01	7.7513e-06	1.6197e-07	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.1837
    Runtime: 0.001s (0.92ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.11ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.4748e-01	5.9957e-01	3.1304e-01	1.0000e-01
    25	-2.2870e-01	1.7603e-02	1.4060e-03	1.0000e-01
    50	-1.8606e-01	7.3497e-04	1.2009e-04	1.0000e-01
    75	-1.8338e-01	1.0646e-05	1.7654e-07	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.1834
    Runtime: 0.001s (0.92ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.4775e-01	5.9957e-01	3.1303e-01	1.0000e-01
    25	-2.2890e-01	1.7801e-02	1.4564e-03	1.0000e-01
    50	-1.8642e-01	9.2041e-04	1.3800e-04	1.0000e-01
    75	-1.8305e-01	1.2259e-05	1.7457e-07	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.1831
    Runtime: 0.001s (0.83ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.1ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.4802e-01	5.9957e-01	3.1302e-01	1.0000e-01
    25	-2.2911e-01	1.8005e-02	1.5147e-03	1.0000e-01
    50	-1.8674e-01	1.0820e-03	1.6311e-04	1.0000e-01
    75	-1.8271e-01	1.5423e-05	7.0153e-07	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 75
    Optimal objective: -0.1827
    Runtime: 0.001s (0.92ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.11ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.4830e-01	5.9957e-01	3.1300e-01	1.0000e-01
    25	-2.2933e-01	1.8214e-02	1.5842e-03	1.0000e-01
    50	-1.8641e-01	1.0281e-03	1.9507e-04	1.0000e-01
    75	-1.8245e-01	3.9026e-05	5.0904e-07	1.0000e-01
    100	-1.8227e-01	5.6606e-06	5.5107e-07	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 101 (incl. 1 safeguarding iter)
    Optimal objective: -0.1823
    Runtime: 0.001s (1.0ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.4857e-01	5.9957e-01	3.1299e-01	1.0000e-01
    25	-2.2956e-01	1.8428e-02	1.6693e-03	1.0000e-01
    50	-1.8571e-01	8.1934e-04	2.2360e-04	1.0000e-01
    75	-1.8199e-01	2.1634e-05	1.1260e-06	1.0000e-01
    100	-1.8189e-01	1.3238e-07	1.9998e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 100
    Optimal objective: -0.1819
    Runtime: 0.001s (1.19ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.12ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.4884e-01	5.9957e-01	3.1298e-01	1.0000e-01
    25	-2.2979e-01	1.8647e-02	1.7752e-03	1.0000e-01
    50	-1.8589e-01	9.8355e-04	2.4594e-04	1.0000e-01
    75	-1.8158e-01	3.0938e-05	2.0133e-06	1.0000e-01
    100	-1.8151e-01	6.0600e-06	1.7262e-06	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 100
    Optimal objective: -0.1815
    Runtime: 0.001s (1.06ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.4912e-01	5.9957e-01	3.1297e-01	1.0000e-01
    25	-2.3002e-01	1.8870e-02	1.9082e-03	1.0000e-01
    50	-1.8591e-01	1.0923e-03	1.7378e-04	1.0000e-01
    75	-1.8280e-01	3.4473e-04	1.7451e-06	1.0000e-01
    100	-1.8109e-01	1.0440e-05	6.0721e-07	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 106 (incl. 6 safeguarding iter)
    Optimal objective: -0.1811
    Runtime: 0.001s (0.95ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.14ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.4939e-01	5.9957e-01	3.1296e-01	1.0000e-01
    25	-2.3026e-01	1.9097e-02	2.0765e-03	1.0000e-01
    50	-1.8565e-01	1.1055e-03	1.5077e-04	1.0000e-01
    75	-1.8117e-01	1.0173e-04	1.3491e-06	1.0000e-01
    100	-1.8068e-01	2.9138e-05	6.7318e-06	1.0000e-01
    125	-1.8062e-01	7.0206e-07	7.0897e-09	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 125
    Optimal objective: -0.1806
    Runtime: 0.001s (1.13ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.4966e-01	5.9957e-01	3.1295e-01	1.0000e-01
    25	-2.3049e-01	1.9325e-02	2.2900e-03	1.0000e-01
    50	-1.8531e-01	1.0808e-03	1.3409e-04	1.0000e-01
    75	-1.8044e-01	4.4291e-05	2.1472e-06	1.0000e-01
    100	-1.8016e-01	8.2131e-07	6.2129e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 100
    Optimal objective: -0.1802
    Runtime: 0.001s (1.07ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.11ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.4993e-01	5.9957e-01	3.1294e-01	1.0000e-01
    25	-2.3071e-01	1.9553e-02	2.5609e-03	1.0000e-01
    50	-1.8483e-01	9.8258e-04	1.2229e-04	1.0000e-01
    75	-1.7970e-01	4.9382e-05	3.9620e-06	1.0000e-01
    100	-1.7970e-01	9.6448e-06	6.4573e-08	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 100
    Optimal objective: -0.1797
    Runtime: 0.001s (1.0ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.5021e-01	5.9957e-01	3.1293e-01	1.0000e-01
    25	-2.3090e-01	1.9776e-02	2.9037e-03	1.0000e-01
    50	-1.8437e-01	8.7979e-04	1.1964e-04	1.0000e-01
    75	-1.8052e-01	2.4016e-04	1.7432e-06	1.0000e-01
    100	-1.7926e-01	5.4365e-05	1.0818e-05	1.0000e-01
    125	-1.7911e-01	4.7544e-06	2.0375e-07	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 128 (incl. 3 safeguarding iter)
    Optimal objective: -0.1791
    Runtime: 0.001s (1.05ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.14ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.5048e-01	5.9957e-01	3.1292e-01	1.0000e-01
    25	-2.3107e-01	1.9989e-02	3.3338e-03	1.0000e-01
    50	-1.8423e-01	9.0560e-04	1.1605e-04	1.0000e-01
    75	-1.8028e-01	2.9187e-04	1.8797e-06	1.0000e-01
    100	-1.7892e-01	7.4904e-05	1.3261e-05	1.0000e-01
    125	-1.7878e-01	4.5539e-05	5.3153e-06	1.1497e+00
    150	-1.7845e-01	2.6689e-09	1.5195e-08	1.1497e+00
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 159 (incl. 9 safeguarding iter)
    Optimal objective: -0.1784
    Runtime: 0.178s (177.82ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.14ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.5075e-01	5.9957e-01	3.1291e-01	1.0000e-01
    25	-2.3120e-01	2.0178e-02	3.8639e-03	1.0000e-01
    50	-1.8441e-01	1.0589e-03	1.2706e-04	1.0000e-01
    75	-1.7916e-01	1.9007e-04	6.7247e-06	1.0000e-01
    100	-1.7805e-01	6.2462e-05	7.9603e-06	1.0000e-01
    125	-1.7775e-01	8.6734e-06	5.7361e-07	1.0000e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 125
    Optimal objective: -0.1778
    Runtime: 0.001s (1.42ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.5102e-01	5.9957e-01	3.1290e-01	1.0000e-01
    25	-2.3126e-01	2.0322e-02	4.4948e-03	1.0000e-01
    50	-1.8479e-01	1.2881e-03	1.2707e-04	1.0000e-01
    75	-1.7821e-01	2.9171e-04	7.3352e-05	1.0000e-01
    100	-1.7827e-01	1.6062e-04	2.6213e-05	8.2169e-01
    125	-1.7756e-01	8.0253e-05	2.8127e-05	8.2169e-01
    150	-1.7671e-01	9.1563e-08	3.4157e-08	8.2169e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 160 (incl. 10 safeguarding iter)
    Optimal objective: -0.1767
    Runtime: 0.001s (1.22ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.09ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.5129e-01	5.9957e-01	3.1289e-01	1.0000e-01
    25	-2.3123e-01	2.0388e-02	5.1992e-03	1.0000e-01
    50	-1.8509e-01	1.4625e-03	1.2957e-04	1.0000e-01
    75	-1.8053e-01	5.8248e-04	6.0174e-06	1.0000e-01
    100	-1.7822e-01	2.9289e-04	3.0717e-05	1.0000e-01
    125	-1.7722e-01	1.4954e-04	4.1950e-07	1.0000e-01
    150	-1.7722e-01	1.4442e-04	5.7248e-07	1.0000e-01
    175	-1.7681e-01	9.6970e-05	1.9022e-06	1.0000e-01
    200	-1.7678e-01	1.0360e-04	3.8881e-07	1.0000e-01
    225	-1.7663e-01	9.2498e-05	6.1338e-08	1.0000e-01
    250	-1.7663e-01	9.2354e-05	3.3486e-06	7.3940e-01
    275	-1.7662e-01	9.1275e-05	1.1926e-06	7.3940e-01
    300	-1.7661e-01	9.1107e-05	2.1314e-06	7.3940e-01
    325	-1.7661e-01	9.0895e-05	2.1057e-06	7.3940e-01
    350	-1.7661e-01	9.0684e-05	2.0952e-06	7.3940e-01
    375	-1.7660e-01	9.0474e-05	2.0847e-06	7.3940e-01
    400	-1.7660e-01	9.0265e-05	2.0742e-06	7.3940e-01
    425	-1.7660e-01	9.0058e-05	2.0639e-06	7.3940e-01
    450	-1.7660e-01	8.9852e-05	2.0536e-06	7.3940e-01
    475	-1.7659e-01	8.9647e-05	2.0434e-06	7.3940e-01
    500	-1.7659e-01	8.9444e-05	2.0333e-06	7.3940e-01
    525	-1.7531e-01	1.6916e-05	5.2233e-05	7.3940e-01
    550	-1.7530e-01	4.2242e-07	1.1297e-07	7.3940e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 566 (incl. 16 safeguarding iter)
    Optimal objective: -0.1753
    Runtime: 0.088s (88.23ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.12ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.5156e-01	5.9957e-01	3.1288e-01	1.0000e-01
    25	-2.3111e-01	2.0334e-02	5.8996e-03	1.0000e-01
    50	-1.8495e-01	1.5207e-03	1.6414e-04	1.0000e-01
    75	-1.7963e-01	5.3190e-04	3.1117e-06	1.0000e-01
    100	-1.7832e-01	3.9649e-04	1.9565e-04	1.0000e-01
    125	-1.7771e-01	2.8611e-04	1.4327e-05	7.8921e-01
    150	-1.7734e-01	2.4920e-04	9.1287e-06	7.8921e-01
    175	-1.7732e-01	2.4801e-04	1.0675e-05	7.8921e-01
    200	-1.7731e-01	2.4676e-04	1.0488e-05	7.8921e-01
    225	-1.7729e-01	2.4554e-04	1.0332e-05	7.8921e-01
    250	-1.7728e-01	2.4434e-04	1.0180e-05	7.8921e-01
    275	-1.7727e-01	2.4316e-04	1.0032e-05	7.8921e-01
    300	-1.7726e-01	2.4201e-04	9.8870e-06	7.8921e-01
    325	-1.7724e-01	2.4087e-04	9.7462e-06	7.8921e-01
    350	-1.7723e-01	2.3976e-04	9.6088e-06	7.8921e-01
    375	-1.7722e-01	2.3867e-04	9.4748e-06	7.8921e-01
    400	-1.7721e-01	2.3760e-04	9.3441e-06	7.8921e-01
    425	-1.7719e-01	2.3654e-04	9.2166e-06	7.8921e-01
    450	-1.7718e-01	2.3551e-04	9.0921e-06	7.8921e-01
    475	-1.7717e-01	2.3449e-04	8.9706e-06	7.8921e-01
    500	-1.7716e-01	2.3349e-04	8.8519e-06	7.8921e-01
    525	-1.7715e-01	2.3251e-04	8.7359e-06	7.8921e-01
    550	-1.7714e-01	2.3155e-04	8.6226e-06	7.8921e-01
    575	-1.7713e-01	2.3060e-04	8.5119e-06	7.8921e-01
    600	-1.7712e-01	2.2967e-04	8.4036e-06	7.8921e-01
    625	-1.7710e-01	2.2875e-04	8.2978e-06	7.8921e-01
    650	-1.7709e-01	2.2785e-04	8.1943e-06	7.8921e-01
    675	-1.7708e-01	2.2697e-04	8.0931e-06	7.8921e-01
    700	-1.7707e-01	2.2609e-04	7.9940e-06	7.8921e-01
    725	-1.7706e-01	2.2524e-04	7.8971e-06	7.8921e-01
    750	-1.7705e-01	2.2439e-04	7.8023e-06	7.8921e-01
    775	-1.7704e-01	2.2356e-04	7.7094e-06	7.8921e-01
    800	-1.7703e-01	2.2274e-04	7.6185e-06	7.8921e-01
    825	-1.7702e-01	2.2194e-04	7.5294e-06	7.8921e-01
    850	-1.7701e-01	2.2114e-04	7.4422e-06	7.8921e-01
    875	-1.7700e-01	2.2036e-04	7.3567e-06	7.8921e-01
    900	-1.7700e-01	2.1959e-04	7.2729e-06	7.8921e-01
    925	-1.7699e-01	2.1884e-04	7.1909e-06	7.8921e-01
    950	-1.7698e-01	2.1809e-04	7.1104e-06	7.8921e-01
    975	-1.7697e-01	2.1736e-04	7.0315e-06	7.8921e-01
    1000	-1.7696e-01	2.1663e-04	6.9542e-06	7.8921e-01
    1025	-1.7695e-01	2.1592e-04	6.8783e-06	7.8921e-01
    1050	-1.7694e-01	2.1521e-04	6.8039e-06	7.8921e-01
    1075	-1.7693e-01	2.1452e-04	6.7309e-06	7.8921e-01
    1100	-1.7692e-01	2.1384e-04	6.6592e-06	7.8921e-01
    1125	-1.7692e-01	2.1316e-04	6.5889e-06	7.8921e-01
    1150	-1.7691e-01	2.1250e-04	6.5199e-06	7.8921e-01
    1175	-1.7690e-01	2.1184e-04	6.4522e-06	7.8921e-01
    1200	-1.7689e-01	2.1120e-04	6.3857e-06	7.8921e-01
    1225	-1.7688e-01	2.1056e-04	6.3203e-06	7.8921e-01
    1250	-1.7688e-01	2.0993e-04	6.2562e-06	7.8921e-01
    1275	-1.7687e-01	2.0931e-04	6.1932e-06	7.8921e-01
    1300	-1.7686e-01	2.0870e-04	6.1313e-06	7.8921e-01
    1325	-1.7685e-01	2.0809e-04	6.0705e-06	7.8921e-01
    1350	-1.7684e-01	2.0750e-04	6.0107e-06	7.8921e-01
    1375	-1.7684e-01	2.0691e-04	5.9520e-06	7.8921e-01
    1400	-1.7683e-01	2.0633e-04	5.8943e-06	7.8921e-01
    1425	-1.7682e-01	2.0575e-04	5.8375e-06	7.8921e-01
    1450	-1.7681e-01	2.0519e-04	5.7817e-06	7.8921e-01
    1475	-1.7681e-01	2.0463e-04	5.7268e-06	7.8921e-01
    1500	-1.7680e-01	2.0408e-04	5.6729e-06	7.8921e-01
    1525	-1.7679e-01	2.0353e-04	5.6198e-06	7.8921e-01
    1550	-1.7679e-01	2.0299e-04	5.5676e-06	7.8921e-01
    1575	-1.7678e-01	2.0246e-04	5.5163e-06	7.8921e-01
    1600	-1.7677e-01	2.0194e-04	5.4657e-06	7.8921e-01
    1625	-1.7676e-01	2.0142e-04	5.4160e-06	7.8921e-01
    1650	-1.7676e-01	2.0091e-04	5.3671e-06	7.8921e-01
    1675	-1.7675e-01	2.0040e-04	5.3189e-06	7.8921e-01
    1700	-1.7674e-01	1.9990e-04	1.0933e-05	7.8921e-01
    1725	-1.7598e-01	1.4913e-04	3.7542e-05	7.8921e-01
    1750	-1.7411e-01	2.2211e-05	1.4354e-05	7.8921e-01
    1775	-1.7364e-01	3.7764e-07	3.7349e-07	7.8921e-01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 1811 (incl. 36 safeguarding iter)
    Optimal objective: -0.1736
    Runtime: 0.009s (8.93ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.11ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.5183e-01	5.9957e-01	3.1287e-01	1.0000e-01
    25	-2.3092e-01	2.2085e-02	6.4576e-03	1.0000e-01
    50	-1.8356e-01	1.1672e-03	1.5679e-04	1.0000e-01
    75	-1.7991e-01	6.7360e-04	2.5292e-06	1.0000e-01
    100	-1.7802e-01	4.0655e-04	3.6364e-04	1.0000e-01
    125	-1.7700e-01	3.3353e-04	8.0557e-06	1.0000e-01
    150	-1.7696e-01	3.0771e-04	1.3564e-06	1.0000e-01
    175	-1.7696e-01	3.1401e-04	1.1344e-04	2.0129e+00
    200	-1.7671e-01	2.9644e-04	1.3239e-04	2.0129e+00
    225	-1.7558e-01	2.1717e-04	6.7102e-05	2.0129e+00
    250	-1.7551e-01	2.1251e-04	7.0157e-05	2.0129e+00
    275	-1.7545e-01	2.0814e-04	6.7618e-05	2.0129e+00
    300	-1.7538e-01	2.0395e-04	6.5230e-05	2.0129e+00
    325	-1.7532e-01	1.9993e-04	6.2981e-05	2.0129e+00
    350	-1.7526e-01	1.9608e-04	6.0861e-05	2.0129e+00
    375	-1.7521e-01	1.9238e-04	5.8858e-05	2.0129e+00
    400	-1.7515e-01	1.8882e-04	5.6965e-05	2.0129e+00
    425	-1.7510e-01	1.8540e-04	5.5172e-05	2.0129e+00
    450	-1.7504e-01	1.8210e-04	5.3472e-05	2.0129e+00
    475	-1.7499e-01	1.7892e-04	5.1860e-05	2.0129e+00
    500	-1.7494e-01	1.7586e-04	5.0327e-05	2.0129e+00
    525	-1.7490e-01	1.7290e-04	4.8869e-05	2.0129e+00
    550	-1.7485e-01	1.7004e-04	4.7482e-05	2.0129e+00
    575	-1.7481e-01	1.6727e-04	4.6159e-05	2.0129e+00
    600	-1.7476e-01	1.6460e-04	4.4897e-05	2.0129e+00
    625	-1.7472e-01	1.6201e-04	4.3692e-05	2.0129e+00
    650	-1.7468e-01	1.5950e-04	4.2541e-05	2.0129e+00
    675	-1.7464e-01	1.5707e-04	4.1439e-05	2.0129e+00
    700	-1.7460e-01	1.5471e-04	4.0385e-05	2.0129e+00
    725	-1.7456e-01	1.5242e-04	3.9375e-05	2.0129e+00
    750	-1.7452e-01	1.5020e-04	3.8406e-05	2.0129e+00
    775	-1.7449e-01	1.4805e-04	3.7477e-05	2.0129e+00
    800	-1.7445e-01	1.4595e-04	3.6585e-05	2.0129e+00
    825	-1.7442e-01	1.4392e-04	3.5728e-05	2.0129e+00
    850	-1.7438e-01	1.4194e-04	3.4904e-05	2.0129e+00
    875	-1.7435e-01	1.4001e-04	3.4111e-05	2.0129e+00
    900	-1.7432e-01	1.3813e-04	3.3348e-05	2.0129e+00
    925	-1.7429e-01	1.3630e-04	3.2613e-05	2.0129e+00
    950	-1.7426e-01	1.3452e-04	3.1905e-05	2.0129e+00
    975	-1.7423e-01	1.3279e-04	3.1222e-05	2.0129e+00
    1000	-1.7420e-01	1.3110e-04	3.0563e-05	2.0129e+00
    1025	-1.7417e-01	1.2945e-04	2.9927e-05	2.0129e+00
    1050	-1.7414e-01	1.2784e-04	2.9312e-05	2.0129e+00
    1075	-1.7411e-01	1.2626e-04	2.8719e-05	2.0129e+00
    1100	-1.7408e-01	1.2473e-04	2.8145e-05	2.0129e+00
    1125	-1.7406e-01	1.2323e-04	2.7590e-05	2.0129e+00
    1150	-1.7403e-01	1.2177e-04	2.7052e-05	2.0129e+00
    1175	-1.7401e-01	1.2033e-04	2.6532e-05	2.0129e+00
    1200	-1.7398e-01	1.1894e-04	2.6029e-05	2.0129e+00
    1225	-1.7396e-01	1.1757e-04	2.5541e-05	2.0129e+00
    1250	-1.7393e-01	1.1623e-04	2.5068e-05	2.0129e+00
    1275	-1.7391e-01	1.1492e-04	2.4609e-05	2.0129e+00
    1300	-1.7389e-01	1.1364e-04	2.4164e-05	2.0129e+00
    1325	-1.7386e-01	1.1238e-04	2.3732e-05	2.0129e+00
    1350	-1.7384e-01	1.1115e-04	2.3313e-05	2.0129e+00
    1375	-1.7382e-01	1.0995e-04	2.2906e-05	2.0129e+00
    1400	-1.7380e-01	1.0877e-04	2.2510e-05	2.0129e+00
    1425	-1.7378e-01	1.0762e-04	2.2126e-05	2.0129e+00
    1450	-1.7375e-01	1.0648e-04	2.1752e-05	2.0129e+00
    1475	-1.7373e-01	1.0537e-04	2.1389e-05	2.0129e+00
    1500	-1.7371e-01	1.0429e-04	2.1035e-05	2.0129e+00
    1525	-1.7369e-01	1.0322e-04	2.0691e-05	2.0129e+00
    1550	-1.7367e-01	1.0217e-04	2.0357e-05	2.0129e+00
    1575	-1.7365e-01	1.0114e-04	2.0031e-05	2.0129e+00
    1600	-1.7364e-01	1.0013e-04	1.9713e-05	2.0129e+00
    1625	-1.7362e-01	9.9144e-05	1.9404e-05	2.0129e+00
    1650	-1.7360e-01	9.8172e-05	1.9102e-05	2.0129e+00
    1675	-1.7358e-01	9.7218e-05	1.8809e-05	2.0129e+00
    1700	-1.7356e-01	9.6280e-05	1.8522e-05	2.0129e+00
    1725	-1.7355e-01	9.5359e-05	1.8243e-05	2.0129e+00
    1750	-1.7353e-01	9.4454e-05	1.7970e-05	2.0129e+00
    1775	-1.7351e-01	9.3565e-05	1.7704e-05	2.0129e+00
    1800	-1.7349e-01	9.2691e-05	1.7444e-05	2.0129e+00
    1825	-1.7348e-01	9.1832e-05	1.7191e-05	2.0129e+00
    1850	-1.7346e-01	9.0987e-05	1.6944e-05	2.0129e+00
    1875	-1.7345e-01	9.0156e-05	1.6702e-05	2.0129e+00
    1900	-1.7343e-01	8.9339e-05	1.6466e-05	2.0129e+00
    1925	-1.7341e-01	8.8535e-05	1.6235e-05	2.0129e+00
    1950	-1.7340e-01	8.7745e-05	1.6009e-05	2.0129e+00
    1975	-1.7338e-01	8.6967e-05	1.5789e-05	2.0129e+00
    2000	-1.7337e-01	8.6201e-05	1.5573e-05	2.0129e+00
    2025	-1.7335e-01	8.5448e-05	1.5363e-05	2.0129e+00
    2050	-1.7334e-01	8.4706e-05	1.5156e-05	2.0129e+00
    2075	-1.7333e-01	8.3976e-05	1.4955e-05	2.0129e+00
    2100	-1.7331e-01	8.3256e-05	1.4757e-05	2.0129e+00
    2125	-1.7330e-01	8.2548e-05	1.4564e-05	2.0129e+00
    2150	-1.7328e-01	8.1851e-05	1.4375e-05	2.0129e+00
    2175	-1.7327e-01	8.1164e-05	1.4189e-05	2.0129e+00
    2200	-1.7326e-01	8.0487e-05	1.4008e-05	2.0129e+00
    2225	-1.7324e-01	7.9820e-05	1.3830e-05	2.0129e+00
    2250	-1.7323e-01	7.9163e-05	1.3656e-05	2.0129e+00
    2275	-1.7322e-01	7.8516e-05	1.3486e-05	2.0129e+00
    2300	-1.7320e-01	7.7878e-05	1.3319e-05	2.0129e+00
    2325	-1.7319e-01	7.7248e-05	1.3155e-05	2.0129e+00
    2350	-1.7318e-01	7.6628e-05	1.2994e-05	2.0129e+00
    2375	-1.7317e-01	7.6017e-05	1.2837e-05	2.0129e+00
    2400	-1.7316e-01	7.5414e-05	1.2682e-05	2.0129e+00
    2425	-1.7314e-01	7.4819e-05	1.2531e-05	2.0129e+00
    2450	-1.7313e-01	7.4232e-05	1.2382e-05	2.0129e+00
    2475	-1.7312e-01	7.3654e-05	1.2237e-05	2.0129e+00
    2500	-1.7311e-01	7.3083e-05	1.2094e-05	2.0129e+00
    2525	-1.7310e-01	7.2520e-05	1.1953e-05	2.0129e+00
    2550	-1.7309e-01	7.1964e-05	1.1816e-05	2.0129e+00
    2575	-1.7307e-01	7.1416e-05	1.1680e-05	2.0129e+00
    2600	-1.7306e-01	7.0875e-05	1.1548e-05	2.0129e+00
    2625	-1.7305e-01	7.0341e-05	1.1417e-05	2.0129e+00
    2650	-1.7304e-01	6.9814e-05	1.1289e-05	2.0129e+00
    2675	-1.7303e-01	6.9294e-05	1.1164e-05	2.0129e+00
    2700	-1.7302e-01	6.8780e-05	1.1040e-05	2.0129e+00
    2725	-1.7301e-01	6.8273e-05	1.0919e-05	2.0129e+00
    2750	-1.7300e-01	6.7772e-05	1.0800e-05	2.0129e+00
    2775	-1.7299e-01	6.7278e-05	1.0682e-05	2.0129e+00
    2800	-1.7298e-01	6.6789e-05	1.0567e-05	2.0129e+00
    2825	-1.7297e-01	6.6307e-05	1.0454e-05	2.0129e+00
    2850	-1.7296e-01	6.5831e-05	1.0343e-05	2.0129e+00
    2875	-1.7295e-01	6.5360e-05	1.0233e-05	2.0129e+00
    2900	-1.7294e-01	6.4895e-05	1.0126e-05	2.0129e+00
    2925	-1.7293e-01	6.4436e-05	1.0020e-05	2.0129e+00
    2950	-1.7292e-01	6.3982e-05	9.9161e-06	2.0129e+00
    2975	-1.7291e-01	6.3533e-05	9.8138e-06	2.0129e+00
    3000	-1.7290e-01	6.3090e-05	9.7132e-06	2.0129e+00
    3025	-1.7289e-01	6.2652e-05	9.6142e-06	2.0129e+00
    3050	-1.7288e-01	6.2219e-05	9.5167e-06	2.0129e+00
    3075	-1.7288e-01	6.1791e-05	9.4208e-06	2.0129e+00
    3100	-1.7287e-01	6.1368e-05	9.3265e-06	2.0129e+00
    3125	-1.7286e-01	6.0950e-05	9.2336e-06	2.0129e+00
    3150	-1.7285e-01	6.0536e-05	9.1422e-06	2.0129e+00
    3175	-1.7284e-01	6.0128e-05	9.0522e-06	2.0129e+00
    3200	-1.7283e-01	5.9723e-05	8.9636e-06	2.0129e+00
    3225	-1.7282e-01	5.9324e-05	8.8764e-06	2.0129e+00
    3250	-1.7281e-01	5.8928e-05	8.7905e-06	2.0129e+00
    3275	-1.7281e-01	5.8537e-05	8.7059e-06	2.0129e+00
    3300	-1.7280e-01	5.8151e-05	8.6225e-06	2.0129e+00
    3325	-1.7279e-01	5.7768e-05	8.5404e-06	2.0129e+00
    3350	-1.7278e-01	5.7390e-05	8.4596e-06	2.0129e+00
    3375	-1.7277e-01	5.7016e-05	8.3799e-06	2.0129e+00
    3400	-1.7277e-01	5.6646e-05	8.3014e-06	2.0129e+00
    3425	-1.7276e-01	5.6279e-05	8.2241e-06	2.0129e+00
    3450	-1.7275e-01	5.5917e-05	8.1479e-06	2.0129e+00
    3475	-1.7274e-01	5.5558e-05	8.0728e-06	2.0129e+00
    3500	-1.7274e-01	5.5204e-05	7.9987e-06	2.0129e+00
    3525	-1.7273e-01	5.4852e-05	7.9257e-06	2.0129e+00
    3550	-1.7272e-01	5.4505e-05	7.8538e-06	2.0129e+00
    3575	-1.7271e-01	5.4161e-05	7.7829e-06	2.0129e+00
    3600	-1.7271e-01	5.3821e-05	7.7130e-06	2.0129e+00
    3625	-1.7270e-01	5.3484e-05	7.6440e-06	2.0129e+00
    3650	-1.7269e-01	5.3150e-05	7.5760e-06	2.0129e+00
    3675	-1.7268e-01	5.2820e-05	7.5090e-06	2.0129e+00
    3700	-1.7268e-01	5.2493e-05	7.4428e-06	2.0129e+00
    3725	-1.7267e-01	5.2170e-05	7.3776e-06	2.0129e+00
    3750	-1.7266e-01	5.1849e-05	7.3132e-06	2.0129e+00
    3775	-1.7266e-01	5.1532e-05	7.2498e-06	2.0129e+00
    3800	-1.7265e-01	5.1218e-05	7.1871e-06	2.0129e+00
    3825	-1.7264e-01	5.0907e-05	7.1254e-06	2.0129e+00
    3850	-1.7264e-01	5.0599e-05	7.0644e-06	2.0129e+00
    3875	-1.7263e-01	5.0294e-05	7.0042e-06	2.0129e+00
    3900	-1.7262e-01	4.9992e-05	6.9449e-06	2.0129e+00
    3925	-1.7262e-01	4.9693e-05	6.8863e-06	2.0129e+00
    3950	-1.7261e-01	4.9396e-05	6.8285e-06	2.0129e+00
    3975	-1.7260e-01	4.9103e-05	6.7714e-06	2.0129e+00
    4000	-1.7260e-01	4.8812e-05	6.7150e-06	2.0129e+00
    4025	-1.7259e-01	4.8524e-05	6.6594e-06	2.0129e+00
    4050	-1.7258e-01	4.8239e-05	6.6045e-06	2.0129e+00
    4075	-1.7258e-01	4.7956e-05	6.5503e-06	2.0129e+00
    4100	-1.7257e-01	4.7676e-05	6.4967e-06	2.0129e+00
    4125	-1.7257e-01	4.7398e-05	6.4439e-06	2.0129e+00
    4150	-1.7256e-01	4.7123e-05	6.3917e-06	2.0129e+00
    4175	-1.7255e-01	4.6851e-05	6.3401e-06	2.0129e+00
    4200	-1.7255e-01	4.6581e-05	6.2892e-06	2.0129e+00
    4225	-1.7254e-01	4.6314e-05	6.2389e-06	2.0129e+00
    4250	-1.7254e-01	4.6048e-05	6.1892e-06	2.0129e+00
    4275	-1.7253e-01	4.5786e-05	6.1402e-06	2.0129e+00
    4300	-1.7252e-01	4.5525e-05	6.0917e-06	2.0129e+00
    4325	-1.7252e-01	4.5267e-05	6.0438e-06	2.0129e+00
    4350	-1.7251e-01	4.5011e-05	5.9965e-06	2.0129e+00
    4375	-1.7251e-01	4.4758e-05	5.9498e-06	2.0129e+00
    4400	-1.7250e-01	4.4507e-05	5.9036e-06	2.0129e+00
    4425	-1.7250e-01	4.4258e-05	5.8579e-06	2.0129e+00
    4450	-1.7249e-01	4.4011e-05	5.8128e-06	2.0129e+00
    4475	-1.7248e-01	4.3766e-05	5.7682e-06	2.0129e+00
    4500	-1.7248e-01	4.3523e-05	5.7242e-06	2.0129e+00
    4525	-1.7247e-01	4.3282e-05	5.6806e-06	2.0129e+00
    4550	-1.7247e-01	4.3044e-05	5.6376e-06	2.0129e+00
    4575	-1.7246e-01	4.2807e-05	5.5950e-06	2.0129e+00
    4600	-1.7246e-01	4.2573e-05	5.5530e-06	2.0129e+00
    4625	-1.7245e-01	4.2340e-05	5.5114e-06	2.0129e+00
    4650	-1.7245e-01	4.2110e-05	5.4703e-06	2.0129e+00
    4675	-1.7244e-01	4.1881e-05	5.4296e-06	2.0129e+00
    4700	-1.7244e-01	4.1654e-05	5.3895e-06	2.0129e+00
    4725	-1.7243e-01	4.1429e-05	5.3497e-06	2.0129e+00
    4750	-1.7243e-01	4.1206e-05	5.3104e-06	2.0129e+00
    4775	-1.7242e-01	4.0985e-05	5.2716e-06	2.0129e+00
    4800	-1.7242e-01	4.0766e-05	5.2332e-06	2.0129e+00
    4825	-1.7241e-01	4.0548e-05	5.1951e-06	2.0129e+00
    4850	-1.7241e-01	4.0332e-05	5.1576e-06	2.0129e+00
    4875	-1.7240e-01	4.0118e-05	5.1204e-06	2.0129e+00
    4900	-1.7240e-01	3.9906e-05	5.0836e-06	2.0129e+00
    4925	-1.7239e-01	3.9695e-05	5.0472e-06	2.0129e+00
    4950	-1.7239e-01	3.9486e-05	5.0112e-06	2.0129e+00
    4975	-1.7238e-01	3.9279e-05	4.9757e-06	2.0129e+00
    5000	-1.7238e-01	3.9073e-05	4.9404e-06	2.0129e+00
    5025	-1.7237e-01	3.8869e-05	4.9056e-06	2.0129e+00
    5050	-1.7237e-01	3.8667e-05	4.8711e-06	2.0129e+00
    5075	-1.7236e-01	3.8466e-05	4.8370e-06	2.0129e+00
    5100	-1.7236e-01	3.8266e-05	4.8033e-06	2.0129e+00
    5125	-1.7236e-01	3.8069e-05	4.7699e-06	2.0129e+00
    5150	-1.7235e-01	3.7873e-05	4.7368e-06	2.0129e+00
    5175	-1.7235e-01	3.7678e-05	4.7041e-06	2.0129e+00
    5200	-1.7234e-01	3.7485e-05	4.6717e-06	2.0129e+00
    5225	-1.7234e-01	3.7293e-05	4.6397e-06	2.0129e+00
    5250	-1.7233e-01	3.7103e-05	4.6080e-06	2.0129e+00
    5275	-1.7233e-01	3.6914e-05	4.5766e-06	2.0129e+00
    5300	-1.7232e-01	3.6727e-05	4.5455e-06	2.0129e+00
    5325	-1.7232e-01	3.6541e-05	4.5148e-06	2.0129e+00
    5350	-1.7232e-01	3.6356e-05	4.4843e-06	2.0129e+00
    5375	-1.7231e-01	3.6173e-05	4.4542e-06	2.0129e+00
    5400	-1.7231e-01	3.5991e-05	4.4243e-06	2.0129e+00
    5425	-1.7230e-01	3.5811e-05	4.3948e-06	2.0129e+00
    5450	-1.7230e-01	3.5632e-05	4.3656e-06	2.0129e+00
    5475	-1.7230e-01	3.5454e-05	4.3366e-06	2.0129e+00
    5500	-1.7229e-01	3.5278e-05	4.3079e-06	2.0129e+00
    5525	-1.7229e-01	3.5102e-05	4.2795e-06	2.0129e+00
    5550	-1.7228e-01	3.4929e-05	4.2514e-06	2.0129e+00
    5575	-1.7228e-01	3.4756e-05	4.2236e-06	2.0129e+00
    5600	-1.7227e-01	3.4585e-05	4.1960e-06	2.0129e+00
    5625	-1.7227e-01	3.4414e-05	4.1687e-06	2.0129e+00
    5650	-1.7227e-01	3.4246e-05	4.1417e-06	2.0129e+00
    5675	-1.7226e-01	3.4078e-05	4.1149e-06	2.0129e+00
    5700	-1.7226e-01	3.3912e-05	4.0884e-06	2.0129e+00
    5725	-1.7226e-01	3.3746e-05	4.0621e-06	2.0129e+00
    5750	-1.7225e-01	3.3582e-05	4.0361e-06	2.0129e+00
    5775	-1.7225e-01	3.3419e-05	4.0103e-06	2.0129e+00
    5800	-1.7224e-01	3.3257e-05	3.9848e-06	2.0129e+00
    5825	-1.7224e-01	3.3097e-05	3.9595e-06	2.0129e+00
    5850	-1.7224e-01	3.2937e-05	3.9344e-06	2.0129e+00
    5875	-1.7223e-01	3.2779e-05	3.9096e-06	2.0129e+00
    5900	-1.7223e-01	3.2622e-05	3.8850e-06	2.0129e+00
    5925	-1.7223e-01	3.2466e-05	3.8606e-06	2.0129e+00
    5950	-1.7222e-01	3.2310e-05	3.8365e-06	2.0129e+00
    5975	-1.7222e-01	3.2156e-05	3.8126e-06	2.0129e+00
    6000	-1.7221e-01	3.2003e-05	3.7889e-06	2.0129e+00
    6025	-1.7221e-01	3.1852e-05	3.7654e-06	2.0129e+00
    6050	-1.7221e-01	3.1701e-05	3.7421e-06	2.0129e+00
    6075	-1.7220e-01	3.1551e-05	3.7191e-06	2.0129e+00
    6100	-1.7220e-01	3.1402e-05	3.6962e-06	2.0129e+00
    6125	-1.7220e-01	3.1254e-05	3.6736e-06	2.0129e+00
    6150	-1.7219e-01	3.1107e-05	3.6511e-06	2.0129e+00
    6175	-1.7219e-01	3.0962e-05	3.6289e-06	2.0129e+00
    6200	-1.7219e-01	3.0817e-05	3.6068e-06	2.0129e+00
    6225	-1.7218e-01	3.0673e-05	3.5850e-06	2.0129e+00
    6250	-1.7218e-01	3.0530e-05	3.5633e-06	2.0129e+00
    6275	-1.7218e-01	3.0388e-05	3.5418e-06	2.0129e+00
    6300	-1.7217e-01	3.0247e-05	3.5206e-06	2.0129e+00
    6325	-1.7217e-01	3.0107e-05	3.4995e-06	2.0129e+00
    6350	-1.7217e-01	2.9968e-05	3.4785e-06	2.0129e+00
    6375	-1.7216e-01	2.9830e-05	3.4578e-06	2.0129e+00
    6400	-1.7216e-01	2.9692e-05	3.4373e-06	2.0129e+00
    6425	-1.7216e-01	2.9556e-05	3.4169e-06	2.0129e+00
    6450	-1.7215e-01	2.9420e-05	3.3967e-06	2.0129e+00
    6475	-1.7215e-01	2.9286e-05	3.3767e-06	2.0129e+00
    6500	-1.7215e-01	2.9152e-05	3.3568e-06	2.0129e+00
    6525	-1.7214e-01	2.9019e-05	3.3371e-06	2.0129e+00
    6550	-1.7214e-01	2.8887e-05	3.3176e-06	2.0129e+00
    6575	-1.7214e-01	2.8756e-05	3.2983e-06	2.0129e+00
    6600	-1.7213e-01	2.8626e-05	3.2791e-06	2.0129e+00
    6625	-1.7213e-01	2.8496e-05	3.2601e-06	2.0129e+00
    6650	-1.7213e-01	2.8367e-05	3.2412e-06	2.0129e+00
    6675	-1.7213e-01	2.8240e-05	3.2225e-06	2.0129e+00
    6700	-1.7212e-01	2.8112e-05	3.2039e-06	2.0129e+00
    6725	-1.7212e-01	2.7986e-05	3.1855e-06	2.0129e+00
    6750	-1.7212e-01	2.7861e-05	3.1673e-06	2.0129e+00
    6775	-1.7211e-01	2.7736e-05	3.1492e-06	2.0129e+00
    6800	-1.7211e-01	2.7612e-05	3.1312e-06	2.0129e+00
    6825	-1.7211e-01	2.7489e-05	3.1134e-06	2.0129e+00
    6850	-1.7210e-01	2.7367e-05	3.0958e-06	2.0129e+00
    6875	-1.7210e-01	2.7245e-05	3.0782e-06	2.0129e+00
    6900	-1.7210e-01	2.7124e-05	3.0609e-06	2.0129e+00
    6925	-1.7210e-01	2.7004e-05	3.0436e-06	2.0129e+00
    6950	-1.7209e-01	2.6885e-05	3.0266e-06	2.0129e+00
    6975	-1.7209e-01	2.6766e-05	3.0096e-06	2.0129e+00
    7000	-1.7209e-01	2.6648e-05	2.9928e-06	2.0129e+00
    7025	-1.7208e-01	2.6531e-05	2.9761e-06	2.0129e+00
    7050	-1.7208e-01	2.6415e-05	2.9595e-06	2.0129e+00
    7075	-1.7208e-01	2.6299e-05	2.9431e-06	2.0129e+00
    7100	-1.7208e-01	2.6184e-05	2.9268e-06	2.0129e+00
    7125	-1.7207e-01	2.6070e-05	2.9107e-06	2.0129e+00
    7150	-1.7207e-01	2.5956e-05	2.8946e-06	2.0129e+00
    7175	-1.7207e-01	2.5843e-05	2.8787e-06	2.0129e+00
    7200	-1.7207e-01	2.5731e-05	2.8630e-06	2.0129e+00
    7225	-1.7206e-01	2.5619e-05	2.8473e-06	2.0129e+00
    7250	-1.7206e-01	2.5508e-05	2.8318e-06	2.0129e+00
    7275	-1.7206e-01	2.5398e-05	2.8163e-06	2.0129e+00
    7300	-1.7205e-01	2.5289e-05	2.8010e-06	2.0129e+00
    7325	-1.7205e-01	2.5180e-05	2.7859e-06	2.0129e+00
    7350	-1.7205e-01	2.5071e-05	2.7708e-06	2.0129e+00
    7375	-1.7205e-01	2.4964e-05	2.7558e-06	2.0129e+00
    7400	-1.7204e-01	2.4857e-05	2.7410e-06	2.0129e+00
    7425	-1.7204e-01	2.4750e-05	2.7263e-06	2.0129e+00
    7450	-1.7204e-01	2.4644e-05	2.7117e-06	2.0129e+00
    7475	-1.7204e-01	2.4539e-05	2.6972e-06	2.0129e+00
    7500	-1.7203e-01	2.4435e-05	2.6828e-06	2.0129e+00
    7525	-1.7203e-01	2.4331e-05	2.6685e-06	2.0129e+00
    7550	-1.7203e-01	2.4227e-05	2.6543e-06	2.0129e+00
    7575	-1.7203e-01	2.4125e-05	2.6403e-06	2.0129e+00
    7600	-1.7202e-01	2.4022e-05	2.6263e-06	2.0129e+00
    7625	-1.7202e-01	2.3921e-05	2.6125e-06	2.0129e+00
    7650	-1.7202e-01	2.3820e-05	2.5987e-06	2.0129e+00
    7675	-1.7202e-01	2.3720e-05	2.5851e-06	2.0129e+00
    7700	-1.7201e-01	2.3620e-05	2.5715e-06	2.0129e+00
    7725	-1.7201e-01	2.3520e-05	2.5581e-06	2.0129e+00
    7750	-1.7201e-01	2.3422e-05	2.5447e-06	2.0129e+00
    7775	-1.7201e-01	2.3324e-05	2.5314e-06	2.0129e+00
    7800	-1.7200e-01	2.3226e-05	2.5183e-06	2.0129e+00
    7825	-1.7200e-01	2.3129e-05	2.5052e-06	2.0129e+00
    7850	-1.7200e-01	2.3033e-05	2.4923e-06	2.0129e+00
    7875	-1.7200e-01	2.2937e-05	2.4794e-06	2.0129e+00
    7900	-1.7199e-01	2.2841e-05	2.4666e-06	2.0129e+00
    7925	-1.7199e-01	2.2746e-05	2.4539e-06	2.0129e+00
    7950	-1.7199e-01	2.2652e-05	2.4413e-06	2.0129e+00
    7975	-1.7199e-01	2.2558e-05	2.4288e-06	2.0129e+00
    8000	-1.7199e-01	2.2465e-05	2.4164e-06	2.0129e+00
    8025	-1.7198e-01	2.2372e-05	2.4041e-06	2.0129e+00
    8050	-1.7198e-01	2.2280e-05	2.3918e-06	2.0129e+00
    8075	-1.7198e-01	2.2188e-05	2.3797e-06	2.0129e+00
    8100	-1.7198e-01	2.2097e-05	2.3676e-06	2.0129e+00
    8125	-1.7197e-01	2.2006e-05	2.3556e-06	2.0129e+00
    8150	-1.7197e-01	2.1916e-05	2.3437e-06	2.0129e+00
    8175	-1.7197e-01	2.1826e-05	2.3319e-06	2.0129e+00
    8200	-1.7197e-01	2.1737e-05	2.3202e-06	2.0129e+00
    8225	-1.7197e-01	2.1648e-05	2.3085e-06	2.0129e+00
    8250	-1.7196e-01	2.1560e-05	2.2970e-06	2.0129e+00
    8275	-1.7196e-01	2.1472e-05	2.2855e-06	2.0129e+00
    8300	-1.7196e-01	2.1385e-05	2.2741e-06	2.0129e+00
    8325	-1.7196e-01	2.1298e-05	2.2628e-06	2.0129e+00
    8350	-1.7195e-01	2.1212e-05	2.2515e-06	2.0129e+00
    8375	-1.7195e-01	2.1126e-05	2.2403e-06	2.0129e+00
    8400	-1.7195e-01	2.1041e-05	2.2292e-06	2.0129e+00
    8425	-1.7195e-01	2.0956e-05	2.2182e-06	2.0129e+00
    8450	-1.7195e-01	2.0871e-05	2.2073e-06	2.0129e+00
    8475	-1.7194e-01	2.0787e-05	2.1964e-06	2.0129e+00
    8500	-1.7194e-01	2.0703e-05	2.1856e-06	2.0129e+00
    8525	-1.7194e-01	2.0620e-05	2.1749e-06	2.0129e+00
    8550	-1.7194e-01	2.0537e-05	2.1642e-06	2.0129e+00
    8575	-1.7194e-01	2.0455e-05	2.1537e-06	2.0129e+00
    8600	-1.7193e-01	2.0373e-05	2.1431e-06	2.0129e+00
    8625	-1.7193e-01	2.0292e-05	2.1327e-06	2.0129e+00
    8650	-1.7193e-01	2.0211e-05	2.1223e-06	2.0129e+00
    8675	-1.7193e-01	2.0130e-05	2.1120e-06	2.0129e+00
    8700	-1.7193e-01	2.0050e-05	2.1018e-06	2.0129e+00
    8725	-1.7192e-01	1.9970e-05	2.0917e-06	2.0129e+00
    
    ------------------------------------------------------------------
    >>> Results
    Status: [32mSolved[39m
    Iterations: 8780 (incl. 55 safeguarding iter)
    Optimal objective: -0.1719
    Runtime: 0.04s (39.81ms)
    
    ------------------------------------------------------------------
              COSMO v0.8.9 - A Quadratic Objective Conic Solver
                             Michael Garstka
                    University of Oxford, 2017 - 2022
    ------------------------------------------------------------------
    
    Problem:  x ∈ R^{20},
              constraints: A ∈ R^{43x20} (290 nnz),
              matrix size to factor: 63x63,
              Floating-point precision: Float64
    Sets:     Nonnegatives of dim: 21
              SecondOrderCone of dim: 21
              ZeroSet of dim: 1
    Settings: ϵ_abs = 1.0e-05, ϵ_rel = 1.0e-05,
              ϵ_prim_inf = 1.0e-04, ϵ_dual_inf = 1.0e-04,
              ρ = 0.1, σ = 1e-06, α = 1.6,
              max_iter = 50000,
              scaling iter = 10 (on),
              check termination every 25 iter,
              check infeasibility every 40 iter,
              KKT system solver: COSMO.QdldlKKTSolver
    Acc:      Anderson Type2{QRDecomp},
              Memory size = 15, RestartedMemory,	
              Safeguarded: true, tol: 2.0
    Setup Time: 0.12ms
    
    Iter:	Objective:	Primal Res:	Dual Res:	Rho:
    1	-3.5210e-01	5.9957e-01	3.1286e-01	1.0000e-01
    25	-2.3079e-01	2.4093e-02	6.7160e-03	1.0000e-01
    50	-1.8297e-01	1.1325e-03	3.3548e-04	1.0000e-01
    75	-1.8145e-01	1.0258e-03	7.8421e-06	1.0000e-01
    100	-1.7781e-01	4.5685e-04	5.0616e-05	1.0000e-01
    125	-1.7710e-01	4.2460e-04	4.4564e-05	1.8974e+00
    150	-1.7059e-01	8.0335e-04	6.6258e-03	1.8974e+00
    175	-1.6814e-01	1.8597e-04	9.5381e-03	1.8974e+00
    200	-1.6802e-01	3.0254e-05	6.3659e-07	1.8974e+00
    225	-1.6802e-01	3.0255e-05	2.3292e-07	1.8974e+00
    250	-1.6783e-01	3.2107e-05	2.2391e-05	1.8974e+00
    275	-1.6780e-01	2.9025e-05	3.7873e-07	1.8974e+00
    300	-1.6780e-01	2.9170e-05	5.6100e-06	3.2734e+01
    325	-1.6777e-01	2.9058e-05	3.6719e-06	3.2734e+01
    350	-1.6771e-01	2.8930e-05	6.1600e-06	3.2734e+01
    375	-1.6767e-01	2.8793e-05	4.6091e-07	5.1699e+00
    400	-1.6767e-01	2.8804e-05	7.8040e-07	5.1699e+00
    425	-1.6759e-01	2.8986e-05	7.7830e-05	5.1699e+00
    450	-1.6759e-01	2.8686e-05	1.5455e-07	5.1699e+00
    475	-1.6759e-01	2.8664e-05	1.2205e-07	5.1699e+00
    500	-1.6759e-01	2.8676e-05	1.7527e-06	4.3145e+01
    525	-1.6759e-01	4.0249e-05	2.6804e-04	3.2338e+00
    550	-1.6756e-01	2.8614e-05	1.4113e-07	3.2338e+00
    575	-1.6756e-01	2.8634e-05	2.8215e-06	6.9496e+01
    600	-1.6752e-01	2.8047e-05	2.3733e-01	8.4362e+00
    625	-1.6753e-01	2.8613e-05	2.0391e-07	8.4362e+00
    650	-1.6753e-01	2.8603e-05	1.0436e-06	1.0912e+02
    675	-1.6747e-01	3.6433e-05	1.5755e-02	1.0912e+02
    700	-1.6750e-01	2.8471e-05	8.8088e-07	4.6092e+00
    725	-1.6750e-01	2.8592e-05	9.4430e-08	4.6092e+00
    750	-1.6750e-01	2.8597e-05	8.8668e-07	3.7464e+01
    775	-1.6748e-01	2.8923e-05	2.2133e-03	3.7464e+01
    800	-1.6748e-01	2.8592e-05	1.1316e-07	3.7464e+01
    
    ------------------------------------------------------------------
    >>> Results
    Status: [31mPrimal_infeasible[39m
    Iterations: 871 (incl. 67 safeguarding iter)
    Optimal objective: Inf
    Runtime: 0.005s (4.66ms)
    



```julia
sharpe_solution
```




    (risk = 0.16236078767891132, reward = 0.17192407616922736, w = [0.25333508825254153, 0.2875880574554104, -1.622086428347008e-5, -9.389968640708614e-6, 0.05989215041431877, -7.32470853677147e-6, -9.096040064505045e-6, -1.1833210603662063e-5, -1.5417989206653268e-5, -1.997033929596048e-5, -1.5042185633232818e-5, -5.151583141939685e-6, -2.6850792301166074e-6, -1.0088207425621601e-5, 0.36524872331581043, -5.7274036623780346e-6, 0.0340785990119089, -3.6366325452087172e-6, -1.0160926743210856e-5, -8.73313413283553e-7], sharpe_ratio = 1.0589014664626328, status = OPTIMAL)



### What's in the optimal Sharpe ratio portfolio? 

Let's take a look at the makeup of that portfolio. First, we'll compute the number of shares that we need to purchase (given our investment budget) for each asset. We'll store this in the `nₒ::Array{Float64,1}` variable:


```julia
n_sharpe = let
    
    # initialize -
    my_list_of_tickers = my_test_portfolio_tickers;
    N = length(my_list_of_tickers); # number of assets in portfolio
    n = zeros(Float64, N); # number of shares to purchase for each asset
    w = sharpe_solution.w .|> x -> round(x, digits=4) |> abs # optimal weights
    prices = Array{Float64,1}(undef, N); # prices vector

    # get prices for each asset
    for i ∈ eachindex(my_list_of_tickers)
        ticker = my_list_of_tickers[i];
        prices[i] = dataset[ticker][1, :open]; # get the opening price on Jan 3, 2025
    end

    # get the number of shares to purchase for each asset
    for i in 1:N
        n[i] = investment_budget * w[i] / prices[i];
    end

    n; # return
end;
```

Let's build a table to summarize the maximum Sharpe ratio portfolio allocation. The table shows the ticker, alpha, beta, allocation weight, current price, number of shares, and total cost for each asset in the portfolio:


```julia
let

    # initialize -
    df = DataFrame();
    nₒ = n_sharpe; # number of shares to purchase for each asset
    my_list_of_tickers = my_test_portfolio_tickers;

    for i ∈ eachindex(my_list_of_tickers)
        ticker = my_list_of_tickers[i];
        α = sim_model_parameters[ticker].alpha;
        β = sim_model_parameters[ticker].beta;
        price = dataset[ticker][1, :open]; # get the opening price on Jan 3, 2025
        weight = sharpe_solution.w[i] |> x -> round(x, digits=4) |> abs;
        shares = nₒ[i] |> x -> round(x, digits=4);
       
        row_df = (
            ticker = ticker,
            α = round(α, digits=4),
            β = round(β, digits=4),
            w = weight,
            price = round(price, digits=4),
            n = shares,
            cost = round(shares * price, digits=2),
        )
        push!(df, row_df);
    end

    beta_vec = df[:,:β] |> collect;
    alpha_vec = df[:,:α] |> collect;
    w_vec = df[:,:w] |> collect;
    price_vec = df[:,:price] |> collect;

    # compute the total -
    total = df[:,:w] |> sum
    last_row = (
        ticker = "total",
        α = dot(alpha_vec,w_vec),
        β = dot(beta_vec,w_vec),
        w = total,
        price = 0.0,
        n = sum(nₒ),
        cost = round(sum(df[:,:cost]), digits=2),
    )
    push!(df,last_row)

    pretty_table(df, backend = :text, fit_table_in_display_vertically = false,
         table_format = TextTableFormat(borders = text_table_borders__compact)
    );
end
```

     -------- ---------- --------- --------- --------- --------- ---------
     [1m ticker [0m [1m        α [0m [1m       β [0m [1m       w [0m [1m   price [0m [1m       n [0m [1m    cost [0m
     [90m String [0m [90m  Float64 [0m [90m Float64 [0m [90m Float64 [0m [90m Float64 [0m [90m Float64 [0m [90m Float64 [0m
     -------- ---------- --------- --------- --------- --------- ---------
        AAPL     0.1061    1.1946    0.2533    243.36   10.4084   2532.99
        MSFT     0.0999     1.152    0.2876    421.08    6.8301   2876.02
        INTC    -0.1484    1.1843       0.0     20.39       0.0       0.0
          MU    -0.0532    1.6953       0.0     87.95       0.0       0.0
         AMD     0.1275    1.7392    0.0599    121.65     4.924     599.0
          GS    -0.0326      1.31       0.0     581.0       0.0       0.0
         BAC    -0.0545    1.3594       0.0     44.75       0.0       0.0
         WFC    -0.0914    1.2383       0.0     70.35       0.0       0.0
           C    -0.1334    1.5008       0.0     70.88       0.0       0.0
           F    -0.1928    1.4336       0.0      9.69       0.0       0.0
          GM    -0.1291    1.4695       0.0      51.5       0.0       0.0
         JNJ    -0.0162    0.5396       0.0    144.07       0.0       0.0
          PG     0.0147    0.4905       0.0    166.25       0.0       0.0
         UPS    -0.0746    0.8695       0.0    123.96       0.0       0.0
        COST     0.1113    0.7147    0.3652    914.33    3.9942   3652.02
         TGT    -0.0193    0.8286       0.0    137.69       0.0       0.0
         WMT     0.0617    0.4798    0.0341     90.15    3.7826     341.0
         MRK     0.0035    0.5594       0.0     99.34       0.0       0.0
         PFE    -0.0792    0.6227       0.0      26.7       0.0       0.0
        ADBE     0.0495     1.264       0.0   429.445       0.0       0.0
       total   0.105994   1.01546    1.0001       0.0   29.9392   10001.0
     -------- ---------- --------- --------- --------- --------- ---------


Now, let's compute the performance of investing all our budget in `SPY.`


```julia
SPY_performance_array = let

    # initialize -
    SPY_performance_array = Array{Float64,1}(undef, number_of_days_to_simulate);
    total_budget = investment_budget; # total budget to invest in SPY
    SPY_df = dataset["SPY"];
    
    # how many shares of SPY do we buy?
    Sₒ = SPY_df[1, :open]; # first open price
    nₒ = total_budget/Sₒ;

    # compute the performance
    for i ∈ 1:number_of_days_to_simulate
        S = SPY_df[i, :close];
        SPY_performance_array[i] = S*nₒ;
    end
    SPY_performance_array;
end;
```

Next, let's compute the performance of portfolio $\mathcal{P}$ by computing the value of each asset in the portfolio and the total value of the portfolio, starting from the initial allocation. We'll store this data in the `portfolio_performance_array::Array{Float64,2}` array.

Each `row` of the `portfolio_performance_array` corresponds to a `date`, while each `column` corresponds to an asset in the portfolio, with the last column holding the total value of the portfolio $\mathcal{P}$ at a particular time. We'll use the close price of each asset.


```julia
portfolio_performance_array = let
    
    number_of_days = number_of_days_to_simulate;
    startdate = Date("2025-01-03"); # starting date for portfolio performance tracking
    my_list_of_tickers = my_test_portfolio_tickers;
    nₒ = n_sharpe; # number of shares to purchase for each asset

    w = sharpe_solution.w .|> x -> round(x, digits=4) |> abs # optimal weights
    portfolio_performance_array = Array{Float64,2}(undef, number_of_days, length(w)+1)
    for i ∈ eachindex(my_list_of_tickers)
        
        ticker = my_list_of_tickers[i];
        price_df = dataset[ticker];
        ticker_data = filter(:timestamp => x-> x >= startdate, price_df)
        nᵢ = nₒ[i]
        
        for j ∈ 1:number_of_days
            portfolio_performance_array[j,i] = nᵢ*ticker_data[j,:close]; # value of this asset in the portfolio at close
        end
    end
    
    # total -
    for i ∈ 1:number_of_days
        portfolio_performance_array[i,end] = sum(portfolio_performance_array[i,1:end-1])
    end
    portfolio_performance_array;
end;
```

Finally, let's compute the performance of the bandit portfolio.


```julia
bandit_portfolio_performance_array = let

    # initialize -
    t = 1;
    K = length(my_test_portfolio_tickers); # TODO: Number of tickers to consider
    N = 2^K; # number of possible portfolios
    number_of_days = number_of_days_to_simulate;
    my_list_of_tickers = my_test_portfolio_tickers;
    startdate = Date("2025-01-03"); # starting date for portfolio performance tracking

    # compute the best portfolio -
    j = sorted_reward_index_array[1]; # get a portfolio index 
    a = digits(j, base=2, pad=K); # generate a binary representation of the number, with K digits  
    if (j == N)
        a = digits(j - 1, base=2, pad=K); # generate a binary representation of the number, with K digits  
    end

    # call world -
    U, n, pₒ, γ = world(t, a, dynamic_context_model);

    # compute the weights -
    w = zeros(K);
    for i ∈ 1:K
        w[i] = (n[i]*pₒ[i])/B;
    end

    portfolio_performance_array = Array{Float64,2}(undef, number_of_days, length(w)+1)
    for i ∈ eachindex(my_list_of_tickers)
        
        ticker = my_list_of_tickers[i];
        price_df = dataset[ticker];
        ticker_data = filter(:timestamp => x-> x >= startdate, price_df)
        nᵢ = n[i]
        
        for j ∈ 1:number_of_days
            portfolio_performance_array[j,i] = nᵢ*ticker_data[j,:close]; # value of this asset in the portfolio at close
        end
    end
    
    # total -
    for i ∈ 1:number_of_days
        portfolio_performance_array[i,end] = sum(portfolio_performance_array[i,1:end-1])
    end
    portfolio_performance_array;
end;
```

### Visualize
`Unhide` the code block below to see how we visualized the relative wealth of the portfolio $W_{t}/W_{o}$ for our selected optimal portfolio versus an alternative portfolio consisting of `SPY` over the same time frame (where the daily price is taken to be the close price).


```julia
let
    
    total_budget = investment_budget;
    plot((1/total_budget).*portfolio_performance_array[:,end], lw=3, 
        c=:red, label="Max Sharpe (actual)")
    plot!((1/total_budget).*SPY_performance_array, lw=3, 
        c=:blue, label="SPY")

    plot!((1/total_budget).*bandit_portfolio_performance_array[:,end], lw=3, 
        c=:green, label="Bandit Optimal (actual) λ = $(λ)")
    xlabel!("Trading Day Index (2025)", fontsize=18)
    ylabel!("Scaled Wealth (N/A)", fontsize=18)

    plot!(bg="gray95", background_color_outside="white", framestyle = :box, fg_legend = :transparent);

    # uncomment me to save the figure -
    # path_to_save_figure = joinpath(_PATH_TO_FIGS, "Fig-Wealth-K20-L2-SR-I500.pdf");
    # savefig(path_to_save_figure);
end
```




<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAlgAAAGQCAIAAAD9V4nPAAAABmJLR0QA/wD/AP+gvaeTAAAgAElEQVR4nOzdZUBUWRsA4HeaoUHpUCQMFAVEbBSxBbFzjbXFbj/XtWPt7sJW1DWwAxsDQUoRkBaQ7mHyfj/ueB0GBMRhYOV9fp05c+69Z+7u8u5pGkEQgBBCCNVV9JquAEIIIVSTMBAihBCq0zAQIoQQqtMwECKEEKrTMBAihBCq0zAQIoQQqtMwECKEEKrTMBAihBCq0zAQIoQQqtMwECKEEKrTmDVdgYqNGTPm69evmpqa5RcLCwtr0qQJk/kf+EX/Le/fv2/VqlVN1+J3IxKJIiIimjdvXtMV+d3weLyEhITGjRvXdEV+N7m5udnZ2Q0bNqzpivyc/Px8PT29U6dOlV/sPxA2UlJSmjZt2rp16/KLPXr0aNKkSfXr11dOreqOS5cuLV++vKZr8bvJyMh4+vSpu7t7TVfkd/Pp06eIiAh8sQr37Nmz3Nzc/9yLfffuXXh4eIXF/gOBUENDw9nZ2cPDo/xiS5cu7dWrl5mZmXJqVXeMHTt2wIABNV2L301iYuLWrVvxxSrcy5cv7927hy9W4YqKijIzM/9zL5bFYsXHx1dYrFrGCEUi0YkTJ2bOnDl06NCEhIRySmZkZAwfPvzIkSPVUQ2EEEKoQtUSCIuLi69evWpgYHDlypXc3NxySs6cOfPdu3eBgYHVUQ2EEEKoQtUSCNXV1a9evfrXX3/R6eXd39fXt6CgoHfv3gp5qKampoqKikJuhWTp6enVdBV+QyoqKhXO/0JVoKampqamVtO1+A2pq6urqqrWdC2qS40tn8jNzV28ePGBAwcUdcPr16/jn+zq8OLFi5quwm9IT0/v+vXrNV2L31DLli0PHz5c07X4DfXu3XvdunU1XYvqUmOTZWbPnj1r1iwTE5MKS3748OHZs2dLly4lP6qrq1+7dq10WzMjI6P8BiiqGnyx1QRfbDXBF1sdBAJBYWGhSCSq6YpUgCAIT0/PvLw88iOPx9PV1a3wqpoJhA8ePPjw4cO2bduys7OLi4vFYnFeXt6PeopsbGy6du3q5uZGfuRwOIaGhqWLSSQSfX39aqx0XYUvtprgi60m+GKrg0AgKCgoqExQqXFXrlzh8/lk+tGjR/fv36/wkpoJhGFhYdHR0VZWVgBQVFQEAJGRkc+ePSuzMJPJ1NfX/88t5EQIIVQF4Rnhf9z4Q1dF9+KAi7oqPx16jYyMqLS+vn5ldllRagfCnTt3Lly4AABz5szJ+mby5Ml//vnnj6IgQgihOuXw+8PR2dFvUt5cjbyqnCdWVyBs3ry5rq6uurq6i4uLrq5uRkYGADx58sTX11euJJfL/Y0nIyGEUJ3CF/NFkl8aSkzIk64+j86OVkSNKlZdXaNhYWGlMzds2FA6859//qmmOiCF+E+MCvwX4YtFv597sffG3xyvwdZ4MOKBqYZp1W7yJf8LmYjJiVFc1cqDc6tQBdhsdk1X4feELxb9Zh7GPxx9Y3S+ID+5IPnCxwtVvk9SfhKZ+Jz9WUFVq8B/YK9RhBBCtVlyQfLlT5fXvlhbLComcwJSAqp2qzxBXr4gn0zH5cZJCAmdVu0NNgyECCGEqm7y7ckXIy5KCIls5rvUd1W7W1JeEpXmi/lfCr6YaVT7UQrYNYoQQqiKgtOCz388T0XBBpoNNNgaAJBamEr1cP4Uuauis5QxXwYDIUIIoSp6nfyaTFjrWO/uvtt/rH9rI+nZsW9T3pKJkLQQlzMuE25NEIgFFd5QLhAqZ74MBkKEEEJV9Cb5DZmY1GrS2BZj1VnqrQ2lgZDqHf3r6V9BX4N8InwexD2o8IbUlFESBkKEEEK12psUaSBsY9yGTFAtQnK+TFxu3JOEJ2ROVHZUhTeUaxF+zlHGxFEMhEqSk5NTUFAgm5Ofn1/+YY2VwePxwsLCQkND8/Ol86zi4+PPnTv3i7etglevXgUFBSnnWenp6d7e3gAgkUgOHTokkUgqvAQhpHBpRWlxuXEAwGVyW+i1IDMdDR3JRNDXIJFEdCrsFAEEmUMuh8jh5zxNfErNL5WDLcLfmYWFRZMmTXg8HvkxOzu7UaNG9vb2v3LPa9eu2drazpkzZ968ec2aNTtx4gQAREVFHTp06Ncr/FN4PJ6Xl1eZm6GXY8eOHdeuXavC45KTkzdt2gQAdDr948ePZ86cqcJNEEK/iOoXtTewZ9FZZFpfVd9c0xwAeCJeaHromfDv/3nG5MSICXH3c937+fQbf3N8mfeUaxHG5caFpIWsfrE6JC2kWn4DAGAgVKZGjRrdvHmTTPv4+DRr1kyugFyTsXwSicTLy2vPnj0PHjy4f/9+ZGQkdUAHicfjicXiSj6ioKBA9oCVwsLC0mWoKF6aj4+Pvb297F63PB6vzBNbioqKqAZcREREUlKl5pUVFRWV/i2kKVOmbN26lSCIytwHIaRApftFSU5GTmRi3ct1yQXJVP7nnM+RWZGfsj4BwKP4R6X/syUIgipPzj4tFhX3vNBzy+stw68Nr77/zOvMOkKBgPHmDQiFynkaYWgoadpULnPUqFFnz54dPHgwAJw+fXr06NEbN24kv/rrr78uXbrE5XJ5PN6GDRsGDBggkUiGDRvWsWPH2bNnSySSESNGtG3bdu7cudTdioqK8vLyqEM5uFyuqal0QyORSDRt2rQnT57k5eVt3Lhx9OjRALBly5ajR4+qqKgUFBT89ddfY8eOBYCtW7d+/vw5KioqPj5+3759vr6+TCbz5cuXOTk5urq6J0+ebNSoEQD4+fktXryYz+cLhcIVK1YMGzZM7qddvHhx4sSJZPrt27dTp04ViUSFhYWdO3fet2+fiooKANy6dWvZsmVCoZDP5y9evFhTU/P69et37tw5ePBgv379Fi5caG9vHxcXR95k3Lhx/fv3HzBgwOPHj2fPnk2j0fLz83v16rVr1y4GgyH76CZNmtBotHfv3rVu3fpX/pEhhH4W1SJsY1QiEDoaOl7+dBkA7sXek81Pzk+mLuGJeKmFqUbq0v97Xv1i9fPE59McppFdplocrWb1m/l/8QeAQmEhACTlJ8XnxTfUalgdP6SuBELuiBHMSpxKpTA0Gs/bW+TpKZvn6uq6a9eupKSkvLw8gUDQqlUr6quxY8euWbOGRqN9/PixT58+3bp109TU3L59e5cuXZydnZ8/f56RkTFjxgzZu6mrqw8YMMDDw8PDw6Nt27Zubm7U3pWhoaF//fXX/v3737x5M2DAgOHDhzOZTE9Pz7lz5zIYjISEBPJ8RxMTEz6ff+3aNT8/PxsbG4lEcvHixWfPnj1+/NjAwGDDhg0zZsy4detWcnLypEmTLl++3LJly6SkJFdXVycnJzJAksRi8Zs3b/bu3Ut+NDc3f/jwoba2tkAg+OOPP7y9vadMmRIVFTVp0qSrV686OTmJxeKUlBRTU9NHjx61aNHCy8sLALKysnJycqh7FhQUCIVCALCxsXn+/LmGhgaPxxs8eLCPj8/w4cPlXra9vb2/vz8GQoSUSSgRBn2VTgugmoCkDqYdZD/SgKbF0crh5xBAXI+6TuXH5caRgTAiM2LL6y0AEJwWTH5lqmHaSLsRGQgpIWkhGAh/CSOkGvuXy0AQjNBQuUBIp9OHDh168eLF9PR0spVGMTExOXfuXGxsrEAgAICoqChHR0dTU9Pdu3ePGTNGIpE8fvyYxWLJPeT48eM3b968f//+xo0bZ8+efezYsd69ewOApaVlz549AaBNmzYAkJqaampqamZmduXKlejo6OLiYg6HEx4ebmJiAgC9evWysbEhqwcAQ4YMMTAwAIAZM2Zs3LgxPz//zp07DRo0yMrK8vPzg2+RSTYQkqcrU0ehGhgY+Pv7+/v75+bm8vn8wMBAAPD19e3Zs6eTkxMAMBgMqvFaIWNj4ydPnrx9+zY/P18ikQQGBpYOhHp6esnJyWVejhCqJqHpoTwRDwAaajU0UDOQ/crewH6n284b0TcisyK/5H+Z1GpSTE4M2Tp8kviEKhaXG9fOpB3InDJB3hAATDRMLLUt5Z4YlhHmYe1RHb+lrgTC4n37WPv3034wzqRwEn19wbRppfNHjhw5fPjwwsLCp0+fUt2AQqGwW7du7dq169ChA51O9/HxoaaANm/ePD8/v02bNmTQkkOn093d3d3d3QFg1apV//vf/8hAqKmpSZXhcDjkYc0eHh4NGjTo0aMHg8G4ffs29Yj69evL3lNHR4dMqKurs9ns7OzstLS0nJycq1elB4NZWloaGxvLXkJuHi0QCLhcLgAcOnToxIkTU6ZMsbCwyMrKys7OBoDMzEy5B5WPGgzYtGnTrVu3Jk2aZGlpmZSUVObgpVAo1NLSqvzNEUK/jtpNVK5flDTebvx4u+/TYRb5LSITsmvqyRmnABCfFy93uamGqaWOfCCsvvkydSUQirp3F3XvXtO1AGtra2trax0dHX19fSoQfv78OTMzc9u2bQBQWFg4ffp0Ml8kEk2YMGHBggW3bt06cODAtLIiK8XJyenkyZM/+jY9PT0wMPD27dt0Ol0oFC5evJj6ikajyZaMiIigakWj0YyMjKytrblc7o4dO+RKUjQ1NfX09BISElq0aAEAN27cWLJkiYeHBwA8f/6c+uGl53YymUxqCoy6ujoA5OXlaWpqEgQREyOdM33jxo21a9e6uLgAQOnDLEkJCQn9+/f/0W9HCFWHxLxEMtG0vvx8iNKsdKxKZ1KBMC4nTu4rEw0TF3MXEw2TlIKUqfZT9wXuAwyEv5Pz58/L5RgZGRUVFZ0+fdrS0nLv3r3UZJDVq1draGjMmzdv0KBBXbt2bd26Ndm1SMrJyRk4cODIkSMtLS0zMzM3bNgwaNCgHz1UW1tbQ0Pj4MGDDg4OR44cIduIZXr48OGRI0eaNm26du3aiRMnslgsDw+PHTt2zJw5c8SIEWKx+MWLFwMGDGjSpInsVV26dHn16hUZCC0tLc+ePWtsbBwYGOjr60vWeejQoTt27Fi0aNHAgQOzs7MJgujTp0+zZs2uXLlibGxsYWHh6OjYtm3b5cuXDx069N9//yXbkQBgZWXl7e2tpqbm7+//+PHjXr16yVVYJBK9e/du+/btFb55hJACpRamkglDtYrXTTXSblQ6s/wWoa6KbtD4oHxBvo6KzvGQ4zwRLyk/Kbs4W0dF55fqXRZcPqEkc+bM0dbWls0xNjaeMmUKAGhpafn4+Dx69OjgwYPjx49fvny5ubl5bm4ug8E4ePAgjUZr2LDhsWPHwsPDZS/X0NCYMWPGhw8fDhw4cP/+/fnz569fvx4AGjZsOGLECKrYlClTtLW1WSzWv//+GxgYuGfPHnd39zVr1jRu3BgA2rVrRza2KF5eXl+/ft27d2/v3r3XrFkDACwW6969e5aWlgcPHjxx4oSamppc1ygAjBs37tKlS2R69erVNjY2mzdvzszMPH78ONlzy+Vy/fz8NDU1d+7c6evrSw4oTpgwYcyYMaGhoWTj+NixYwwGY9++fZ06dVq7di0Za7ds2aKvr79582ahUHj06NHu3bsDgJ6e3pgxY8jHPXr0qFWrVmZm1b4/PUJIFhUIjTXk/yCUVrqfEwDic6Xxj4qIFDNNMwBQYaroqeox6cxm9aWLzaqpUUir/QuwBg4cOGjQILKrrRypqak/u6AbyZk8ebK9vX35fbA/4unpuWjRovbt2yu8VuXr27fv33//7ezsrOTnoloL/xRUB4FAUFBQQE1NBwCnE07kikD/Mf629W3Lv1wkERnsMhBKSixgowEtdVaqCkPFaLdRkagIABg0hpgQA0DIhBITRGfdn3Ui9AQArHdZP8OxxPz58vn6+l64cIGa4vAj2CJEinHq1KmmpZZOVjeCIA4ePIhRECHlo1qE1FrAcjDpzAZaDaiP5Fm7BBAJeQnpvHQyCmpztMn5NY6GjuTeNBRq/7ZqahHiGCH67lf2ZtPQ0FBgTSqJRqNVfiUGQkhReCJeLj8XADgMjg6nUoN2ltqW5DIJOo3uaOhIHtIUlxuXx88jCzTQarCt27a5beYaqRnJnUpvp29HJkLTQxX4KyjYIlSeoqKiwMBAf3//L1+ku8qKxeK4uLi4uLikpCRyQ7LCwsLExETZqwoKCiq5DxlCCClHSkEKmTBQM/jRfHI51HwZCy2L5nrNyXRcbhw1QEj2hZppmDHp8i20FvotyND4KevTj3br/hUYCJXEz8/Pzs5u2bJlmzdvdnV1XbVqFQBkZ2fb2dn17du3T58+pqamixYtEolEPXv2vHv3LnmVRCIZMmRI6YmmCCFUg35qyiiJWkHRXK85Nf4XmxNLBULZvlM5qkxVMo6KJCJyYFKxsGtUSRYsWPD333+Tcx0lEklKSgr11ePHj/X09OLj49u3b9+1a9e9e/dOnTr11atXOjo6+/fvLygomD17ds1VHCGE5KUWfAuE6pUNhD0b9Vz7cm2+IH+k7UieULqDTFxuXIFAehJAA80fBkIAsK1vS/asfsr61FK/ZRXr/QN1JRDyeLSnTxlFRUp6XKNGRMuWJXaxycjI0NPTI9N0Or30TjENGjRo0qRJVFTUrFmzunfvvnDhwr/++mvz5s23b98uvbkaQgjVoK9FX8lE5VuE5prmHyZ9KBYV1+PWozYpjc+NJ/fUBoCG2g3LuZxagEEeaqhYdSUQDh3KffKEUXE5xTl6tHjIkO9zhSdMmDB+/Pg+ffo4Ozv37NmTOjWCEhISEhYWtmzZMgDYsGGDs7Nzv3795s6dq/ypmAghVL7kfOnuvpWZMkpRY6mpsdRAphc0Nic2XyDd7rH8DbUttCyoS36yshWrK2OEUVHK/qWRkSWe+Pfff1+9etXU1NTHx8fBweHgwYPUVw4ODqampuTpEK6urgCgoaGxdOlSsVgsd+IEQgjVBl8Lf7pFKEtXRVeLowUARaIicqs2GtDMNMrbFoNqEVbHmfV1pUV48CDP25utrD23oV49wstLIJfZtm3btm3bAsDJkycXLlw4YcIEMv/x48dGRkaqqqqyhTU0NFRVVeXO3kMIodrg+2SZSo8RyrHUtgz8GggABBDkfVSYKuWUp1qEGAirzsVF7OLywwPWlYAgCGqScYsWLYRCofDbKcGamppyURAhhGozKhAaqBqUX/JH/mz5Z+C9QOpj+TNlAMBY3ZjL5PJEvAxeRp4gT5OtWX75n1JXAmGN69ixY//+/W1tbfPz83fv3u3p6cnlcss8VAghhGo5atboT40RyhrTfMyrL69Oh58mP1Z44i6NRrPQtviQ8QEAYnNiFTtxtK6MEda49evXFxUVXblyxd/ff/r06QcOHAAAVVXVuXPnltkctLa2HjdunLJriRBCFeGJeDn8HABgM9i6KroVlv+R7W7bqaPtyzynSQ7VO6rwiaPYIlQSFxcXuXMeAEBVVZVcWV+ara2trW0F+9gihJDyUTNlDFQru61MmTgMzhmPM1NuTyGAGNtibIXlqb1pFD5MiIEQIYTQT0guqMraiTIZqhleG3ytkoUttL+toMhV8AoK7BpFCCH0E359gLBqqm8FBQZCJYn7JiUlRSKR/PoNd+7cmZycDAA3btx4+fJlZS759OnTnTt33rx5Q27wXXnv3r2jzt2tmsjIyGPHjpX51fHjx2U3nKtWb9++vXz5MgCkpaUdOXKkzDIPHjw4cOCAoqoUERFx9+5d8p9UmTIyMu7evRsSUi2HyyD0i/hi/rGQY+c/nk/npVOZ1LYyBmpVnDJaNdXXNYqBUEns7e2HDh06ZswYNzc3e3v70NBfPUzk2LFjaWlpABAWFkae8H7//v1JkyaVWTgvL4883PjkyZNz5sxxcHB4//59OTfPy8uzs7OjDm1OTEwsv3yFPn/+XObW4cHBwSdPnvzZY1Td3d2r9gKDgoJu3rwJAPr6+ufPnw8MDCxdRkdHJyAgYOjQoVW4v5x169Z5enqeOnWqQ4cO169fL13g2bNnTk5O3t7eo0ePnjVr1q8/ESHF2ui/cc6DOZNvT252tJmnrye52yfVIlRyIDTVMGUz2GQFyCMMFQUDofIcO3bs6dOn4eHhXbt23bBhA5Wfl5dHHcMkSyAQJCYmyuUXFhampqbK5ixdunTkyJEAUFBQ8PXr1zIf7eXlxefzAwMDz549+/Lly5EjRw4ZMiQvL48qIBQKExMTqaaqRCIhgyvJ09Nz7dq1sjdMS0vLzMwk07m5uWRIpvD5/MTExMosDtm1a9eff/5JjbcXFxcnJCTwePIrPgUCQXx8fHGx9PiVpKQkPp9f4c15PJ7sVXL+/PPP3bt3l853dHTct2/fly9ffjH2f/nyZdeuXffu3Tt9+vTevXvJrYLkyvz9999//fXX2bNnHz9+fP369eDg4F95IkIK9zr5NZkggHif8X7z683wk0fyKhCDxiCXGxJAKHajtboyWaZAWOAX7yeS/FyXYJXpq+p3MO3wo28NDAyoYDZ8+PDPnz9raWnFxsZu377dw8MDAEaNGqWrqxsQECCRSPLy8nx9fS0tLQFg3bp1x44dMzMzMzc3pwLkzJkzraysRowYsWLFioyMjM6dO2tqavr6+lKPS01NvX79+osXL9TU1MicBQsWnD59+tKlS3/++eeMGTMKCwsjIiLYbHZ6evq5c+datmw5bdo0ACCnuR4+fPjFixdPnjzx9vaOjo52c3Nzd3d/9+5dYmLiwoULAeDs2bOZmZndu3fft28fAJw6dWrTpk2Ghobx8fE9e/bctWvXj+aV8fl8X1/fjRs3kh/379+/f/9+AwOD2NjYwYMHk/kSiWT58uXnzp2zsLBISUk5dOjQkydPkpKSpk6dqqqqOm/ePA6Hs2PHDurgKjMzs+fPnzdo0GDTpk1nzpzR19ePiYmZOHHi0qVL5Z7ep0+fOXPm8Hg8Lpcr9xWbzTY3Nz99+nSrVq3K/edcnps3bzo5OZmbmwNAz549J0+eHBISYm9vTxX48uVLYGDgtWvXAEBXV9fNze3GjRstWyp4W32EfkVkVqTsx2eJzwAgKV96QmrV9lf7FRbaFlHZUQAQkxNjW19h8+rrSiAcfGXwyy+VGkhTlP0994+yHSWbs2nTJh0dnYyMjNjYWOos+J07dxoYGABAeHh4v379+vbtS26r9uHDh0ePHnG53AULFuzbt2/r1q2vX78+fvz4q1ev9PT0Lly4cPXqVdmb6+vrr1q16vjx46W74CIjI1VUVGQXYzCZTAcHB6p38c2bNy9evNDW1j58+LCXl9fz58/3799vbm7+5MkTMoa9ePGCujYrK6tLly67d+8ODQ11dXWdMWPGq1ev8vPzbW1t586da21t3atXr1GjRtHpdD6f7+bm9vDhQzc3tzJfUUhIiK6uLnUox6BBg6ZOnUqj0YqKijp37vz69WtnZ2dvb+9Hjx4FBgZqa2uLRCIej9exY8dLly4dOHCgdevWAHD79u0ybz527NhFixYBQG5ubrt27Tw9PeW2L9fW1jYwMHj//n27du3krn3z5k1ERERcXNz69evZbLbctx4eHh8+fJDLHDZs2Lp162RzkpOTTU1NyTSDwTA2Nk5KSpINhMnJyZqampqa0g0yzMzMqBObEaoNcvg5aUVpAMBlcpl0Zr4gPyk/KTIrMiAlgCzQpF4TJVepmoYJ60ogTMhLqPEntm7d2szMLDs7+8SJEzdu3GjevDkACIXCLVu2JCcni8XiwsLC5ORkMzMzABg8eDDZUmnXrt2pU6cA4NGjR/369SPDxpAhQ+bMmVPJmhQVFamoqMg1y7hcLtW7OGDAAG1tbfgWPNLT08s5+InL5Q4cOBAAWrRoQaPRhg8fDgAaGho2NjYxMTHW1taamppnz54NCQnh8/kCgSA0NPRHgfDr16/16tWjPmpoaJw4ceLjx498Pl8ikYSGhjo7O9++fXvChAlk9ZhMpoaGRiV/tZqa2qFDh6KiogQCAY1GCw8PL32OR/369cucFLNz58758+f/+++/d+7cIdvoss6ePVu6H5vD4cjlCAQCJvP7f19sNluuO5fP58u+59IFEKpZVHPQWtdaj6v3MP4hAGx5vYUn4gGAja6NqYapkqtErbtPKVDkDLu6EgiP9T125P0RoURYcdFfxqAzTDVMZzjKHxzh6upKBr82bdp06tRpxowZIpHIzc1t2rRpnp6empqaly9fpsbVqG5MFotF/tnNz8+nwgCdTq98SGjUqFF2dnZmZqZs1ImKiurVqxeZVldXJxNsNpvD4eTl5cmWlKOqqkrFVAaDIVtPcvdULy8voVA4evRoXV3d7Ozs0gN+FNlgDADjxo3T0tIaNmyYjo5OUlJSUVERAOTk5JBRsJKoYc7Bgwc3bdrU3d1dR0fn06dPZQ5YFhcXU/WnfP782c/Pb/fu3Vwu9+zZs6UD4cmTJ0vPAm3durWnp6dsDtnHS33MyMiQmxNkYGCQk5MjFovJPoCMjAyybwChWoIKhDY6No11GpOB0CfCh8x0beCq/Cr1tey78+3OXH6up41nxaUrra4EwrbGbdsat63pWkgVFRVJJBKCIIKDg/X19ckD6BMSEmRnr5RmZWVFjicBQHJystz8FADgcDjURt5yF1pbW+/evXvlypVkjr+///v376mjoKg+0qioKIIgTE1NyWkdIpGoCmcCP3z48MGDB+SgZlJSUpMmP+w8sba2JmcDMZlMgiAePXoUHh6ur69PEERSknQQomnTpq9evRo8eLDshWw2m2qT6ejopKdLJ3YnJSXl5+cDAI/H8/f3v3r1qoqKilAoTEgooz9AIpEkJCRYW1vL5e/evXv8+PG6urrDhg1bs2bN169f5eJT/fr1qfm0FC0tLbkcZ2fnHTt2CIVCFosVHR2dk5NjZ2cnW6Bhw4b16tV7+fJlp06dCIJ49uwZeRolQrXEp8xPZMJG16adkXQEQUxI53y5NSy7p6damWiYhEwMEUvE5PRRRamuQJidnR0QEBAbG+vs7Fzm+H9YWNidO3eSk5N1dHTI/1TWbsUAACAASURBVHmvpprUHqdPnzYwMMjKyrp8+fK4ceM0NTWtra0/f/589OjR+vXrHz58uPwzKIYNG7Zly5aVK1e2bt366NGjpZsytra2oaGh27dvNzAwIOeRkuh0+qFDhzw9PVNTU7t06RIbG7tnz541a9ZQMSAgIGD9+vV2dnZbtmzx8vIie/msra2XLl1qa2tbuklUPjs7u02bNg0aNOjmzZvlD3qZm5ubmpoGBwc7OjrSaLTmzZuvX7++T58+ly9fzsnJIcvMnz+/a9euWlpaTk5OMTExzs7Ojo6OdnZ227dv79GjR4cOHVq2bJmXl7d27dqmTZueO3dORUUFALhcrqWl5erVq11cXMrsyQSA0NDQ+vXrN2rUSDYzPT3dx8fn9evXAKCnp+fq6urj4yN3KmQlV1a0bdvW2tr6zz//9PDw2LNnz/jx48nhwKVLl379+vXYsWMsFmvGjBlz5sxZtGjR06dPJRJJnz59KnNnhJTje4tQ18bB0IHD4PDF0i4cNoNdznzAasWgMRR+Ph2DaiUoVp8+fW7fvu3r61u/fv0OHcp4X6dOnUpLS2vYsGFycvKUKVO6dOlCzq8r7cKFC82aNWvcuHH5TywoKKC6+GohFRUVMnTp6upOnjyZXPCnqanZsWNHPz+/lJSUhQsXWlpatm7dWlVVlc1mN2vWTF9fHwAYDIahoWGzZs3YbPaAAQOCgoI+fvw4c+bMZs2aOTg4qKurs1gsGxsbY2NjbW3trl27pqam8vl8Jycn2acbGxuPGDEiKSkpJCSETqevXr26f//+5Fe3bt3q0aOHtra2v7+/u7v7jBkzyJ5Pd3f37OzsvLw8W1tbTU1NExOTxo0b02g0bW1tcpYKAHC5XGdnZzJwcjgcOzs7XV3d7t27R0VFBQYGdunSZdiwYVZWVmZmZgwGQ19fn+wZliUUCp8/f96jRw8A6NWrV1hYWHBwcN++fd3d3Rs3bmxsbKylpTV06NCwsLCAgABVVVUXFxc1NbVu3brRaLTMzEwylPbq1ev169dfvnxZvHixmZkZWaU+ffoEBgaGh4cPGzbM1dWVfJ9MJtPU1NTGxgYAdu3a1bFjR/KESEpsbKyTkxOVaW1tLRKJqvx/aZ6enomJicHBwX369Jk7dy6dTif/gVpZWZF1cHZ21tXVffr0qbGx8Y4dOyrf3Y3KUcv/FPyHrH+5Prs4GwAWt1usr6L/MO7hl0Lp/9p2MutUmd1Ba1xkZGR4eDg5laEctNKdPApBHr/n4eHRsWNHcvJeOcaPH6+lpbVjx44yvx04cCC5GLz8m6Smpv7sumwEADNmzLC2tia7Z5WvuLi4c+fON2/epOaOKkdWVlaPHj2ePn2KJ0H+fvBPgUIIxALD3YYiiYhOo6fOTKVL6CufrtwTsof8dnWn1XOcKjtfrwb5+vqWnmNfWnUtqK/8luS5ubmhoaEtWrSoppqg8nG5XLI7sUaoqKg8efLkp6bDKISGhgZGQYTK8TnnM7nw2lzTnDw73tnQmfq2RmbKVJ+anCxz+fLlefPmpaamjh49esKECT8qlpCQcOjQIWq5GJfLXb58OdnLJCsvL092ZTSbzS69UBqVtnnz5pqtQI38Y2KxWFWYB6R8AoGgnGm3qExyfwpQ1QQlBpEJS03L3NxcoVBopWJFDhMaqhqas81zc3NrtoZlIghizZo15JxzAEhMTCwoKKjwqpoMhO7u7i4uLhEREZMmTdq1a9eP9lrU0NBo2LAhNeNOTU2t9DwRAFBRUZH9t1/ho6kIKR+TycS/6T9L7k8BIhUIC4LTgh0MHLjMSr2c+MJ4MtG4XmMul8tgMOqp1zvY4+C16GvjW4yvzb0pTk5OVPBjs9mfP1d8im9NBkI2m12/fv2OHTvOnTvX29v7R4FQR0fHzc2twjFCNptdehMQhP7T6HQ6/lv9s/BPQZn6X+wfnBbsYu5yY/CNypT/nCuNH031mpLvk81mD2w6cGDTgdVYS0WQnRrj6+ublZVV4SVK3XQ7Ozv76dOnZJpqugJAQEDAj6aMIoQQ+kXZxdnBacEA8CThyaesT2WWEYgFe97tORJ8REJIoOTaCaXVs6ZUV4tw7dq1V69ejY6ODgwMvHjx4sqVK/v16xcQEDBgwACy0ers7Gxqaqqnp/fhw4fMzMz79+9XU00QQqiOo86LAIBLEZeWtS9j64ZD7w/978n/ACAiM6Jrg65k4KQBrXG9Cpau/QaqKxD+8ccfvXv3pj42bNgQAJydnZ88eULmPHv27PXr11lZWRMnTmzXrt1/YuYCQgj9F30t/H5A248CYXhGOJk49P7QidATBBAA0Neqr66KrnIqWYOqKxA2aNCgQYMGcpmampqOjo5kWltbu2fPntX0dKRAaWlp5NJ+pFj4YpHSyAbCzzmfg74G2RvYy5VJLvi+g65ALAAAc03zPT32KKeGNQsP5kUVoLaxRoqFLxYpjWzXKMhsnC0rOb/EVvJcJveMx5m60BwEDIQIIfTbk20RAsCVT1fIGTGyvuRLt09rZ9JOk625v+f+lvp15ZjounL6BEII1VmpBSVahMkFye/T3jsYOFA5eYK8AmEBAHCZ3LvD7iq7fjUNW4QIIfSb+1okbRFqsKUbuyfmJcoWoJqDxurGyqxYLYGBECGEfnPUee629W3JREZRhmwBKhCaair70PnaAAMhQgj95qgxwuZ60qPQMnglAiE1ZRRbhAghhH43PBEvX5APABwGx1LHksz8UYvQRMNEydWrDTAQIoTQ74xaO2GgZqCnKj34M7M4U7YM1XdqpGakzLrVEhgIEULod0ZNGTVUM6zPrU+msUUoCwMhQgj9zqgWoaG6YT1uPTL9ozFCDIQIIYR+N2lFaWTCQM2gwhYhTpZBCCH0u6G6Rg1UDeqrSgNhJi+TIAgyzRPxcvg5AMBmsKlIWadgIEQIod+ZbNcoh8FRZ6kDgFAizBPkkflUc9BIzYhGo9VIJWsWBkKEEPqdUYsIDdQMAIBqFFLDhHV8pgxgIEQIod8bFQgN1QwBoPQwYR1fTQ8YCBFC6Pcmu44QAEpPHMUWIQZChBD6bYkkokxeJgDQaXSyLfi9a/RbizClULqa3lgDW4QIIYR+L2lFaeTRg3qqekw6E2S7Rku1CLFrFCGE0O9GdhEhmZBdQQEAQonwY8ZHMgcDIUIIod/N6+TXZEJfVZ9MyE2WWfV8VWxuLABwmdzG9RrXRB1rHgZChBD6PQV+DVz+dDmZdjJyIhOyyyfux93fHbCb/Liy00pNtqbyK1kbYCBECKHfUHpR+ujro4tFxQBgW992VutZZD7VIkzKT5p+dzoBBAD0btR7aqupNVXVGses6QoghBBSvP1B+5PykwBAm6N9tv9ZNZYamU+1CCMyI8iEkbrR/l776+aeMiRsESKE0G8oMiuSTKzpvMZCy4LKL72b6KDGg3RVdJVXs9oHAyFCCP2GsouzyYSFtoVsvhpLjcvkyuZ0bdBVedWqlTAQIoTQb4gKhNocbbmvqM1lAIDNYLc3aa+8atVKGAgRQug3lFOcQyZ0uDpyX8kGwjZGbajhwzrrh5NlCIJISUnJyMhgMpkGBgb16tX7UUmEEEK1TTktQtlhQhdzF+XVqbaSD4QSieTu3bve3t5+fn5paWlUvqWlZY8ePSZMmODo6KjcGiKEEPo5QomwSFgEAEw6kzyAUBY1cRQAuph3UWbFaqcSgfDKlStLliyJjo62s7MbPHiwjY2Nrq6uSCTKyMgICQm5c+fO/v37O3fuvGXLFicnp5qqMUIIofLl8nPJBYJaHK3S6yKoFqE6S93B0EHZlat9vgfCCxcuTJs2bcaMGWPHjrW0tCyz9OvXr48cOdKpU6ePHz9aWFiUWQYhhFDNogYItThapb+lWoSdzDqx6CzlVau2+h4InZ2dY2JitLXle5NlOTs7Ozs7/+9//9PVrdOLThBCqDbL4UsDYekBQgBob9KeTqNLCMmQpkOUW69a6nsgbNiwYYWlhUIhi8XCtiBCCNVmVItQW6WMQNjOpN2z0c94Il4bozbKrVctVdnlExEREUuWLDEzM6vW2iCEEPp11JRRXW7ZvXct9FpgFKRUsNdobm7uuXPnjh8//ubNGwaD0a1bN+VUCyGEUJVRgVBHRX4RISqt7EAokUj8/PyOHz9+5coVHo/HYrG2b98+fPhwQ0NDJdcPIYTQz/reNVrWGCGSIx8I4+LiTpw44e3tHRcXZ2RkNH36dCaTuXfv3jlz5tRI/RBCCP2s75NlyhojRHJKBMIhQ4ZcuXKFzWZ7enru27evR48eDAbj2LFjNVU5hBBCVYAtwp9SIhC+ffuWzWavX79+woQJmpp19KhihBD6r8MW4U8pMWt048aNzs7O8+fPNzQ0HDVq1J07d8RicU3VDCGEUNWUs9EoKq1Ei3D48OHDhw+Pjo4mhwnPnj1rbGzcqFGjqt1aLBZHRUWxWKwf7VOTlJQUEhKirq7epk0bFRWVqj0FIYSQnPLXESI5ZawjtLKyWrt2bXx8/P3797t16xYYGFhQUGBra7ty5cqYmJhK3nf79u1aWlr29vbz5s0rs8CyZctat269Z8+ehQsX2tjYfPr0qeo/AiGEkAyqaxSXT1TGDxfU0+l0Nze3kydPJiQk7Nq1i81mr1q1ytraupL37d+/f3R09KpVq35UYMSIEQkJCbdu3Xr9+nXXrl1Xr17903VHCCFUlmweriP8CSUCoVAoLF2iXr16M2fODAoKCgwM9PLyquR9GzVqVP6iw+bNm7PZbDJtbW2dl5dXyTsjhBAqh0AsKBJJz2BSZarWdHX+A0qMEdrZ2VlZWbm7u3t4eJQOY/b29vb29gqvQXZ29pEjR/75558fFcjLy/P39+fz+eRHLpfbo0eP0sUEAoFAIFB49RC+2GqCL7aa4IvN4GWQCS22VpnNmyoQfKOQu1Wr+/fvFxUVkemgoKDKtLJKBMLVq1f7+PgsWLBg+vTpHTp06N+/f//+/X801UUhiouLhw4d6urqOmzYsB+Vyc7OfvXqVVxcHPlRU1Ozbdu2dLp8p25hYWFBQUH1VbXOwhdbTfDFVhN8sV9yv5AJTbamol6FQCAoLCykuvFqLYIgrl+/TgW/1NTUyqx9kF9QP2TIEJFI9OrVKx8fn23bts2fP79Ro0b9+vUbMmRI+/btS4efXyEQCIYMGaKrq3v48OFyijVo0GDQoEEeHh4V3g0Ph6oO+GKrCb7YaoIvNpofTSbqqdZT1KsQCARsNvs/8WIPHjxIpX19fS9cuFDhJWUENiaT2bFjx507dyYlJYWFhf3xxx8vXrzo1KmToaHhmDFjbty4QfVSVoFEIiETYrF4zJgxTCbz9OnTDAajyjdECCEkC9dO/KwKWnjkqomAgICYmJhly5alpKQMGjRo3bp1Fd43MDBwyZIlt2/f/vDhw5IlS65cuQIAxcXFDAbj/fv3ALB48eJr165ZWFgsX758yZIlO3bsUMjvQQihOg7XTvysCo5holhYWMyePXv27Nnp6emZmZkVlmez2To6Or169SI/qqqqAgCLxfrnn3+MjY0BoFOnTnp6elR53NENIYQUgmoRYiCspMoGQoqenp5sAPuR5s2bN2/eXC6TwWAsWrSITJMzcX726QghhMr3fX817BqtnBJdow0bNqRVpKYqihBCqDJq5OgJ1unTau3acf/4g3XpEu2/Nmu3RItw6tSpOTk5ZZYLCwu7efOmUqqEEEKo6pR99IREwlm5kr1jBwDQw8OZ164RurpFDx5IrKyU8XRFKBEIlyxZUrpEbGzsihUrbt++bWRk9PfffyurYgghhH5OWlFaTE4M1TWqxdFSwkNVpkxhlVyiQMvKYu/cWbx7txKerhDljRFmZGRs2bJl586dLBZr4cKFy5Yt09DQUFrNEEIIVV4GL8PZ2zmTl0kD6RiWErpGGW/eUFFQ1LevpGlT9pYtAMC8eJG2Zg2h/d8YpCw7EBYUFOzdu3f9+vUikWj27NmLFy/W0cHZRwghVHsdeX8kk5cJAAQQZI4SukaZ//5LJkQeHryTJ4FOZ9y7xwgJofF4rNOnBTNmVHcFFEJ+HaFAIDh06JCVldXy5cuHDx8eFRW1ceNGjIIIIVSb8cX8oyFH5TKrffkEQTCvXSOTggkTgE4HAOHkyWQO6/Bh+LaDSi1XIhB6e3tbWlpOmzbN1dX1w4cPBw8eJNf8IYQQqs0uf7r8tfArAOio6HAYHADgMrl6qhUvdfsVjNev6UlJAEDUqyfu1InMFA4ZQujqAgA9Npb54EG1VkBRSnSNrlixIikpqU2bNhoaGps3by7zAtlt3BBCCNUG+wL3kYk5TnM6m3U+E36mr1VfMiJWH+bVq2RC5OEBzG/RhMsVjh7N3rULAFj794vIw4KEQqDTobbuplnGGOGbN2/evHnzowswECKEUK3yLPFZSFoIAKgyVce1GKejouNo6FjtT5VIWN/6RYWenm/eMA4eZEVH05OS6Gb6G28zfPTFKcxHj+hhYfSkJJVx42hFRcDhiJs142/aJHZ2rvbq/YwSXaNxcXFERWqqogghhMp07sM5MjHSdqTStlVjvHlD+/IFAPj1jZf79ejZU9XHhxUUxEhPpwWGc/fY7AAAIAjOypUqU6fSyAMC+XxGUBC3f3+Gn59yKllJijxWCSGEkJKJJKLbMbfJ9CjbUUp7Luv4cQAQA6M368G2HSpyp/6dL3AnE8x792hZWbJf0YqKVIcNYz569KM70/LzOStXsnfvBmU1vb4HQpFIVPnLKnPUIUIIoer2POk5uWrCWN3YwcBBOQ+lpaSwLl8GgAfg5pfSlMzs2lV082aRhgYBAFGJ3Df2k8j8QlA7Sxv1eOuLwsBAiakpAEBxMWf+/DLvnJhIfzL58uFt/IfLXrD37VPCbwHZQHj+/PmBAwcGBQWVU1oikfj6+rZp0+bz58/VXzeEEEIV8I32JRMe1h5K2w6affgwCAQA4GPgReaMHi28epXXqZO4Xz9pm+qs2cICUN8ASy0gdhRx2m1R+1C+De/uXUJNDQDonz/TkpNl7xkVRR8wgGtrq9bv5swZsKcv3Hy56gktKYmWl8e8dYuWn199P+f7ZJnu3bvfu3fP0dHRzs5u0KBBzs7OjRs31tXVFYlE6enp4eHhz58/v3jxYlZW1rx58xo0aFB9dUIIIVQZBEHc+nyLTLtbuVfHI+gJCbTYWJZAwNLQgLZtAYDG47GOHQMAETCvFvUgi40bJySj8JAhonPnWABw4Y3VHZWwT8XSYCEWw4ULLNvVZhJHR8bTpwDAePdO9G2F3qZN7E2bOAJBiUffLHbrPGoUPTGRlpEhdnAoevy4On4gyAZCAwODkydPzp8/f8+ePf/8809hYaFcUUNDwwkTJkybNs3ExKSaaoMQQqjy3n19l5SfBAC6KrrtTNop/P6ss2dVpk4l05oAov79izdtYu/eTQ77+RkOz0zlAICJCeHkJB0v69JFVL8+kZFBS02lpUKJJtO1a8zVq/ni1q2lgTAgQOTuDgAREfS1a6UrPZg0cTMiPATsAOAFdGAELSDzGYGB9NBQSYsWCv+NUHr5RMuWLQ8fPrx37963b98GBwenp6czmUwjIyMnJydbW1s6HSfXIIRQbfHvJ+kOZ30s+zDpP32+bIVYR0vsVsO8dk39xg1qv5iLDRdAKgCAh4eQ6pRlMmHAANHhwyzyI5dLrFvHX7mSk5dHi42lh4TQHRylSzsYAQFk4vFjac1tzXPPJLiYQWJ9yCCAFggOPOBygSetjK8vXzmBkMRmszt06NChQ4fqeCRCCKFft/vd7r2Be8m0u7Xi+0Vp2dmMwEAAAAZD5OTEfP0aCIKKggIHp2vR0rDk6VliruXw4UIyEBoaEufP8xwcxK9fMy5cYAHA9ess3d5t38IYD7iuFRQEYjEwGM+eSRfaT5fsaQnBANC03tcPmYYCYL/hdOrQhca8excAmDdu8JcuVfjPBFw+gRBCtdDblLdBX4PExA/n5y99vHTZk2USQgIAdvp23Rp0q+Sd6VFRtOzsypRkPHwIYjEAiB0dc319044eJfT1AYDQ1+dv2XL/7wfpGXQAMDIinJ1L1NPJSbxvX7GXl+Dx40IHBzEAeHhII+Xp06z2AyzGgrcnXKUVFNAjIiQSePFCGghdk04DALBYbV2lPaWPFl8vPnECuFwAoIeF0WNiKvkzfwoGQoQQql0OvT/U7Vw3lzMuFvssxt0cl1KQIlcgIDWAagt2MO1wY/ANNoNd4W1pPJ7KhAlqjo5qjo60zEy5b+nx8apduqj26UN9xXz4kEyI3NwAgOfqWhgQUHTjRmFIiGDy5INHVclv3d2FpQfNRo8WbtjANzaWLgR0cxOpqREAkJxMy8mhAcATcImAJox378LD6VlZNAAwgpQmEAE0WvE//zi7cckLX71iEGpqoq5dpVW6caPCn1kFGAgRQqgWKRIV/fPqHzKdw8+58unKWN+xZMuPsuPtDjLRw6LH1UFXK7ObDD0pidu9O8vHBwBoGRkMf3+5AuzduxmBgYznz1knTwIAEAQVCMXdu5MJQltb7OJCqKp+/Ei/eZMJAHQ6TJggrPDpXC706CHfuj0NoxkBAc+eSUfoXOAJ0GjF27YJJ05s21Za+PVrhkQCIg8P8iMGQoQQ+v0dCjqUXpQOAHSa9O/zq+RXx0OOUwWis6PJtYM0oK3utLpSO2tLJAkeC3eEdI+BRmQGvdRacMbdu9LEkycAQA8NpaWmAnmyhL29XOGtW9nkWGHfvqKmTSt11tLAgdJ4qasrbSaegVH0gHfPnkp/Zhd4LFi8WDhhAgBYWEgMDQkAyM2lffxIF/XuTW7qzQgIoKXIt49/HQZChBCqLQqEBTsDdpLpnW47F7VdRKZXPFtBdZDuCthFNhB7WPRoVr9ZOXdLTKST/ZBZd4Ncoo8vgC0tIfgU/AGlAiE9MpIeH0+mGa9fg1BInaAkcnWFkl2fsbH0K1ekk0IXLCi59O/H3N1FGzbw584VvH1bqKsjAYA4aPjsg95Lv2/rLtTfyh7kSzUK16zh7Dlr8NlxEACARMJ8/ryST6w8DIQIIVTDJIRk5v2ZTQ83dTjmQO6X1lCr4UjbkQudF9ro2gBAniBv+LXhTxOfXvh44fzH8+RVc5zmlHPPzZvZzZur2dqqPX3KmP8/zXTQA4ACUB8DJyfBYdrnErNOmPfvU2laYSEjMJAMhAHQutmTw+bm6lZWur16GQUHMwBgwwY2uSNnt24ie/vKbrdJp4OXl2DVKr6eHjFosPSqBZJN2TwVADCGZIvJXQhNTao8FQhv3WIuXcpx+7RfBEwAoJMTWRXqh+tOUlNT7927FxcXV0TuGv7Nxo0bFV4JhBCqyw4HH/YO9ZbNWdR2EYvOAoCdbjv7XOxDABH0NaifTz+qgJORUwdT+RVuIhGkpNDFYti7l3XwIBsA8vNpAwaoCoUl9iA9AhPHRtxsKZPDkAmEAMA6fZocRFxC+yc6TYvMzMlhjxjBXLFCcP78TzcH5QwbJl1f8Q6kawq7MJ4Jpk+XLePmJmIyOdQe2HE5OlfBczBcYpS7D2jVlB0IT506NWXKFB6Px+FwVFVVZb/CQIgQQgqUlJ+06tkq2Rx7A/vhTYeT6Q6mHVZ3Xr36+Wqh5PucFC2O1mbX72enEwRcu8a8do314AEjN1d+u1Hht+vGss9FOQx++YoFABEZeq14PILLBQBaURHz5UvZS1gnTwJBxEMDP+haoqpJ9EmTVMj0oEGiDh2qePqCk5O4USNJTMz3LskB3bLJtRkUGxvJgwdFL18yXr5k+PoyAWAveA2GS/TgYHL1YdUeXaayu0bnzZvn7OwcGRlZXFycVZICn40QQmjOgzkFwgIAaFa/WeD4wGejn90ffl92m5jZrWcH/Rk0tsVYDoNjpmG2ouOK93++pw6a4PNh4kSVMWO4ly8z5aKgh4fIwkI6k8UMErd6POjaTfoxkrCmfRsmZDx9CsXFAEB82/mTPP/oBIyTEDQA6NZN5O2dL7uht54esWVLcZV/Mo0GGzbwTU2J1na8hVaX/dov6XWwV+liDg7iGTMEW7YUs1gAAI+hSxg0pxUW0iMjq/zoMpURCNPT0zMyMtatW2dtba3YhyGEEJJ1JPjIvdh7AECn0Xd3322lY9VSv+XLZ1xzc3VHR7WkJGnwMdc03919d4JXQujE0Plt5tfj1iPzs7Jo/fur+viwqBvq6xMNG0osLCTz5wtOnuTduVPUiRtgDgmnYbTqoO6WltJAGAXW1HwZaoBQOGyYpJF0WqkE6CdY0nOUxowR9u0rmDo1j3rKtm3F9er90mGBvXuLPnwoePRctDywh+OdZUS9ej8qaWxMUCda7IPpAKDw3tEyAqGmpqaqqqpAUMXOX4QQqg3SitJm3Z+1wX+DSPITh60q093Yu4v8pPNCJ7ea7GTkBACfPtFHj+bm5NCiougTJ3Jlz37lMrnUmgoASEmh9eql+vKltJNwzBjhy5eF0dEFISGFwcGFK1bwGSlfLDbPfcpziocGndTeiVxdrayk0YsKhLTkZOaFCwDAB87WvMn79FcQQAOAx9AlTmgCALq6RJ8+IgCYPz+7WzcRAIwbJ+zfX6mvdPJkaTw6BX/kgpbC58uUMUbI4XBmz569ffv2Dh06sFis0gUQQqj2W/ls5enw0wAQ9DXIu583l8mt6RpJ5fJzH8Y9DM8I3xe4jwzSDgYOqzqtAoCsLNrQody8PGlD8OVLxubN7CVLymiWJCTQ3d25sbF0AKDTYc0a/syZJYoxnjxRHTKE7PMEAHGvXsDlUi3Cz2AJ0TEAoDJ3Li0vTwyMEerX/z3aBKCJGAJnw85jrCkgBAAYMkTI4YBAAEwm/Psv7+tXmoGBkg6Op3ToILa1lYSH0wtA/SBMmR/kp9j7fw+EAQEBly5dItMEQfj7+7do0aJbt24aGhqyF+BkGYRQqd5SrwAAIABJREFU7ccT8a5GXiXTd2LuDLwy0GeAjzpLvWZrBQC5/FyXMy4xOd9XLzTQbHBxwEUOnXv+PGv1anZSkjS2kSvWN23itG4tcXMr0QK7e5fp5aWSlkYDABYLDh/mDRwo30RjHz36PQo6O/NXrgQADQ1CX5uflsMpBpUvHwvuzQ5+fHtsW2gcTmv+b4H0ZMGVtFUNiPjzosHkx9GjS2wco/woSJo+XeDlpQIAO2DOrLDDIBSC4tpp3wNhZGTkoUOHZL9LS0s7d+6c3AUYCBFCtd/N6JvkDBTSi6QXq5+v3tR1Uw1WiTT34VzZKKivqn954GU1wqBPHy7VyUmnw6lTvAMH2M+eMUQiGDqUu2YN38tLAABiMSxerHL4MIsgAABUVODUKV7PnmV0VNKDg8lE8bFjwsGDqXzLRuK0QACAxxHGM961EwPjAgwDmeiWQ2gNpP1L3t/VVdSyZaU2jqluw4YJN2zgJCXRUsDImzd09MePEjs7Rd38e3fzyJEjsypBUQ9GCKHqczHiIplopd+KTJz7cI4n4tVcjQAAzn88fylC2vHWvHD6Eptj78YHWmrZjB+vQkVBfX3iyBGeu7vo8GEeuWm1SARLl3JmzVIhCNi4kXPokDQKGhsT//5bVGYUpOXn0+PiAADYbOG3jTpJlk2l7Z/9hWPFUGIRAnW4Lnl/bW1i796qTw1VLDYbZsyQ9v1uhoXw7r0Cb1728omQkJCCggK5zMLCwnfv3inw2QghVB0y81Ifxj4AABrQTrqftNS2BIBcfi65RWdN+ZL/Zf7D+dIPgRPDNu/dOHJ821bG/fqp3rkjDU7z5gnevy8cPFgEAMbGhJ9fYZs20uB04gRr4kSVrVulp0x4eIheviz80Uo+elgYGc0kjRsDu8TBFJbf5ssEQGsy0dg4r149YtAg0e3bRb16fQ+r27YVm5jUTEdomcaNE+qq8gDgM1heva2mwDuXHQh79OgREhIilxkSEtK6dWsFPhshhKrDjb88hYQIANpqNW+o1XCU7Sgy/1TYqRqs1ZnwM/mCfACATBu4Iz0+4ssXGnUa34IFgpUr+erq32OPkRFx61bRsGHSUTofHxa500rnzuKTJ3nU7tWlMUJDyYS41JHu1HwZytGLjNjYguPHeWw2bNjA53IJABg+XEjG49pDVZWYNk66hCOA20mBd/6JvUYFAgGbXfGRVwghVINUQkPPMz6Q6T8ufmTv2zeiyTAGjQEATxOfHn5/uJ9PvxXPViizSg8fMs3N1ddflh7vAH6rmjTijh8vlI1kAweKli/nl76WzYb9+4tdXb/HJC0t4sCB4tJHAMqifwuEpQfS5AJhPW1R8+YS2W9fvCi6eJG3b19t6RSVNWO5Wr/e/HZO/D9XGSrwtiWWT+Tm5mZmZgKAWCxOTk6OkTkLODc398SJE+bm5gp8NkIIKZ73gVf2AABMCQwJFnH8l9gcP+46sfn9wmAJIZn/aD4APE182rNRz/Ym7ZVQHbEYFi3i5EiSwTAAAEDM5n7p5X2H17SpZNs2ePmScf8+k8uFuXP5NPnN0aSYTDh1qrhHD9XwcDoAbN3KNzWtYAIL/VuXXlktQoJGk44CAoCL/NkSYGUlsbKqFRNkSlNTI85eUPwa9xKB8NixY/PmzSPTQ4YMkS/KZO7Zs0fhNUAIIUWhx8e/iXkocQAAaJPFrV/EAwD6p0+TTsD9kn/S7sbcVU4g/PdfZlQUHVrfABoBALSEzrs3qzRtKgQABgM6dRJ36lTxjp0aGsTVq0U7d7KbNJEMHVrRQbgiEePjRwAAGk1SKhCqqhJGhpLkFGn0c3GpXf2fNaJEIOzbt6+pqSkATJo0acGCBY0bN6a+0tHRadq0qYmJibIriBBClSQQsHfufNBQ2prp1Gs6v546e/t2Wl6exycwzodkDaABjQACAB7GPyTXsFcrgoAtWzgAAI2vkzl/D+01tFPFR7oz/fwIHR1xq1ZUjoEBsX59GX2npdGjosgVhBJTU0Jbu3QBSysi+dvptl26VHHj7N9JiUBoY2NjY2MDAMXFxT169DAwMKihWiGE0E+gx8RwR42ih4cDwKOZ0kyXRt0EnTsKx4/njhrFefHi8QnwddJut+KEy4OhArEgNC30a+FXA7Xq/St34wbzwwc6sAvAQroZytBWvSu8ir11K2fVKqDTi/ftE44c+bMPZfx4gJDUqJHk2TMGAJiZSahdueuyssdb//jjD4yCCKH/Cva2bWQUTNCCyHoAAFwml9y6k9DV5R05QujqWmfC3Ds5bdt5tv8sAAACiEfxj6q1VkFBjP/9jwMAYHUHmMUAYKdnZ6ZhVv5V9A8fOBs2AABIJCpeXsyr0v1x6KGhnCVLWN7e5VxLS0ujBwczXr8mP5buFyXZ2EiDX9eu2BwEkG0RPn369ODBgxVecObMmeqsD0II/SQej4oWD+y1AHIBoL1Jew6DQ2YSJibFe/dyR44kp4j0iobHDQEA7sfeH9FsRHXUiM+HXbvYGzdyyLMAGS0ukwGnj1WfCq4Ui1W8vIA680As5k6YID52jKDTmX5+0qWBFhbizp3J7xlv3rA3bQIOR2JmxggPZzx/DjK7dJeeKUMaMEB49CirqIg2ZQoergAgGwizs7NDvzWof92ZM2eOHz8eGho6YsSIHTt2lC4QGhq6atWqd+/esVisSEUfLoUQqjuYt27R8vIAQGJldXeqA0RcBICuDUqcKCvq25e/Zg3r6FFaenrP6IIlbgAAfgl+EkIie55DOV6/ZqSl0fr1E5We23n/PvPtW8aoUcIGDSQAcP06c/lyDrkdNgCoG6YUN7tC7mHmYeUhf3FJ7L17GeS+JSoqElNTenQ0CIWMx49LlNmzh9e5MwDQvn7ljhhBS0//0d1+1DVqakq8f19Yfk3qlO+BsH///v3791fUfdXV1adOnXr9+vWioqIyC9Dp9F69erm5ua1YodQFPQih3wzr/HkC4JItfBxo+iDuAZnpYu4iV0wwa5Zg1ixaUZFd8+ZG+RkpGpDJy3yf9v2E23Js2cJec/sEoZE4M2juur9LLKeOjKQPG8YViWDvXtby5YI7dxiPHn3/u+rsLG49f+/eDwIAaGvctrle8/IeIxSyt20jk/wlS4QjRnBHj2a8fSv9llzlIJEw792jf/4ssbBQmTJFPgrS6RILC3pCAgiF4nbtJLjgrXLKOIZJIciY6u/vn5+fX2YBW1tbW1vbJ0+eVFMFEEJ1AS09nfno0REHmOQBAI+hGACgHrdeC72yewUJVVXh9Ok9QlZ7twIAuPf5bvmBUCCA+fNVvD8chr5eALDnba7H63+cnb93P27ZwiZ3e8nPpy1axKHydXSI//1PMGZ8YasTx8icya0mS+uclUUPCxO3aQMqKrLPYvr50bKyAEBiaiqYNQuYzKKHD+mJifSQEFpGhrh9e85ffzFv3waJhL1vn0Rfn/noEQAAnc5fuxYEAkJbW9S7N2FkBHw+PSZGYm0NP1qZiEoqLxASBJGcnMznl5iw2+jb+cVKIxaL09LS4sgNZAHU1NT09PSUXAeEkHJk8DKufLoSnR0dnxtvrWu9suNKJr28P1Osy5dBKLzcrERmH8s+5XR4CidP7j1gi3erIgC49mj3MtXe1CqFyEi6igqYm0vnkly7xlyxghOTGw1TF5I5hN3J/7N3ngFRI20c/yfZThFBqoANu4IodgTsYm9n7+3s3bN79t49ey9nbyeKDVEpIhbsBVFEQZqCoLDLliTvh4RlwUURPe9eL78vTCYzk0l22SfzzFOGjFwQdpVUKFgAL1+SR4+KUWcNSl3C1d8RXwMARWHQIM20aZqiRdljkacSMhIA2JvatyvXDgD56pWiRQvizRtdo0aq48eJxET5kCEgCNX27aLjx7mr6Dp2hIi/a8bJiXHi7Ws0w4eLzp4FIN66VX87mvHjNSNH5rpDqZSpWPEzD+3nJjk5Wa+JTE5OpukvGwQZ/4Z9/Phx1KhRhw4dysrKG2WHZX90DNbIyMhr166tWrWKO1QoFH/99Rf5SXyh5OTkHzyx/wjCg/2bEB7spwTEBcwIn5Gq5rPcnI0+a01ad3Xp+pkuTnv2qEUIKsEfjqo6Sq6T96zUMzEx8fZt+YoVVtHREpomihXT9euX1rlzOkUBQP06vRXazUoxHikyYjp72/Sd+H7w4NMB9Hj/NSStWNV6VNOGuvHj7c6dk4PUYUBfiLO3eKQfXpodmDSp68yZbwHMn2+rc7yCFmMBWDq/SV9+291dNXPm24oV1cos+lCY3+p7vIVE51KdU5JTRElJjj16EG/eABAFBmrmzDEJCOC8HYjBg6lbt7jGST4+WYmJRu62fHnn8uWlkZH6iqzq1eMGDGCNNv6uaLXazMxMjebfblzDsmz79u31SSNUKlXRokW/2Mu4IBw5cuSJEydmz5597tw5S0tLX19ff3//8+fPL1iw4HtOuWBUqlSpU6dObdt+YZMZgJ3d94w+J6BHeLB/E8KDNWTy5ckb72zMU7knas+o+qPyW96RT5/KHj68VBpKMQC4FHVZ0HRBYmKinZ3dvn3isWNl+t/t9HTJzJk2hw4Vq19fZ2aGJs2W+F72PyaOBXC4Evv7tm3SqVM33lsGj00MMPGgc52DIzlPO3gtgOP1XFetsXn/tl9HjhSbmODkSQX6Teaq38si7j2PKmllBxTN0Ga0OdLmdiKfrkdCSUbXG23HmihatyZjY/UjWWW/3wMwucw7GjKlSlk0aZLfU2LHjcPQoQBYuVw7dKhu0iRb0x+RbVij0WRkZFhaWv6Aa30j4dneIwBOnz596NChL3Yx8vViWfb48ePLly+fPHlyyZIlK1SoMGjQoOPHj0+YMOHw4cPfc74CAgICAIDzL8/rpaCjmeM8r3lFpEUARL2POv/yfH69xIcOAbiYvV3TqEQjrrBmjWT4cNmnq5eHD8nNmyXLl0tatS/i4raIqzxcGcT792zI9WiKv5C26jZeCpa+RHjP4yrH1RwnF8kBwP4ObR8+Y4b0119l2rLHUPwG14AlEPLqDFfecHuDXgqaS8w3t9hsa2Ir3r2b5CzkJRKmTJn8bkrXseNnHpS2Wzf1kiWayZMz791Tz5nD/hAp+NNjRBC+ffs2IyOjQYMGAMRisX6NOWLEiLCwMP1e3ed59epVQEDAq1ev3rx5ExAQ8OLFCwCJiYne3t5cdt/MzMyAgIDbt29rNJqAgIDr169/aUgBAYGflhXhK7hCi9ItwvqEjfEY09+1P1ez7tY6430YRsQJwmyZwrlMpKdTCxbwRitVqzK3b2dGR2fMmKHmdvU4aBo7prZXiEwAPLHGQxtc3XeDts7O9WrzEI7hMIuX9+rOEjQAb2fvWZ6zOpXvxDfw2Hjxoij0OoPG0w1ndDFsD4CPmo/rI9ZzNSPdhz8a/IjrKDpxgqtUL1igOnyYlcu5Q12nTqzBSkv7WUEIktQMG6aePp0V1AnfDyOC0MzMDAC32ejg4MDJMAAURQF4//59QcYNDw9fsmRJenq6RqNZsmRJcHAwAJIkFQoFQRAAUlNTlyxZcvbsWQ8PjyVLluzcufM73ZGAgMD/GaFxodfjrwOQUtLVTVZza8Ffq/0qJsUAQuJC7iTd+bQXFRJCxsW9NcFdOwAQk2IvJy8Ap06ZcbYNVaowFy4oy5ZlihVjf/tNc/9+5ubNWUuXqu3sWABv401M3rTmhjpcGXtjokEYBBurtc52dEcV+RaAnYnd9pbbKYIa6DaQP+u6D47X4bkIVs8AyLNDhwZm3Nd9TNuxvMv7rPcAyqZg6QWWux0iLo53hBCLtV26MGXLqteuZU1Ndb6+qo0b1XP4qKdMuXL5hYMR+Pswskcol8tdXFzu3btXo0YNHx+fxYsX79+/v3r16gsXLpTJZC4uLgUZt0uXLl26dMlTaWNjc/bsWa7s5OR08eLFb5y9gIDAT8CKG/xysHul7g6mDly5uFnxjuU7HnpyCMCO+zvWNc27LhQfPAggoDQYAgA87D3MJGYADh825xoMHqwxMclZBdrYsN27awFUrky3baugaby90hVdDwHYXQ1ZL3M75Ln+mQQAEJGiHa122ChsqOvXayclNSrRKPBVIEgaXTvBlDdRmf3EdmOJ5JgibLqYDu3ruab6a65+ejBk8ccyFiwCSYr/+ouLC6Pz8WGLFgWg7dpV25W3A9L27k3dvUtdu6ZetOgbH6ZAITC+BT18+HBuIejj49O6deuePXtWrFhx//79S5cu5daLAgICAt+Fe8n3LsVcAkAR1NiaYw1P9avajyvcTLiZt1t2WDX9BmFdm0YfPhAREVRkpBSAQsHml2C9QQN62jQ1AET5IsMWwOsiSHbjNwhNmVz+8ot9Fjcwd5UNG6Zo1kzeu/eWm/bmEnMAMIvnVpANX2Jo303NaX4evT1ev1MAQJlU9LwPIjmZswXV60V1HToYmRNJZq1alRkermvUKP9HJfB3YVwQjhs3Tm8geuTIkTt37pw4cSIyMnLUqFFG2wsICAgUjkmnl3J5kegHnVvWcV29mvdPB1DNthpnL/os9ZlKpyIfPFC0bi2dMgUsK7pyhcjIAHCpHK/WWje2dZkypoMH8y7qHTrozMzy9fWaOFEzd65aJpLh2kS+imAAUGqT6YE5NjbT600fKm1gUqeOODvGcpkNfy5V5Egyxw84EGBBNPBuWqsnV5OW7SI/VVtXxACA6MwZQ72orlWrQj4pgb+NLwfZIwiiWrVq7du3L5O/mZOAgIBAIdh1/sH196cBgCURPD0+npg1S+rjo7h4UaRWw0Rs4lLUBYCO0T1+91g2dSoVFCTZsEF07hznV/7CEq9NdABIrbn2lYdajago/jetT5/P5fwjCIwdq7l2LbMGOwSZOQE6SsU4D46AvUoEYLTH6Mm1Jsl+/ZWIizPsO2TqYV/r+gCkOhw5DEufVhCJPH2HyWg+jAsFcnKdyT0ajuMORf7+4uPHeb2otzdbALc2gR9MviEbYmJitm7d+ujRI41G4+/vD+DAgQMWFha+vl9OpiUgICDwGa5do44fFycnE35mi1CGBUA++YVJ4o1E7t+nOnWSm5qynTrpqpQy5ULy33t2lYgLGT4CFd9ix5+7ZDfuAHwSCQDMSy8wOb9m5coxdet+OZ6Iiwvjf5Ks99u4F6WmcTXNYmClxNPVupen9peu21q8fz919y4AVi5Xr10rWbGCfPqUUKkOr3h9rLS166O37glQtWkDQCE26erUanf8aUeR1ZaOez0dPXUqFatQEEolGRkpWbiQG9+4XlTgn8b4ivD69etubm5btmyJi4u7f/8+VxkbGztu3LgfODcBAYGfkPh4okMHxZYt4pM3I+gypwGAoY6N/i019ePcuepsnwJkZBC7d4tvXGjAHT644z+1IfPYGscqoY/iLJOcmAybfWWzI8rE+ADo2lXbpInOwUG3ZEmBMrkDkMvZiwv6S7TFuMMBLmUBmKtR8fhVQqWSzp3L1WtHj9Z27ar680/WzAyAaXRs34C37glgFQpdQz7NxZqu+0J7h94e/tjT0ZMbmm7cmDtFKJUAmFKldJ06QeDfh3FBOGzYsNq1a0dHRy9fvlxf2apVq8jIyKSkpB81NwEBgZ+QNWskKhUAoOEsrqalc+fGrmVFIowdqwkPzxw5UlO6NO/JEJfYhitcSrsd7siP8FcFjGguqY6IK47Z+s+XDa2s2JUr1cePq65cedm4sXEzGaMUMzfZ0XFNCUWFEW7jKnYZzFWKjxyRTp9OxMcDYO3sNGPHAmDKls3atUsfBRQA3bQpskU3SZBVravyTvcAAF1Lg+yDUmnW7t2sQlHwiQn8MIyoRlNTU+/evRsaGmpmZkYYBC8vUaIEgPj4eCF5vYCAQOFISiJ27ZIAgHMIXM4DoAhqftPJ+gYlSzILF6oXLlTv2SMeO0qsS3Dn6mPMcqk6N9fWgF4Fs3gAUBVFYrVJizSfsY75PG3Ltmlbtg0AmmEYZ2fy9WsiNVW8bRt3Vj1zJmtiwpV1TZtmLV0qGz+eP2zT5jPD6po3B0VxmXKzFizQh/YW+LdhZEXIhVU1/SRyT0pKCgCR6O/K3CQgIPDTs3Ytvxw0bTOTq+lWqRtnEZOHfg2e/cn2gMoSaSVynfiQvTCsx3sf4pW3ezV24MDvEQ+aJHU9expW0N7e2tw12kGDNOPHA2BKlPi8CShbrJhm2DBQlHbAAO2QId9hegJ/D0YEoY2Nja2trZ+fHwDDFeH+/ftNTU3Lly//42YnICDwf0tGBhEVRep0UKuxZ4/Y11fh6mqyebMEAEoFZlhfASAmxZPrTDbaXXTxYmcctUIKEgzyBbIkdl5FcmXDltN61A0MVEqleUcoHNrevbngZ2zx4lnLlyuPHsUnuW7Us2dnPH2aefOmfqWYH+qFCz++f5+1evX3mZzA34OR5R1JkhMmTJgxY4ZWq3V0dGQY5t69e4cOHVq+fPlvv/0mkUg+7SIgICBgSFwc2aiRIjGRkEohl7NpabkyxJq0npUJAOhVpVfJIiUBkNHRkuXLqTt3WEtLxslJ26sXdeECCcYbV48nuqMi742ON7XwvjRO7MGgOqD4DcLWlRtwyZW+C4yjozI0lHzxQufjg/ylK+vg8N0uKfBPY1zPOXHixNTU1IULF2q1WgDVqlUjSXLgwIG///77j52egIDAvxGWxZMnpLMza2pqZFuOYTB0qCwxIwmOr9RxtdTqXFJQ6hKaaRUKQEpJJ9WeRKhU0unTxbt3Q8sLNooLn0ZRABri8vGE5jmdn3SUyZCVUB1XZ6HRTABWcqvKxXItEL8dxsWFKVgsSYGfg1xLfn3SXYIgFi1aFBMT8+effy5btmz79u2RkZFbtmwRi8X/xCQFBAT+AfbvFzdqpNi+Pe9//evXZNu2ijp1TFxdTUJDKQBRUaS/v0ifxnvjRklQ6hGMKYNBddB2MAjG0ZGdP199927mgweZreeu4Zp1q9TNUWEv699fvG2bXgryMAxX410qBonuOfVPOuzYoWrWTFdHN8nLroWIFI2vNd5wB0dAoBDkWhFWqVLFwcGhSZMm9evXr127toODQ48ePf6pmQkICPyDxMaSY0eJs7TU3QiiXj26YkXen+HgQfH48dKMDALAu3dEu3aKOnXo4GCKZdHA6eVp56F3K/8y89ULdFoCggWA6tvbl7+3y32SJCuTUVdOcLb0e/EXN9Rgt8HSadNE/v7cIe3joxk3DiwrWbyYys7LVq51aeuDDm/j6sDxOqKbmOvKtGiR0bo15x0hpEcV+D7kEoT169c/efJkQEAAAHNzcy8vLx8fHx8fn2rVqlHfUQcvICDwr2fBNF2WlgKgY8hZ7Z8fuecAmSwslBj2q4Rmc1ZgGg2Cgvgfh+DYUg0S5j0qvoiue9JwqJMmt6yedi2iRr1AsljNhhpaA6CulXutOZvFe/fy44wdq872XtfVqycfMkR08iRIku7YwSuePrb7Ehxu4U0tb19asFsX+O7kUo1u2bIlKSnp4cOH69evb9Gixc2bNydOnOjh4WFlZdW2bduVK1dGRET8UxP9D0LGxsp79ZJOmQLdV3gHCwh8O48ekQdPmesPzye4Bdf+PfNyxJDOKpolAVTC47+K9nUzieIakGAAQP7+fu9JdCVeCvo8Mx34kLeto0mkynHahdn1/hJXM3rbfb0U1HXooJ49O+fyMplq927VgQPKgAC6Rg1PTx20Crzygk7WpInwvyDw/cn7ckUQROXKlStXrjx8+HAA0dHRISEhoaGh586d4xwq9PuIAt8RMiZGNmAA+fw5ANbCQr1iha5RI1mfPtTt2wCY6tW1nyR3FBD4nmg01PXrTKVKbLFiAOZM1DIsAUAKtRpSAENfTnVqF/sK1gCskHIBzYq/f9MYx+Zhphbiodj0l6jTpA4PUSKIG29AmMWmROesM/5m+/ttygjMIhnDq9l/RKeHvIO8rnlz1aZNeV0UCELvouflleNK37jxlyOICgh8LV/IPmFra2tvb29tbe3k5EQQhLAp/TchWbyYunWLSEsj0tLImBhZr16yUaM4KQhAvG/fPzs9gZ8clpX36qVo3dqkfn0yNnbTJsm5UAsAFGi/6jPMZRoAsXC6hnpc8w01tjjYMwBMkLkYU5aV2+w8t3fziBZEuTMACJALb9ptSS2rPnwE5uZzhx5PnpiWMjYltMmRBom8N8KImxDT0DVurDxzRnXkiD5KmVHKlmXc3GgA9erRzs7MZ1oKCBQOI+p2pVIZERERGhoaEBAQHBys0+nKly/v6ek5ZsyYhtnhZQW+I0Ramjg7aSdfo1IZCj8qKIiMi2McHT/pKiDwHZBs3cqcC7wCHzKBudvoxOQkPhVDP2J3vXUdZoUxEyfmNO5XNtg3cERmRl/R6dOshQXt4cFaWwP489oCLq1gyzK+I8cfUOa+hJgUV3Vt7j8o9MLEVmmaDz2q9MxcNpipWLGAM/T3V0VEkB4eghQU+FvIJQgXLlx4+vTpmzdvEgRRs2ZNLy+vcePGeXp6mpub59df4NsRHzwIlQoAXa1a1oYNijZtiJSUXC0YRrR/v+a33/6Z+Qn81JDPnmHmvNY4fRFNASA7qH59hC7vEspU/WVIVa2XF/30KRl7LUGsVfZf5AaCYM3MnrSoGRwbfDPid4VYMbP+zP2P9nMde1bumc+lwJYr1/RUFIDPpQo0hpkZ6+0tKEUF/i5yCcItW7YkJCT0799/8uTJQhreH4Z4506uoB0wgKlSRXXggKJtW2RlQSLRjBolWbECgHj/fs2kSRBU0wLfgHj3btHx40ylSnSDBmRcHHX1KhkVxb6K7a3aykvBbNxx52SbzaK1yzmLgAoVmAoVGLTPSWC78sbK2SGz9YcXX16M/RgLoJi8WPPSzSEg8H9FLkE4ceLEs2fPHjx4cOvWreXKlfPy8vL29vb29nZycvqn5vfTQ4WFkU+eAGBNTXW//AKArlOLqTdSAAAgAElEQVRHeeiQZM8ebYcOuqZNxdu2EenpZHQ0FRZG16v3T89X4P8V8e7dstGjwbK4fBnr1+vrJ2L5AXTnyu72CaqE9NLEyy3j70tn/fEuK/X84xMNnRvam9obDpWuTl8evtyw5mX6S67wS4VfxKQQdkPg/4xcgnDkyJEjR46kafru3bucsejo0aPfv39vb2/v6enJOdpXrvydoxn9x5Fs2sQVdF276gP40g0bqrK3Y3WdOol37AAg2bJFJQjCnxfi3Tvp5MnUnTtM1ap07draDh1Ye/svdysYojNnZGPH4hOT7z8wcgUmcOUhQzTLl5tSNx6zCgumyvDbibe7/9U9MTOxtEXp2/1vU0SOJ/HO+zsztBkAnMycmpRqsvP+Tv2pz+hFBQT+tRgxlqEoqkaNGjVq1BgzZgxN03fu3Ll69eqlS5eGDh3KsqzgPvEdER0/Lso2k9H062d4SqUi1q0T//GHxNl6rR9xyZl9JTpxgho1iq5R4x+YqMDfjOjyZdmvvxKJiQDI589FJ06IN23KjIjA9/AeJ2Ni5AMGcFnxaHd3ukEDKjyctbP7q1j/sTvbch6A7drpli5VA6Br1QJwLPLY8PPDVToVgOi06MBXgU1L8rpTDa3ZeGcjV55ef3qPSj3sTOwWhS0C4Gbj5mrj+u0TFhD4wXzu34xbGoaGhoaHh4eFhQkisPDQNPn8OVO2rKGzFBkXJxszhitru3Zl3Nz0p44eFU+fLk1IIACkpZl4KW5eUtYtw76QzpypzI5HJfDTQF25Iu/QAUwuk0gyJoa6e5f28Pj28UXHjnHWWIyLi+rYMaWFyZGnR648vX8iZC094jeYJkCSGW5q2+yQ0y8VfxniNuT4s+MD/QcybM589j7cywnCdHX6schjCRkJABxMHTqX7wxgat2pRaRFgmKDptad+u2zFRD48eQVhDqd7t69ewEBASEhIcHBwenp6QDs7e2bNm3KqUb/iUn+k2g0iIwkK1ZkCv1qTiiV8vbtqevXdZ06qbLtYojkZFnv3kR6OgCmZEn1ypVxccS7dyRNY/VqyV9/5brYK6W1NxEUytYrERIiOntW5+tLfPwoWbECWVkag9zZAv+nSJct46Qga2ubtWiReN8+UWAgACok5PsIwiDeyV0zaRJbrNiYs0MOPjkIAM45bRIzExIzE24k3PCL8rsef52TgiWLlIxJjwFw9sXZu8l3B/kPepb6TN9lWPVhEooPHDO8+vDh1Yd/+1QFBP4Rcv3gduvW7fTp05mZmQAcHR3btm3r4+Pj7e39n7UgzcpCmzaK8HCqQgVm8+Ysd/evN+DW6WR9+nARhEUnThCLF7O2ttTVq/LBgzk9GESirO3bL4YX/eUXOZ17eAcHtndv7dq1YpWKeMM6zMWs7RgoGzRIO3Kk6OBB8uVLAGzRoprJxvOaCvwwqBs3pBMnUo8eaTt31kya9FUZfMjISCokBADEYuXly4yjI5GVxQvC4GCMHfutk1Or9QGsdV5ez98/P/L0yGeaB8XyUrOiVcVzXc91PtH5ZsJNNa1ufrA5pynlMJOY9Xft/61zExD4d5ArskxcXFyHDh22bdv2/Pnz2NjYPXv2DBgw4D8rBQGMHy8LD6cAPH1KNm6sWLXqK5MSs6xs1CjRhQv8IcOIzp2jbt1SdOzIS0GSzFq8mK5Zc/lyiaEUJAgMHKi9fTtz+nT17t18bpuLZHMAxMePkkWLOCkIQHTmzDfdocA3otXKxoxRNG1K3b0LrVZ84IBJzZrSr0nbKd6xg7Nh0bVqxcVMoD09uVNUWNi3h5mlbt7U60XZ4sVX3lhJszQAvK6PA6c6JTyIHRGbMjbl0eBHo2qMIsD75ziaOR7veLyorGivyr24Gk4KUgRlJbcqZ1ludZPV5hLBvVjgJyHXijCEezMVAABs2ybety/HEFynw+zZ0nr16Nq1C7oulKxdK/7zTwBaiB+hcmU8Evn74+JFLtEaa2Oj2rqVbtjw0SPy2jUKgFiMypXpYsXYUaO0DRvyv4BNm+rMzdkPH4hYpviz0s3KRV8wvAR17x6RlMTa2n6XWxb4WqRLlujdQHloWrJ6tbZfP6ZUqS92J1Qq8X7eD10zYABXYEqWZBwdybg4IiODiogQ+fmRL17oOnTQtW5NPH9ORUQwlSrRNWsWcIZ6vSjt7X3o/Jv9Dw/xwi5giWlqvSWTMotIWQBOZk4LvBfUsKsxNmCsqcT0eMfjxc2KA+hUodOUK1M4KUiA2Oq7tXOFzgW8tIDA/wtfiDX6n+XGDWrKFBlX7tBB5+FBA2BZnDjBvzoQaWniXbvkAwaIt2/PyCAyM/O6ulOXL0tnzwYQifJups/dcacd/hJducJlX0sjil6af8VP1VSlwvbt/EKzbVtdUJDy+HGVXgoCoCjUr8+L3gujjqlnzGBtbWkfH7paNQBg2ZwVp8CPhUhOFv/xB1fWtW6tOnKEqVIFAFhWVDCbJtHRo/w+cdmytLe3vp5u0IAryIYNk6xZIzp9WjZwoKm9vUn9+rJRoxTNm5OPHhVwktTVq1zhXY0mw/atYwgtAMT44HX9sWM1Nja5LOA6lu/4esTrx4MfV7CqwNWYS8w7lOvAlWd5zhKkoMBPiSAIjfD2LdG3r1yjAYBq1ejNm1UzZ6q5U/7+IgBnuh0dXir44eg9oqNHr40/XbaMonx5kxs3chytyNhYef/+oGk/tKlN3XqS4QzgLHyDVDUTdNY1cbMom9p0SMVu3eQNGpgcPMgL14EDNUbn06ABLwiDw6Sa337LiIpSnjql68z/JBkKQvLhQzI6+rs+DIF8kSxbRiiVAJiqVVX79umaN9cMG8adKqAgFO/ezRW0AwYYhg3Sa0fJqKic1nqzUp1OumABAMkff8g7dqTyV+QQSiUfup0gdiY10FXJXrwGTffwoEeNMv59y8NCn4VjPMasabJmQq0JBWkvIPB/hyAI80LTGDBA/uYNAcDSkv3zzyyZDJ6etLk5CyAmhvTb9La3f++9dI/GuHQA3X9hD2eqyA8fiJ49+V4AJEuXEqmpGzC8PU6m06b6wRdh6hBsuYUcU8Bnz0gu2XfFioynp3Gla44gDM5RZeua84GsqMBAaDQARH/9ZVK/vknNmtStW9/veQgYh3z9WpKtFFXPmsU5xuhatOAKVFgY8f7950cQJSVRN28CgFis7d7d8JR+RcjBlCnDlCkDQG3juJ/oeQfuojNndKOmdptW0Tzg1J7eIdwuo0aTd0uRCgvjvhtM5crbLsdArAJgxZaLPFsnMFD52ZQPOVjKLOd5zRNMYwR+YgRBmJc//pBcvUoBIEls357l5MQAEIvRrBkvjX6d4aiDCMAHmPfA/lRYcvVJSUT37nKVCmBZ0blz8zFjBNYzIAE4OTEUyQI4hxan0Zob3NWVNjHJUUzltxwEULUqbWHBAkhIIJ4/5z8ypnx5pkQJAMTHj1RYGADxkSNgWWi14o0bDbuT0dFf/FEW+DoYRjp5Midj6Lp19S8lrLU1v3un04nOn//8GCYBAbyZjKcna2mZa/iSJVl9shGRSLVrV+adOx9j47rUedmT3eeBWyPYP5rt7ncS7VWQT0uZqLl0LeIGW9ZJXKkk+TzHwQGiv/7iCsHl+r1U81m9GpevaW8v+AQLCOTwcwrC45HHF4ctTlOnfW1HpZJYs4bfsZs6Vd24cc4LdsuWfDlDk9d2VIYsiZgFcPcuNWmSjLp3b01S95mYx52tWZMODla2b5/rXX3QIE1IiDIoSFm1KgPA1pbt3j1f+0CSzNkmDA7OUcDqf3857SgVHs4dik+f5naeAIh37TKpVs2kWjUiPr6AD0HgUwiVCgZ2vdK5c/X2uurcNqK6li25Qh7tKJGaKlm0SHT0qL7G9OJFvkubNp9eUeflxRU0o0ZxwRbW7Cp26pQIAANyA4br9QrvUfTMshdz+ye8V8kSP5jM6xHDT+DsWb3qdXvaL7CP4Mo1Hat91b0LCPz0/ISC8OHbh/3O9FsYtrDXqV6G0TEKws6d4nfvCADOLh+CS7Uov6X8rOBZ8RnxAJo21YkNggnXIcIti/KDb8GQVY34SGl794q3LkibhoXcYaNGOj8/laUlO36ChgD/Gu5kr509WwOgbFkmMDDzyBFVSEimmdnnXtL1SboNtaO0XhCeO0dGRxNJ2Rl0VCrR4cNcUbJxIwDi/XvxgQNf9SgE9IhOnDB1dDRxdRWdOweNRrJunWTlSu6UZsSIPJHQ9YKQCgiAWq2vl86cKV20SD5ggGTDBgDE+/fyGzcAgCT1qdgN0UyerGvUSNuzp3rq1JQU4uBB8Zw50vxmOOd6y8DY8lz55LMqj7beImNiZL/+yq043zXudDTMCQ68wryajSAIBQRykfOr6ufnN2fOnC92uPWv33+68voKVwiKDVp3e90YjzEF7KhWY+1afrXnMnBOYNwVAKtvrt4QsWFUjVEz68+sX5++coUCQIBd57FDt7bKuknJTULm9cZeJvp6YKe2x46JWBZjz/Mv+NVKpBw+LJFIAKBqVaZFC93Zc2IAq9bpTE15sSeVonnzL/uKeXrqACmAM2dEwcEUt2uoa9CANTEhMjPJqCjx3r2G7cV792oHDyafPuVSWwAQnTypmSAYOxQG8a5d0GrJ2Fh5ly5skSL61bbO11c9f36exkz58kyZMuSLF0RGhnzgwKyVK1kbGwCigACugXTqVNbSEgxD6HQAaA8Po8G1mVKlVCdPZmQQHdvKr1/PUQPUqUP3b588c4Y0i5HMH584fkUpHUtFszmuGiyIhb+pTlEe/O6gk9P2+ltVwZko9hSAiBQJ4UAFBPKQsyI0MzMrbUB0dPT9+/elUmnJkiUVCsXjx48fP35cqgCuUf84NxNu6svzQufdS75XwI779om58J7WFZ+G6P7Q12tozYobK3r79W7e+gNX0wnHqnQrX7kys+m4aT/TIwDIqKgVHS5bWeWs6sTQbtislRioUdf9oR4zRrNjh6pZs6/2kq5cmalShQGgUqFLFzlvoSqT0U2a8JfbsMGwPXX3Lvnggcgg8T11757eDV/gq6AeP9aX9VKQdnPL2rEDFPVpe23XrlxBdOqUSc2a5L175MuXREICf5plZcOHS6dP546M6kX1bN8uNpSCNjbs7t2q7sNNnySJXySx/WbZtqiY85kSYEkwAE7TvmM0y+Zi1lNx1YwdezbsKgK7uyBpABWsKshFBTOSERD4z5AjCH18fA5n4+bmVqJEiefPn4eGhh49ejQoKOjVq1f16tUrVqzYPzjXAmIoCDW0Zui5oQUJF07T0O8OWnYfq6E1AFytXes41OEq/Z77HZM17Sb+syX8VxHjeXWWTKbz9eUalOjXcoXHPv2AU5z2VamXKwqojQ07b566c+cvS8FbibfGXRq38sbKa2+uqWk1AJLEgQOq4sVZAJmZRMeO8kePSBgo4ggVH/6KKV2aK0jWrxefPGk4rCj3oUBBIFJSeJ1ztsxjHRzUs2apzp3LL8qrZsIEbd++nDsE8f69bNo0KjQ0VwudjkhJ4YsGgjA+nvD3F4WEUI8fkwwDmsaWLbw63s2NHj5cc/VqJmfnIhZDKgWAPuNzwrs0dX7S2ScJAAtiLUb/jjl1pbeXXa37+jUp6EUFBD6DkUjSGo1myZIlp0+fdnbOCcprbW29adOm8uXLz5kzx8bG5gfO8OuIz4iP+xgHQKSVSMSkElmP3j0KfB3YuETjz3c8c0YUE0MCMKtzKJI5D4AiqPXN11e1rvp78O9rbq0BcOvd7XEVevV4ALp6DaWDA9dRM2GCyN+fyMyETtf3fB8/KI6hU03cnNTvTeFuQUNrevzVIzEzkTt0MHW43OOyval9iRKMn5/S11eRlER8+EB06qQICMh0at4cIlGO1bxEol66VN65MwB9yBI9opMnNePGFW5W/1nI7OUg7eamXrWKeP9e16ABxHlzzyYnE6mpRIUKDACIxVnr1mk7dlR07Aiapq5dY2V8cAbN8OHUo0d6J3e6WjX9i0tUFNm4sSItjffA8fCgBw7UxsaSAKyt2YsXldlj5KJJR7n96LQEpQWAsSts7F3kf9Vi1Fr+BTctQ8zrbrMFobut+zc/EgGBnw0jxjLv3r37+PGjhYVFnvqiRYsyDPP69esfMrFCol8O6uLq291swZW33t36xY7r10sAwDE8qwUf6WqgpG6t5X9KDxxcYN9Hv9F4vCIA6J3ZATCVKinDwujsPLqH0eUBqobAk2zZpHC3cOr5Kb0UBBCfEb8sfBlXdnFhTp5Uch6N8fFEw4YmFeo72xFJ+9EDwEeYTbbcsuhe66yOXQwH1DVuDIkEnL701avCzeo/i14vylSuTLu76xo1MpSCajUWLpTWrGni4mJaq5ZJly7y9+95SUY3bEhz2VpoWqQ3EO3YUennl/H0adbatalDh2bt2sXVZ2YSvXrJ9VIQwK1b1IgRvOgbMEBrVAoCEImwcqu4vHPm6CEfPZtLy5RhAq+oli5Vz5ihlstzFCFEcd53wt1OEIQCAnkxIgitra0tLCzWrl2bp37t2rUikehfvk3ox1niAYir8+r6QoIlAJyPPh/7MdZo+/PnRadPi65fp8LCKFhFoXsbLZQAysgcFs8NkWzaJBs61KRGjcFbePl6zgWZzvbaAQMAvEx/Of3q9K13tybbmipPnlTt2KFr2ZIoWqQKHlI+9ZjKlQt3C3qxrddi7Xm4Rz//ypWZ/ftVnFosKYl484ZI0lpyRqrLMGlpYt9586T7Gm5mypXTD6jt21fHyWmW1TuWCRQQ/YqQqVTp07OTJskWL5ZERvL/R+fOiTw9FXfu8EpUbfv2ho1ZuZwLjMc6OGj79UsZP16/HBw1SvbkCQlALke9ejQXZIaLJCORYMCAz4WAadWGufmQmb+cP6xalRk6VPPbb5rNm7P4YDXSD7B6BkBMiqsUq/K1T0BA4KfHiCAUi8Vz5szZvn17jRo15s+fv23btsWLF/v4+MydO3fixIlWVlY/fpYF5O1b4mQE/+aLN7XplIqlY0oDoFl6z8qenwbyP35c9Msv8h495L6+CgDo2BMmbwEUkxc7/axW0ZycM6h86lqltwCQKcGZsa1ZufzVh1e+h3zX3V43IXBCuc3levj1TGnTVHXwYMbLl5mPHysLuxv34O2DsDdhACSU5GjHo/Ud6wPQ0JolYUv0bby86I0bVYZWGq9Q4ikq/IV23OHFYBPV3r2sQgGANTOjmzfXtW3LnaKuXSvcxP6zfEYQnjkj2rWLXx1KpXyItNhYsls3Obdjq2vb1tCahqlVCxIjCUw2bJAcPcpvUqxenXXunHL27By/i/bttYXzf2/fXseFBpSVucGCAVDRqqJMlM/SUkDgP4xxP8LRo0cfOHBAp9PNnj178ODB06ZNS0xM3LBhw8KFCws47tGjRydNmtSlS5eIiAijDRiGWbx4cZ06dZo1a3bp0qVCTj83mzYxGpu7/EFcHQAZ4ZO4o53kXWb39jzt/c4QqLMGtdfRDAOnMBS/CUAukh9p9Wf5Y5e5NrSXFxc0qyPvhoDjDukJGQltj7Tl/AsB6Bjd6een191eBwAkyTg6Gmai/yq23dvGFdqVbWejsJlej7ctPPD4wMv0HPvAzp114eGZZ88q9S7/2zDoAapy5ZAQEVOxourIEW2XLll797JyuT6/K3n/fuEm9h+FZXP2CHMLwqQkYtQoXqh07KiLjf148KCqSBE+AFBYmAgAa2Ojjxp6Fr6W1883a6b48CFXfPbgYGrGDN5BcNAgbffuWgDjxmm4QKBiMUaPLlBEUKNMnKgJDc30nsCbQNdyqFXooQQEfmLy/b3u1q3bvXv3lErlq1evVCrV06dPhw0bRhB5cyzkx6FDh6RS6dWrV+PzCWiydu3affv2/fHHHwMGDOjYsePL72HZb6baD7ESgG26qSUsACQ9G1Q03QxAsgmCDi2CSmXYPuDtn2gxFr6j4T0PHpu4yu6i6rUfpOpzxyv9/FRHj7KWlnpB6B99tsmBJpxYkovkNe35hDh7H+7VMd+UPS4+I/7Q40NceXC1wQA8HT0blmgIQMtoN9zO5SBRrhxTvz7dti1/xT+oMWx2Mrn4eOL5c5Ju0CBr2zZdo0YAmLJlIZcDIOPihHBrBYeMiyM+fgTAWlkZ5rpSqdC3r5yLveDoyK5enSWTwddX17OnlmvA+ZvCQDu6FL99UEuvX6eGDZOlpREdOsgrVChbr55Jnz5yTlVRsya9eHGW/hILFqj9/ZXXrmW6un5dUIg8SIo/uRjnB4AAIcQLFRAwyhcWLhRFFSlSRCrNN6RFfhw5cmT+/Pnm5vmm7tywYcO8efM8PDy6devWunXrbdu2fe0lPqWIGR+/yqdIqa69uW0W6v2jIVzlMROZZPNmfeOoKDK9KG+8J/JZJHLjQ7GMWHstx8erc2cQhK5JE2VwcOUOw0uSVgA+aj5yO3ZiUrynzZ7zXc/bmdgBSMhIOP/yC+ElP0OmNrPLiS5KnRJAVeuqereNsTX5HOVXY69+2qtJEz7ijJrOZQBsGIkNAEQiumJFrigsCguOUb2oTof+/eVcCkmSxMaNKi4SLAAfH/7j0AtCTjuqg+gm+BcmPz+Ru7vJpUsihsHDh2RKCgHA1pbdu1eVR2/q6UmXL/9NUhDAqhuruPhKzUs3r2pd9RtHExD4KclXEO7bt8/d3d3ExKRyttHH77//Pv+TOBqFQ6VSRUVF1arFK2pq1ap1/3v8Or90500PPDy79enDv5sjri7397KjXLJqFfGBd4oPCaFgx+tRdVDrkAWgdhyqx7P6TEbabOtQxslJvXhxa/ecFAFWcqs9bfY0L9VcRIp6VeGzeO+8nztHa4GhWbr/mf73394HICbFi3wW6U/VcagjpaQAIlMi36ne5eno5MSUK2fkt9IwEht/C658PBHqwYPCTfIng0hLk02YIBs2jIyMzK+NPu0fpxdNTCS2bBG3bq3gsnEBmD9f7e2dE4PU05PmTErv36dSUwkArLW1eurUB5ZemchxOuSEnx6xGLt3qxwcvn8g7NcfXh95eoQrT6w98buPLyDwc2DEjxDApk2bhg0b1qFDh/r165/MtvuoUKHCqFGjpk6dShmLpvFVJCcnA9B7aBQtWjRJHyfzEx4/fhwcHDx16lR946NHj5KfbMK9e/euddmugUnh5hLzRg4tikgSmza1u3jRRPauNqdviiueQKcrtQsXpo4fD+BCYBG4Ps0zyFCD+HGacuUSixVDcrK+po1Dm133d6l0qu5lu491G2shteBupLVD65XESoZlLsVcuvvyroOJQ0pWysq7K20UNiOrjqSILz+uTQ83nYs+x5Xn1p5bQVoh2eC6Va2q3kq+xYL1f+TfwrlFnr716hV79qwIV1YoGKWSBHD1KpGUlGyoyS5SqhQXDUFz44bh4F/k3bt3nz7t/3fE0dH2Q4aIY2IAiA8e/NihQ8rkyXTRonma2d65wylD0p2cQgLS+/d3SE/PeRRDh6Z16ZKS51m6uopu35YxDE6fzmzRIgMA+vU7LRmNWbmaSSTs5MkvSpc2uXtXWreuysUlq4CfiVKnlFJSo1+qwDeBUlJa376+vmZ22GwtowVQx7ZOSarkV33u/7/8lN/YfxyNRpOZman7xOTw3wbLsu3bt/+QveBRqVQFiQNjRBAyDPP7779PmTJl0aJFV69e1QvCOnXqpKSkxMXFlShR4hvnWqRIEQBKpdLExARARkbGp26LesqVK9ewYcMm2bHEpFKpnZ2d0Wnb2dmFlMlJUnrkCBMbm2lpaeG4wpk1f81IlBdsHHx37xZPmMBaW4dHP4W71nAESxW6PgJIkrNbZ7t1yxM6wMbGJrJEpIbWWMlzmc7awMbH2SfwVSDN0mcTz06tO3XOhTmHnh8CUKJYiSHVhnz+aSRkJGx8xCdOmlBrwoi6I/I0aFiq4a3kWwAefnzYx6ZPnrNt2oiyvdHQq5fu6FFxairx9i2VlmZnqFijsmNDm0RFfVVIBIZh/s0hFAoBdeeO/Jdf9MHSQNNmR4+aPH2qvHCBNc1JHkk+fSq/y+sMyGp1J4/LkYIEgWHDNIsWUQSR98k0bUpyqXDv3LHs00fBVT59ypvVjB6tCQqiPnwg1q/PKlOGtbMz7dQJgBjIdxPBkD0P94y+OLps0bIXu1+0kOb6l9n7cO+IyyMA7Guzr23ZtgDC48OPvTjGnZ3WYNpP9iF+hp/vG/tvQKPRZGRkWObOF/bv5Pjx4+rsePeBgYEXs714P4OR96akpKTk5OQePXrkqee+W9/lpdLCwsLCwiIqO/v28+fPS5YsmV9jkUhkY2NTMht7YxGKjUKSKFGCMTNjbbW1uZo9TmWJzEzJihUvXpDvxLwyttUzwi0RJIuZVyHXEarduxlnZ7paNW1/I5YFZhKzPFKQo1/Vflxh5/2d71Tvjj3lf4AWhS1KV6d/2t6Q2SGzM7WZAKpaV51Rf8anDTgnCgDX3hhxfvD0pPXe1i1a0Prsvnm2CZkqVThbVvLZM8OsCP9BpLNmcVKQVSjo7GxH5MOHsoEDuXcgQqWS9+plUrs2H3+AJGeeqB0VRQIwM2NXrsx68CBz8WK1UdMxb2/+lVm/TQjg5k2+3LatLihIefdupj6vVsF58/HN5MuTGZaJTI2cFTQrz9mg2CCusChsEcuyOkY37tI4FiyANi5tfJx9vvZyAgL/p9jb2+vlhY2NjUhkXPFpiBFBKJfLAXz8+DFP/YsXLwB8yxtBeHj41q28t3iPHj3WrVsHIDk5+dChQ5/K3e9I7Wyr8RBHEQDJjh0hpz7A7g5X6fmajdiM9EUYex1MlSq6du0yHz5UBgWxX+Mx2cqlVXGz4gASMxN7nerF2bwASFGlLA9fbrTL8/fPN0RsmH9t/sHHB7maxT6Ljaq8ajvUFpEiAA/fPvxUrMrlbNu2WgBOToynp06fzv7yZRGAsDCqSpqSxJ8AACAASURBVBWTdu0UKsqEd9/WaqnslBT/RWiavMmHR1D5+ytPn85av547FJ09K5s0icjMlPXuLTp1CtkhagO8Zm3awe/wLV6sHjRI6+ycrw1LzZq0QsECePGCLFnS1MXF9ORJEZdOWSKBq+tXyz8904Omcy9MAHY/2H09/rrh2acpvJ7/0btHfs/91kesf/j2IQCFSLGk4RIICAjkjxFBaGFh4ebmtnr1aoZh9P4SNE3PmzevVKlSpbNjYXweX19fS0vLlJSUPn36WFpa3rlzB8Dt27f3ZmcLmj179uvXrx0dHcuXL9+rVy8fH5/vc0PG6FKvBleId3zlj5bDslbNW2Sit5SplgiShakGAHRNChkXTUyK9SrQPOu2TXc2DT03dPDZwTcSbugrH7x94LXPa8qVKUuvL+Ve29uXa9/AqYHRwU3EJm42bgAYluHc7fOwYUOWv78yOFgpk6FRI35Fcv68KCWFmDZN+vo1efky5ecn1tvL/JcNR8nnzwmlEgBrb09Xrw5A27u3PgSreOtWk7JluUTHAHTt2in9/ddbTOdkoq+vrndvrfFxs5FIUK8eL+1SU4nkZGLgQDnXvWpVOr9IaV/k8qvLxyOP6w9ZsGMDxurlIsMyz1JzMtOPvzT+92A+XfCUulMczRwhICCQP8a3lJctW3bixIl69ert2bNHqVQuXLiwVq1ax44dW7p0aQFdCc+ePZtqgLu7O4Dhw4cHBfEKHGtr69DQ0Nu3b8fGxi5Z8ve+sTZzrUrQUgCs5YtWit2bMDRZbQpbXhi4WlTQtyy0IATQ37W/QqTQH8pFci5GmppW73+8/9CTQ338+nCG7AkZCV1OdsnQZhg2nu/1OYtcvXY0NC7007MSCTw9aUtLFkDZskzNmjQAjQaTJ0tv3+aXmFevUnRV3nr+vywIqXt8Wi7azU1fqf79d107Pi4PkcF/LpopU1R799KenvoIalOmFMi3vXdvreF/iTZbdHKfSyFgWGbylclcuVmpZqZiUwCP3z122eQy7PywuI9xMekxKl2Oj2yyMpn7prnZuI2okXfLWUBAIA/GBWHTpk0vXLjAsuyOHTvev38/ffp0pVJ5/PjxzgbBpr8Ltra2pgbmCX8TUkpqx7oDAMHC8ToAWL6A9CMAuyyRZffBXDPW1JSuXbvQV7GQWuj9KAC0L9d+VZNVhqrO+Iz4+2/vq3SqLie7vPn4BoC5xHxszbFT60493+28s7mzkUGz0QvC4NjgL86kVy/+p/fw4Zzw0EFBlOBBAYDMFoRMNYOERCSp2rUra8UKNttoSztggHraNAAMAy4tCQAXlwJ59XXooHvwIPP69cwdO3IFcKhVq5BOgaefn+Y0n+YS8/XN1s/0nMnVZ2oz/3z05+Czg/V6UUPqFa93qvMpMZk3UYaAgEAe8t1FbNiwYXh4eGpq6rt378zNzY0aav4f4VXa49Dr6wBknusHvY21tlvHaY7cKEdd+/bsrFlEZqaubVujoSALzvDqw7fd28a9jPer2q+GXY3AHoF3k+4eizzG2TIEvAy4FneNyxUsJsV72+5t6NywICPXLV5XRIp0jC4iKSI4Njg/JSpHp066KVNYlSrX2j0mhnxp6c65hZP/4T3CnBWha+5E7RSlHTxY16GDZONG1sJCM3w4Vx0fz6d6tLZmzcwK6urHbSJWqsRcuKA9eJAXRYVeEXJZwAD86v6rrYntMPdhMkq26c6mJylPAFx/c10f3qhT+U5XXl9JUaV0rtB5Q7MNQmRRAYGC8AVvG0tLy3Llyv2/S0EAPWo15QpZzufuztoU4cb7ULs6erDW1sqgoKxt27JWrfrGq5S2KD3AdQCARiUa1S1eF4C7rXt/1/59qvI+D4GvAg88PsCVZzeYXUApCMBCatGtYjeuPCNoxudTDZubs+3aGXH3CXpix8rlAIi0NH1ggf8WLGt8Rag/X6yYeuZMzahR+mDZ0dH8/0jp0oVZzy1ZorazY7nuJUoUZoRrb65xycVkItmv7r9ylf1d+4f3Da9uWx0AzdL7HvIZoRs4NbjZ7+blHpe3+24XpKCAQAHJWRE+e/bs6lUjQbzyMHjw4L9zPn8XDZ0bjvYYvfbWWgAh6feRnaSosrsvAKZsWaZs2e9yoZWNV06qPYkLumZ4dZIgOVMXmqUByEVyvcdFAZlRf8axyGMqnepO0p2jkUd/qfDLZxr36pWzEKlenY6IoAAEBYvMLIYfVnmNx0qP16/ZKt8nI8/t25RIBDe3wttD/jDImBjeccLKinEskAnJNwrCokXZc+eU/v6iNm0K6Ym85ia/HOxeqbuNIpd7nE8Jn4ikCAD6kEMVrSoWkxcrJv+yB7GAgICeHEEYGho6ZMgXXL/xfysIAcz3mm9rYjvj6gzOShMARVA1nep89wvZm+b1dLRWWFe1rnov+R4nBQH4lvE1k5h91bAOpg4ja4zkkvTOCZnTxqXNZ175GzSgy5dnIiNJZ2dm8WJ1s2YKAH5+okOZyxgQD1D1UexN5psF4a1b1Ny50itXKILA0aOqpk3/7VEnyDu8zwxtbDlolG8UhFzHkSMLmUEiMjWSCzlEEuTIGiPznPVy8lp5Y6VhTQWrChAQEPhKcgRhz5492+fOI/rzMarGKJeiLqeiTolJMUVSLUq3cDJz+jGXblKyCbc1yNGlQpfPNM6PcbXG7Xqw663y7esPr9feWvtbnd/ya0kQ+Osv5cWLokaNaAcHxtyc/fCByMjgdw1fotSHyNMK30JMIYcNGyRTp0o5HS3LYsMG8b9fEFLZ5rJG9aJG0QvCMmW+fyzQL7Lm5hruva1lmZZli+ZVWtQpXkdCSTQ0L2XtTOyKyvJGiRMQEPgiOYJQIpFIvs1U5P8C39K+vqW/TQIUikYlGq24sYIrW8mtmpQsjJ+Gqdh0Wt1p4y6NA7DyxsoelXt8xkXMwYHt25c3H61Xjz53Lpdh1ON7tEchZmDAunUSw53KK1dEcXGEo+M/IC0KDpkdMi2vpUz+fPuK8GuJeh91M+Gmp6MnRVCHn/JJUfRJSAxRiBQedh56v1VhOSggUDiE0LQ/iNoOtTn3LwAdy3eUUIV85+jn2s/VxhWAUqecFZw3zlZ+eHnl3cB78vybLCmiosg3bwgA5uZsrVo0AJrG/v3/bkt9lSpnRWjgRPgZWBbR0fwy+gcIwu33ttfeXbvGzhpDzw313Os5NmAst9qr71i/lr3xnLpezl76siAIBQQKR76CcNeuXc2bN3dxcbHMzY+c3M+EhJI0LtmYK3ev1P3zjT8DRVBLfJYQIAAce3qs9ZHWy8OXv8/6Qq7dzp21zs6MQsE29kjlah6/yTfKeUG4epU3qmzQgB46lFfN7dsn/qw16z8JoVIpunYl3r0DwBYtypQqVZBeiYmEUkkAsLRk9UkHDdExus13N6+5tYZLUfktPHj7YNylcZxHBIA0dZo+veW4muPy6+XlJAhCAYFvxbggXLRoUf/+/UUikUwmq1ChQqtWreRyOU3T/Y3FoRYoIIt9Fg9zH/ZHsz887L5JK1nfsX6nCp0AsGCDYoPmhs4dfn7457vY2bH37mW+epUx7Fc+B/qj9G/aHL16lVe0envTrVvrihZlAcTEkHkTAv9LUKvlnTpRV65wR5pp01CwAElf1IvuvL9zUuCkmUEzq2yt0vJwy/vJhQ/ZcyrqFFeQi+SGW32Vi1VuWrJpfr1q2teUi+RcuaJVxUJfXUDgv4xxQbhmzZrffvvtzJkzNWvWbNSo0d69e6Oiory9vVNTU3/w/H4mipsVX9JwSZ8qefMoFYKF3gtr2dfi1oUAAl8Fqmk1gDcf36SoUox2oShIpahUj0/381BbnsjM/MwlGAYqg7goWVn6GNRgmJzUFt7eOpkMv/zCb0aOHi27cOHLsd5/MJL166kQPj+Xes4cza+/FrDjFwXh/sf7uQILNiQupPWR1oYmUV/FmRdnuMIW3y1Xe14tbcEH9R1fa/xn4hpKKalvGV8AxeTF3GwLpO8VEBDIgxFBmJaWlpSU1L17dwAkSapUKgAKhWLFihV79ux5+/btj56jwCfYmdgFdA949uuzUkVKAVDpVBGJERdjLlbZVqXy1sqP3z3Or2NxR9aczADwDsWS7yTk1ywtjfD0NHF2Njt5UgTAz09UooRZzZomly9TAB484NOv29qyFSowAPr21XIO6NHRZOfO8hEjjGxAEkqleOtWvUD6YRDp6ZLVq7myesYMfXxtpZIYN042cqQsPT1fMfN5k9HotOjbibcBiEgRlx4kTZ3W/lh7vXqz4Lz68IpLFiETyZqUbFKySMlL3S+NqjFqvtf8TuU7fb7vxuYb97fdH9QryDDUrYCAQMHJd49QLBYDsLGxSUxM5GqKFy/OMMzr169/0NQEvoStia3eViIkLmRTxCaapZU65Y77O/LrQhCoZMZ/gk+v5820pWf2bOnDh6RajdmzpTRNzJolVanw7BnZrp1i0CDZ4cP8ms/LS0cmxCvatas1s+36xW+LFOGlxd694tjY3F8tnU7evbtswgRFmzbk8+ffcNNfjWTNGiItDQBTpoxm/Hh9/bZt4u3bxXv2iPv2ldGfBANISSEePiSfPfvcivDwE96ks0XpFld6XOH0mSmqlK4nu3J54QvOmef8ctDH2cdEbALASm61wHvBaI/RJPEFiza5SN7apbWQYkJAoNAYT8NkbW3NZc11c3M7d+4cJ/y2b99OEIRjweJxCPwYPB09ucLZF2evxvKBgU5FneLinRqlsi2/pn9833ib27epXbt4+8/oaHLuXOsXL3K+J4cPi9et401eveur5b16UZcviwIDB9wdd+dOZrVqvEgJC8u1WSidMuXp5eS2ODWFXkBG3Pna2ywchEpFhYSIN2zgDtUzZsAgRSe32AUQGCiaNUtq2PHlS9LDw6RePRM/P76NUUF4NPIoV+hcvrOrjevJTie5IAkx6TFcULSCo9eLtirT6qs6CggIfDvGXzbbtWt35swZAJ06dSpWrFiZMmXs7e1Hjx7dq1cvW1vbHztDgc+hz0pxK/GW3rE6MTPRMG3h8/fPU7NyNncrleK3Bo16UNA0xo2TMgY/+wcOFOEKJUvmFQbNQ+dSt25xZfGBAzZv7rbX8rIhPDxHEIp37FBuOdwGfn5oswSTbwT/CL97ybJlpk5OipYtueyDtKurrmNH/dn4eEKfoArAunWSI0d42c8wGD5clpKSS1+qF4Qsyw44M6DoqqKtjrTiUgCaik25XTp3W3d93Lsrr698OqUXaS8+aIyEeE3NSuU+L5IguaEEBAR+JMYF4datW7lU8mKxODQ0dNmyZV26dNm1a9fOnTt/7PQEvoCjmaPR/E0nnp3gCtvvba++s3q17dUSMvgdwYpV+J/4R/FGnGH27xffvUsBkMv1cacBgKJw+rTKz09ZpQovEsraprscWZbTgmEULVs2eLSFO7p+lZd2xLt30qlTB2PrS/AeC6+jvk5tWAjEO3dK582DJiewmWbuXENL0dOnRZztD5n9H/Dbb1Jus3DzZkloaK7lbJUqjJUVr/Xdfn/70cijNEvr82G1KdtGb7fp7ezNFS6/upxnStvubXPf4V5jZ43XH/JuLpyIPKFjdABq2tfME01UQEDgB/Blh/pixYqNHTt2zZo1ffv2pah/pXH8fxu9dtQQv+d+DMuwLMvFGU9Tp+lFY8Wa/K/2k/Tin7r96ZWB48apW7bMWbq1bKlzdma8veng4Mx167K6dNHuEfG+NHTDhpzMJD5+rI1wEXQAHkXJPnwgAEg2b16uGnkUOZksk978veG5qbAw2aRJXJkpVUrbrZtq715do0aGbU6f5td/c+aouZVuSgqxfLnk8WNy9mxe8TtliiYiInPvXpWfn5KrifsYNysobxCDLhVzouV5O3tzW3q3E29/1OTagt3/aD+ApMyk/mf6axktwzLvst4BSMhImBs6l2vTtmzbb799AQGBr8W4ILx8+bK/v3+eyqCgoE8rBf5x9NpRAOUty9ua2AJIyEi4Hn89LD7sZfpL7lTgq0CuUMzNzhpvAXygTQw3/wCwLG7c4N91OnfW6T3lAejLFIW+fbU7Jt6t8+YEANbMTHXggLYXn5HYBJluuAeAYYmbN6nIO+oWK1r9hqWGV0l+9zf6VxAfPsh79+bWgrSbW+b161lbtuizz3O8f0+EhFAASBJdumjnzFFz9Zs2SXx9FVweR1dXZtIktYsL066dTr8cHHNxTIY2A0B5y/JDqg2xM7HrUK6DYS4tS5mlq7UrAB2jM0yhrGW0D9895Mo3E272OtXLfYd7veP12h1tN9B/IBcPoYR5if6ugp+ugMA/gHFBOGjQIM5YxpC3b9/27NlToylkHH2BvwlDQdiuXDv9qmLfw33cKoQjJDaE8zVk7e09yAiucvliimHwv/buMyCKa20A8DvbYOl1AUG6hSZFUFBRVCxERGNP7LHFSmJizI1fEo25mnj1xpaIkkSvokaxa9RgBRWxgl1QigrSQWBh2Trfj7MOy4KI6LIC7/MnZ87Ozp4dJ7x7+jff6ISG6sXHs1NTWWRehKUl7eKiCA6W9+ghB4AePeTBwbWqcZwTJ0hCHhpK6+mJlyyhTU0BQOHp2RMukZf++IMbMsD4nEy5hzCfrwwneZWGDU9hfBucI0eoggIAoAUC0e7dwOfXPefECY5MBgDg7y+3saGHD5d17y4HALEYSkspADAwoKOiRNzaC8adyDhxKusUALAo1saBG1f3W502K+1/4f9TG9XZ10EZF1W7Ce8X3a+WVateivxAOff03MXsi+SaUYOjmEX4EELNqZ5AWF5enpGRERysvgd6r169Xrx4kZmZ2SwFQ43lbOLczqAdSUe4RozoqBwSsvPeTmbJZgCoklVdeX4FAIDFWmS1jWT+tU93/Hj+xo28q1fZX3yhm5SkrA4GBspJh9qhQ1W7dmUfOlSl9qGcl20Dsg8+AADa2rry8mXRwYNVp0715FwhLx07xqmUcAGAC9IFfZM3b1ZGglywoTIyGvv1pFLd+fP5w4axG7FZJqhEaElkJF3fCGeahu3blSGO7BFIUbBihZjpQLSyoo8fFzFdoYzfU34niene07u36/6qAoTYh5CEaiBMyVcu9s2sgaBmjt8c1R80CKHmVE8grKysBAAWS/0lklNR8crJZ0hblgYvtTGwmeEzo4ugS0+7nuGu4QBAA61aCwGAc0/ORSVHDfhrQOnAzA/hIAAoFPD338qGyrQ0VnS0snuM1JAAQFcX/P1FurWHl1KFhexr1wAAOBzZwIEkk27XTta/P62vH+jxQvVkAxBeMQ/7cW97FxdlaMkDa1ajf05x9+7l/u9/nHPn9IYO5U+ZQr2c1Vo/sZh9VtkCLBs8uN5Tfv+dm5jIBgAOB4YPV3aCBgTIyU4dnTopTp2qYiaBMJ5VPDvz5AwAsCjWfP/5DRQh0DaQ7BP5sPghs8pMcr5yxsgC/wUh9iHeAu/V/VYf+eDIqM6j2BQ7sF3gdz0bu346Quidq6e3RiAQGBkZnTx50qf2nm0nT55ksVhOjVutGDWncW7jxrmNYw43DNhwPfd6XqUyZgTYBJBpbVtvby2tLqWBXtDZ8jy1+G96iARqbYJx547y109QUEPjWTj//AMKBQDIAwNJi6gq62Bnx1tZWeBIDtfCZ+6RfSQ6OlZWL5tGwZqVcbCRX427Y0fN5x44wM/IqEpIeGXBLlwgja4KV1dFB/Xd+wAgK4vFTBmMjJQ4ONRU+9atq54zR+LkpNDRqfs+2H5nO5ma2de+r4ORQwMF5nP4QbZBZNRon519BjsP3jRoExMIQx1Dl/deTtJ5eXl/fvDnxoEbcUUYhLSrnhohm82ePHnysmXLfv31V1I7FIvFMTExkZGRw4cPNzc3b/ZCojdjzjePGhxFWuFYFGvDgA1kAbCS6hKyy+tzcZHliM7zYQM5X22CIJ8P3t4NBsLjxwFAQcHFMM/0F+l07bGn8u7dmW7CD+HgJ6YHpNOnA4CFBc1hKQCgGMzl6Y1an4iVns6+fBkAgMUikx/Yt25Rr26T4Jw8SRJq1cGKCmr8eL6zs4G3t35lJQUA7u6Kr78Wq55DUdC5c/1RUKaQ7birjMeNGc/C7C6ioBXH049/8vcnZNE7CigfK/UNgTEKIqR19Q+W+emnn4KDg+fNm2dgYGBubs7n8ydOnNihQ4ctW7Y0c/lQ0/Rz6Lc0eKmVvtXXgV+7W7h3te6q+ioNdNr8ics4yxfA+nmwMalHpJVFzUwJPz95Qzs0i0Sk+XHxAAiRRvn+6Wv3q91Hhz9itoKSd+v2JazuAI96wcVomCH59FPawAAAWCywMJYAAA1UYVpZvddmJybyoqKYUMeNiSFLfcs++EDh4QEAQNOsB69cyZP9soNQFlZrWvr8+bpHj3KKiigSsjkc2LSput6YV6+4zLjnwucAYKVv1ZgJ7+Pcxp0Yc+IDlw/Ib5EzT86QYUrOJs7GOsaN/VSEUHOpfyC7np7eP//8c/LkydOnTxcWFpqZmfXp0yciIgLnEbYgnwd8zuxj18+hn3KkzEsZxgqfSSPX/RkJALALxrE7rYN55KXAQDkAcI4dY6WmSmfOVLss5/hxslbLbh8OgAwAKiQVf6f/HZUc9a+gfwEAbWPTxaE07UlHAKANDStnz2bea2VF55UCAORnVNWdzM/KztYLDweZjJWSUh0VBXI5d5dy1Kt0wgTO/v2su3cBgHX/vrxbPbvUsu7eZT17BgC0iYk8KIjJ37KFd+BAzXNuZUV/9ZXY1/cN5jLuT91PEhM8JnBZjdp8uKddz552Paf8PeVA6gEm09fat/EfihBqNq+c0UVRVFhYWFgYLvjUGozsNHLdtXUimcjW0Da7IhsAssqyxD/8QGVlcc6eBYCP5TtUAyE7IYH/8ccAwMrKgiVLVC/F3bsXAPIMIEev1kpph9IOkUAIAPLu3VlPngCAdMYM2qRmB2CBHQceAgAUFLLdxGKoXSmjHj8GmQwAOHFxQNOcM2eo3FwAoK2sZAMHMhXBV9UIOceOkYQsNBQ4nCtX2Js383JzqWvXlL/epk+XrlpVzXnzSYzppekkMch50Bu98fOAzw+mHiTN0QDga4WBEKH30WtWlqFp+ujRo0uXLl2zZk1WVlazFAm9ex3NOt6aduvmJzc/9f2U5GS+yKSNjESHDokOHQKK6gZXO1OpAKCjA927yXS+/Zacxjl4kJJIqMpKXlQUJy6OKinhnDkDANdtldMAfAQ+pJfrQfGDR6XKuafS+fMVTk7y7t0ln32mWgxrG2UiTyFg1dnGhBIKlYmiItajR5y9yrkf0nHjgMNRuLuTQ3a9gVAuZ4bVyMLDc3KokSP5+/ZxLl1ik4mvvr7ylSubEgUBgPx0AID2hm+2m7G3wLu/Y3/m0Eeg3kGIEHof1AqEK1asGDRokEJlxeWxY8dGREQsW7bsyy+/9PDwuNjsm8mhd8VK38rFxMXR2JEcZpVlkYSsXz+FrS0A7KHHTB9VGBMjsjizj52sHOVIlZfrXbqk88UXOl99xR89WnfaNLJoyzV/5czFnnY9Bzgp908/nHaYJOTe3pW3blWdOqVaHQQAZuBoLtjUnUFBlwsnwg4PuHcaQtkXL5KICwDS0aMBgAmErPv17LbIOXVK2S5qaSkLD1+wQLnAG2FjQ2/f/gadgqpEMlFhVSEAcFlcGwOb156v5otuXyiLTbHqjpRBCL0PagXC3bt3d+zYkZlBeODAgdjY2PDw8Bs3bhw9etTc3DwyMlIbhUTvTN1ACAAKNzcA6AK310ecHNS3Smf5ctW3mGzbxo2NBQDSXEkyr7spB334WvsO66hcwOzIoyMNf3rtGRTqc+pv3NePgQn3wf3fsIQXFUUVFwMAbWOj8PICAIW9Pa2vDwBUQQHr4UO9iAi9AQOYaiX3jz9IQjpx4o49+qdOcQCAxYLo6OrLlytv3RKqzpR4I9kV2aRt09bQ9rVbA9bV067nUNehADCi0wiySRNC6H1T01SkUCgePny4RKVDKDY2ls/n79ixw8TExM/PTygUfvTRR2VlZcbGOPKtpXI0cSSJJ+VPaJqmKAoAFJ07w6lTAMB68IBbUqKsq+nqQnU1AOhdvqx+FQ7nJrcIZAAAvla+1vrWOmwdsVx8q+DW0/Kn9e6GQQgENXPqqawzaq+WFivD5BNwYD18SNKy0FDlrhEUpXBzI7s+6c6dS2b0c7dsEf/4I+vpU86pUwAALFb+h9P/NURZ9Zs9WzJ27NvudPGs/BlJNPC9GhYzNCZHmIMb5yL03qr5hVtWViaTydq1a8fkxMfH9+rVy+Rl61b37t0B4NmzZ81cRPQOGfGMzHTNAKBaVp1bqdyYidQIAYCdmsoMOREvWaKwr/Wnn5k7/ySsZ56oAAAMeYYuJi6GPEOywCYNdMOVwlo1woICtVeF5cpXc8BW8fLJlA0YwJxQ0014TbntLevePQDgbt1KJvjLQkPjUp1Io6iLi+K7797BurhMIGxyJKMoCqMgQu+zmkBobGzM4/GeP39ODh8/fpybmxsYGMicIJVKAYCuu3MPalHqto4ygZB1+zb7Zf0vobdD1FhX8csmg5vBHb79dUzgHF7AbPb2D11Ipo+VD2ktHNZB2ToanRItkole9dGqgZCqEwgrXgZCCfAKwRIAgMOR963Z24EJhAz2/fsAwDmgnKIgnTaNWS517Fgps8z323hW8bJGaNzEGiFC6D1XEwhZLJaHh8eGDRuqqqoAICoqCgA++OAD5oTU1FQAsLW1bfZConfJyUS5SF5NIOzUiTQ/sh4/JkuU3fG1HXx+ylz9s58NBgBYFwhd+z/6d9rmKwLJdSv590+V+zMzwyDDXcNNdEwAILMs84eLP7zqo62tawbLUIWFaq9WVNQMb8kGOwCQd+9Oq7TDy18GbAaVm8tKT2eR8cy6urLQULKOKACQfTPe3tMyZTfkfUL4oQAAIABJREFUmw4ZRQi1FLU6/7/99tvLly/b2tp26NBhzZo1/fr1I82hxL59+zp37mxmVs+25qgFqVsjpA0MFLU3atjex4QsrbnVl0ozhx/61VpIoe7EOGMd45UhK0k6KjmKLG1al74+ra+nAAAR8Cvy1SuOlVU1TyMJhKrtolBfjRAAuDt3ktVn5J6eZVW8hw9ZAMDlQkBAE0fHqGFqhNi8iVBrVSsQfvjhh0eOHAkKChIIBAsXLty/fz/1cnOaysrKx48fT5kyRQtlRO8UEwgzX9RMYFCoVLZogFhz5YLdYjbdf4FpCU8OAO0N2y8OXKx6KT9rPyY93mN8f4f+ACCn5fNPzX9VE7qVtTKR94JPps8zKqpqwm29gZC2sqLrLHXL/esv5Vfw80tKYpO5P126yN9JuyioDpbBplGEWin1Ccbh4eHh4eF1z9PX17906VKzFAlpVt0aYUpByg0f8ZQEMKkGALhiB0/kxcz52bRyEdHFQYsneU4qF5dvSt4EAMY6xk7GtbYi2TBwQ8C2gEpp5f2i+49KH3U061j3062saDJvIk8hsC0spG1qZuYJq2tWL8sGO7m/v8LTk6YhOpr77Blr1iypnZ1C4eXFPn8eAOSBgeykJACgspWz3eW+vleu1Oyn2KR7o05Oy8kqoxTggBeEWq03nheFWjqmj/BJ2RMASH+RPvCvgZ/rxc9Q7mwPf/UyqfsuO0M7stPTj31+7O/QnwJqtt9spsGAOad3+94kfTP/Zr2fXmu8TO1uwgpxzVLfWYOmVR0/DhR16BDnyy91163jde2q/+9/65R+vkTh6SmdMEGyaJHaleW+vpcvv+NAmCvMlSlkAGClb6XDbtKEfITQe69JS06hlszW0JbL4koV0vzKfJFMtCR+Cdm/91J7AAAFBbGuylkHozqP2vdwH0l/FvAZj80DAC6Le3DkwUpppT5Xv+7F/az9TmScAICbeTdVt0hkqE4lZBUWqvbjVUpqAmFOlRnoVikUsHKlMvyIRPDzz7wboSEHEhMBgHo5vJmg9fVFjp1u3FAGwob3U2y8p+XKkTJYHUSoFcMaYZvDptjtjdoDAA303H/mHk8/TvJzDaFcBy7aw3NOFQAI9AQbB24kAcDW0HaS5yTVi9QbBUGl15DZilZNAzMoKqS6TDonhwKA/fu5ZPAL4+xZTlkZBQB0u3aqewIrvL1v3eVVVwMAuLgoBIJ300HIrDKKHYQItWIYCNuiUMdQktiXuk81P9UCDrspWzuHdRymx9E7POrwV75fHRl1RJejq36V+jDjSG8X3CaNigyapq/nXedZKENLPlipB0J5zRa1ubksmQx++klZR1y8WNKlixwAFAq4fl1Z7VMdRKraLvquqoOAcycQahswELZF3/f6nunMU3UvxPNqL2eSHug0EAA6mHaY7ja9g2mHRl7Zgm9BliITyUQPimu2iSisKhxxYES/Xf1WlPmBYS4AFIKlaiCkRKIK2oA5FIlg82beo0csADAxoefPlzDdflevKh9a1UCo8PM7cULZzt+z5zsLhMzcCVKHRgi1SpoKhDRN79y588svv9y0aZNEUv9KV8ePH//mm29+/vnnwjpzq5FGGfIM94/YP7zjcHLYzkC5rt69CYNvs5T/Fl6WXk27eN3W0UvZl3rF9Drz5AwAiBTlYHMDAApAUGuwTEVFBdRak3rdOmV1cN48iZER3b27sj+R2V9QdX79c4fuZE0ZDgcGD65VE30bzNwJDIQItWKaCoSLFi1atWqVk5NTbGzs2LFj656wdOnSL774wsHBITs7OzAwsKKiQkMlQfXSYetsG7Jt48CN60LXfdtTufvgqcxT5ZJyALDgWzDR8U0xraM3824CwI67OyL2ReQKc2vO4JdA3RqhUKgWCPPyKACgKJgwQQoAAQHKet7162wyR1Hh4UFyaGPjo3ddyAzCHj3k5ubvpoMwrSQttTiVpLFpFKFWTCOjRktLSzdt2pScnNyxY8fJkyfb2Njcu3fP4+WfLQCQSqU//fTTxYsX/f39ASAtLW379u1z587VRGHQq7AoFhkCcz3vOsm5VXCLJLoIujT5sn5Wyhrh9bzr3134bu21tepn8EsAoAAELJUaIV1eIQQD9TMBPDwU7drRAODoqBAI6IIC6sUL6tEjVseOCoWPD21lReXny8LCDh9WzkEcNuxtt5sAAKFUOPHIRFKFJXCwDEKtmEZqhNeuXRMIBB07dgQAAwODoKCg+Ph41ROKiorEYrGzs7I7ysXF5dy5c5ooCWqMul2AbxMIfa19KaAA4HbBbSYKdrHsMtlrMkmzDUoBoBL0Rfk1zQBVhVWK+p7G0NCadk5/f6abkA0ANJ9feeGCaO/e/B83XrzIBgAWC8LD36Bd9HTW6WOPj6kN6gGApReWqkZBf2t/I55R4y+LEGpZNFIjzMvLs7S0ZA6trKye1571ZW1tbWlpee7cuZEjR0ql0gsXLhgavnLP0mfPnm3ZsuXEiRPkUE9P7//+7/+Y3YMZ5eXlfD7/3X2JtsWSb1koqqmfuRq4lpWVkXQTbqyzsXN6WTpzOMB+wMa+G/ek7SGHuiZFlQAAUFTMYpeWAosFAGVPS+u9VGBgWVmZmKS9vBTHjxsDwKVL8qFDywAA+HwICoqNZUmlAAB+fhI9vRcvC/4aRzOPzjk7BwAcjRwX+CwY6TqS7KRxLf/a77d+J+cMtB842HFwmGNYWSMv+ibwidUQvLGaIJVKhUIhm81+/alaRdP08uXLydYRAPDs2TOhUPjad2kkEHI4HLm8ZuSeVCrlcrmqJ1AUFRUVNXPmzJiYmPT0dHNz8wbur4GBgaOjY5cuyjqKnp6evn49k9h0dXXx6W+yDqYdVAOhXzs/5mY24cb6WvmSQMhj8xZ3Wzzfbz6LYlkaKH8bcY2VMa9Abu5aXa0wNweA4vqeVX19undvFo+n/PQePZRTO65c0d292xQAJk2q5nAgLk75PAwdKmt8Ubfc3UISWeVZCxMWXiu8tqH/BolC8vWlr8mC4wMdB+4K3/VGX/yN4BOrIXhjNYHNZstkb/D/lxb5+/tXVpIf28Dj8dLT0xs+HzQUCNu1a/f8+XNmA/ScnJzQ0FC1c0aMGNGnT5/79++7urquWrVKJHrlJnampqahoaERERGvOoHg8Xg8Hq/hc9CrdLLolPg8kaT5HL6bwI1NKX+aNOHGzg+YfzXvqpmu2YaBG7wF3iSTCYRsgxKSKARL99JShY0NAIjKlINCddgysVz5WPbuLTcwqPnobt0oDgdkMnj8mP3VV/oAwGJxZsyQJCUxHYR0I4ua9DwppSBFNWf3g90DnQeef3o+rTQNAAx5hmsHrNXoE4VPrIbgjdWQlnJjP/roIyZ97NixkpKS175FI32EQUFBMpns4sWLAPDs2bMbN26EhYUBQF5e3rVrNRv0mJubBwcHKxSK7du3f/zxx5ooCWok1QWyPS09mSjYNL5Wvnen302YkMBEQQAw1VUuBEPr1gRCZuCosFTZUedqUlMxVe0gBAB9fdrdvdbmSmfPsrOyWC9eUABgbk47Ozd266Wo5CiSGOs2dmSnkSQ988TM/935H0kv7bUUl1VDqI3QSCDU0dH597//PXr06BkzZoSEhCxYsIBs5/v3339PnqwcMbF48eJhw4aNGzfO19d3wYIFvXvXM78bNRvV8TJvM1KmAUwglPOUgbAABKyiIpIWvqwRtjcpNzBQzn8YMEB9avyMGRIWC/T0lCfcvMlOSVE+w97ejZ1Hn12RfeTREQCggPo84PMNAzeQRQCkCuWI0wkeE6Z7T3+zr4cQarE0tej2zJkze/XqlZycPGPGjG7dupHMiIiIgIAAkl68ePGlS5fKysqWL1/eoUNjFy5BGtLBrOafoMlT6RvGBEIpW9lHqFojrChXxjZDfcWsWdJffuGNGSN1dFSv4U2eLB01Ssbl0k5OBhUVVF4e9fffymfYx6ex1cHolGgyUrSPfR93C3cAiBocFR4bTroGw13D1w9Yr7axBkKoFdPg7hPu7u7utbcUt7S0ZEaTmpmZDR06VHOfjt6IvZG9DltHLBeDxmqExjrGFFA00NVQBpQCaFYBCKiC2+RV4cuZFAYG9Pffi7/6SvyqXnl9fRoAfH0VCQlsAGBmEDayRvhC/OKPW3+Q9Ke+n5JEL7teS3osWZG4YoDTgD8/+JPDwl1ZEGpDcK1RBADApthBtkEAYM4397DweO35TcBhcQx5hgCgADnoloFaH6FQWQMzMAQAeO3YtK5dlWFPrJxbAX5+jaoRbrq5iaye42buNth5MJO/qPui0s9L9w7f28jlxRFCrQb+8kVK28K3HXt8rIdtDz5HUyOkTXVNSRACfgmITGs1jVYqf5MZGjWqTdLPr1b9z8SEtrd/fSAsl5T/dvM3kl7UfRGZOIgQauPwDwFSMtM1m+Q5ydXUVXMfwXQTMqusMetuC0XK32QGxo16JpkaIeHjo2hMp95vN34rE5cBQCezTiM6jWhksRFCrRsGQtR81AJhIViyHz6kKioAoEKsnJ+kb9qoVgo7O9rGpmZxbR+f13cQ3si7sf76epJeFIjVQYSQEv4tQM3HjG9GEjyjUgCoAr1KEYtz9CioBEJDC51GXs3Xtyb4vXakzJ3COyMOjBBKhQDQyawTM3cQIYQwEKLmw9QI9cyLSaIABJy9ewFAKFUOUTEwb+zSFardhA3MnaBpes+DPRH7IkqrSwHAgm+xY+iOt1wxACHUmuBgGdR8THRNSIJvVvwCAAAKwdIpPp7KzxfKlIFQz7yxNUJ/f2XwMzSknZzUA+Gaq2s2XN9gwDPgsXmPSx8rC6Bjcmjkoc7mnd/qayCEWhcMhKj5MDVCrlHNKmsgl3P37KlQhJEcQzMuQKNmBAYEyE1N6dJSKjRUrrYZSX5l/orEFVKFtKS6ZplBW0PbnRE7NTRLEiHUcmEgRM2HCYTMutsFIAAA7tatFTCG5DDrq72WoSEdH1919Sq77h6EO+/tZNZLAwAuizu369zFgYv1ufXsW4IQauMwEKLmozZqFAAKOTYgA1Z6egUoN6RsfCAEAEdHRd1l2BS0YtudbSS9os8KXyvfDmYdBHqCtyg4Qqg1w0CImo+JjrKPUM5TLjea394PMgEAmED46h2aG+v80/NZZVkAYKxjPM17mubWB0AItQ44ahQ1n5p1tzkvA6GlBwAogFUFegBAAc3sLNFkW29vJYnxHuMxCiKEXgsDIWo+TCAUwcumUd32QFFCMKCBAgB9djXr7R7JwqrC4+nHSXqK15S3uhZCqG3AQIiaDxMIhXJljfD6Xb2f2/2SBsptgQ251W/5EReeXSDDZLq3647TJBBCjYGBEDUfXY4uaauU0RLgCQGgpIT6OieyD8STEwx44obe3wjJ+ckkEdw++C0vhRBqIzAQombFrLL2ydwC3Zf7HZEOQgDQN3iR/iL9ba5/q+AWSXgLvN/mOgihtgMDIWpWTOvotHl56enCmTNrZvuBTvmD8f19//Rde21t0y5O03RKfgpJ+1r5vl1JEUJtBQZC1KyYGRSl1aWGhvS8eZKa12ySxfrPAeBQ2qGmXfxJ+ZMX4hcAYKZrZm9k/7ZlRQi1DRgIUbNimkbJEtiOjoqajSN0ysl/syuym3bxm3k3ScLHyudtCokQalMwEKJmpVojJIkPP3y5QBpPSP5bWFUokomacPGUAmwXRQi9MQyEqFkxfYRMIBwxggmEFeS/NNDPhc+bcHGmgxBrhAihxsNAiJpV3UBY0zrKq2ROe1b+jCQUtGLl5ZWD9gxyj3a3Xm+95uqaV12ZpmlmyCgGQoRQ42EgRM2KCYTFomImc8wYGUBN0yiodBPuS9238vLKyzmXsyuyq2RVq5JWKej69+B9WvGUBFdTXVN7QxwpgxBqLFx0GzUrSz1LkiiqKmIyP/1UwmJBHF167uUY0uxyZSBcf3296ttFMlGOMKe9Yfu6V07OU06l97HyoSjqXRccIdRqYY0QNSsLPQuSKBLVBEIuF+bOlbi4VTA5OcIcADj39NztgtsAoM/Vd7dwJy89KnlU75Vv5N0gCR8BtosihN4ABkLUrCz4LwOhSo2QEEpqmkZJH+Haq8qZ9ZM8J/lb+5P0o9L6A+GZJ2dIItA28N2VFyHU+mEgRM2KqREWVhWqvSSU1uojvFt49/zT8wDAptiz/Wa7mrqSl+qtEeZU5NwrvAcAOmyd3u17a6DgCKFWCwMhalbGPGMuiwsAQqmwWlZrr4lKaa1Ro7/f+p0GGgA+7Piho7FjRzPlDhX1BsLTWafJyT1se+hz9TVXfoRQ64OBEDUriqLq7SaE2k2jIpnoyKMjJD3NexoA1NQI62saPZV1iiQGOQ9610VGCLVyGAhRc2O6CVVnUEDtQAgvwySfww+wCQAAJxMnUpXMqchRW3dGqpCef3KepAc4DdBUuRFCrRQGQtTcGlMjZATZBvHYPADgsrhkHW0a6Melj1XPuZxzuVxSDgAORg4dTDtoqNgIodYKAyFqbua65iShNl5GtY+Q0cuuF5PuYKYMcmrdhKcysV0UIdR0GAhRc6t3Tj28IhCqbjTP1PbUugmZiRPYLooQagIMhKi51ds0KlVIxXKx2pl6HD0/az/mULVGeC332oVnFwCgtLr0ftF9AOCyuKpREyGEGgmXWEPNrd459fV2EAbaBpIBMgRTI/w7/e/Yh7E00NFh0cY6xmT10S6CLnocPQ2WGyHUSmEgRM2t3jn1TLsoh8WRKZQbM6nV8JgaIXPyrvu7mAXVetj20FiREUKtGQZC1NxqaoSiemqE9kb2T8qeyGk51AmEAj2BsY5xmbiMybn47GJ+ZT5JB9kGabTYCKHWCvsIUXOrd7AMU8kz0THxsvQCAIGeoO5G88z6MoRUISUdhBRQuMQoQqhpMBCi5lbvYJkKiXLrCQOewe5hu1eGrDwx9oRqByExwWMCi2K5mrrO8Jmhmt/BrANT0UQIoTeCTaOouZHlRqUKaYWkolpWrcvRBZUaoT5X39bQdq7f3HrfO7XL1KEdhpromKSVpEWnRDP52EGIEGoyDdYIMzMzjx49mpqa+qoT8vPzT548mZCQUF1d/apzUOtDUZQ5XzmnnllljekjNOAZNPx2C74Fh8Vxt3B3MXFhMrGDECHUZJoKhNu2bevWrdv27dtDQkJWrVpV94TY2Fh3d/dt27b98MMPHTt2zMrK0lBJ0Huobuto4wMhI8wljEn3sMMaIUKoiTQSCMVi8aJFi/bu3RsbG3v27Nlly5YVFxernfPjjz+uXLnyr7/+On36tL+//6ZNmzRREvR+qhkv8zIQqjaNNvIiQ1yGkISNgY2DkcM7LSBCqA3RSCC8ePGijo5O3759AcDNzc3Nze348eNq5+jp6XG5yqEQXC5XXx/3kGtDmOVGmYGjTCBsfI0wyDZogOMALou7sNvCd15ChFDboZHBMtnZ2e3bt2cO7e3ts7Oz1c757bffZs+effHixeLiYjabHRkZ+aqrlZeXX758WSxWrr/F5/MHDhxY9zSJRCKRSN5F8VEtmrixZrpmJJFbnksuXiZSzg7ks/iN/7jd4buZQr7bEjYDfGI1BG+sJkhe0nZBXu/UqVNVVVUknZycXF5e/tq3aCQQisViDqfmyjwejwljjAsXLohEIm9v7xcvXuzYsSM1NbVbt271Xq2kpCQpKYnpRDQyMgoMDGSx1OuylZWVQmE9y3Sht6SJG2vIMiSJ3PJccvEXohckh6PgtJF/R3xiNQRvrCZIJJLKykoej6ftgrwGTdOHDh1iHoC8vDyFQvHad2kkENrY2BQV1UwRKygoIM2kjOrq6kWLFiUlJfn6+gIAl8v97rvvTp48We/VHB0dR44cGRER0fCHSiQSMzOzty47UqeJG2tvbk8SlXQlubiUkpIcgYmgjfw74hOrIXhjNUEikfB4vBZxY6OjayZWHTt2bM+ePa99i0b6CAMCAjIzM3NycgCgqqrq6tWrPXv2VD2Bpmm5XM78uNDR0ZHJZJooCXo/1R012oQ+QoQQeic0Egitra0nTJgwZsyYmJiYUaNG9e3b19PTEwA2bdrk4+MDAHw+f9SoUVOmTNm1a9fGjRtXrlw5adIkTZQEvZ/qbkDRhFGjCCH0TmhqZZmoqKgtW7YkJCT069dv7lzlKiGBgYG6urokvWPHjpiYmMTERF1d3b1796q1naLWTaAvIIk7hXcelT7qYNqhCfMIEULondBUIORwOHPmzFHL9PX1JZ2CAMDlcqdOnTp16lQNFQC9z5yNnb0sve4U3hHJRFOPTT3z8RkmEGKNECHUzHDRbaQFFEVtCdtCVhm9XXh72cVl2EeIENIWDIRIOzwsPJb3Xk7Sm25uYjbpNeBiIEQINSsMhEhrZnrP9Lf2BwA5LRfLlTNNsWkUIdTMMBAiraEoSm2xbB6bx2O/7zN2EUKtDAZCpE1dBF1UD7FdFCHU/DAQIm3ysvRSPcR2UYRQ88NAiLSpo1lHPofPHOKQUYRQ88NAiLSJTbHdzN2YQwyECKHmh4EQaZlqNyEGQoRQ88NAiLTM09KTSWMfIUKo+WEgRFpWq0aIo0YRQs0OAyHSMi9LLxalfA6xaRQh1PwwECIt0+fqO5s4M2ntFgYh1AZhIETax8wmxECIEGp+GAiR9gXZBpGEq5mrdkuCEGqDNLUfIUKNN817Gg00j8Ub0XGEtsuCEGpzMBAi7eOyuLN9Z2u7FAihNgqbRhFCCLVprScQJiQkyGQybZeiFTp37py2i9AKyWSyhIQEbZeiFaqsrLxy5Yq2S9EKFRQU3L59W9ul0JTWEwi/++673NxcbZeiFZo1a5a2i9AK5ebmfvfdd9ouRSt069atdevWabsUrVBCQsLWrVu1XQpNaT2BECGEkIbQNK3tImgQBkKEEEJtGgZChBBCbRr1/ld4fX195XK5hYVFw6ddvnzZz89PR0eneUrVdpw/fz4kJETbpWhtxGLxzZs3g4KCtF2Q1qasrCw9Pd3Pz0/bBWlt8vLyiouLPTw8tF2QN1NUVMRisVJSUho+rQUEwnPnzlVVVb02wmVlZTk4OFAU1TylajsyMzOdnJy0XYrWhqbpJ0+eODo6arsgrY1MJsvNzW3fvr22C9LaVFVVVVRUWFlZabsgb0YsFuvp6fXt27fh01pAIEQIIYQ0B/sIEUIItWkYCBFCCLVpGAgRQgi1aRgIEUIItWmtZPeJ+/fvX7lyxcXFpXfv3touS8uWlJQkFApJ2sTExN/fn6SlUmlcXFxxcXH//v1tbW21V8AWJjs7Oy0tzd3d3dramsmsrq4+efJkZWXlgAEDBAIBk5+ampqYmOjo6BgSEoLjnxuWkZGRkZHh7+9vYmJCcjIzM9PT05kTgoODmaHmycnJKSkpbm5ugYGBWihry5GXl3f58mWRSBQQENChQwcmv6qq6p9//hGJRAMHDlSdyfbgwYOkpCRnZ+fevXu37CeWbvm2bdsmEAhmzZrVuXPnWbNmabs4LZuXl1fXrl1DQ0NDQ0M/++wzkimRSIKDg4OCgqZOnWpmZpaYmKjdQrYU3t7ehoaGurq6u3btYjKFQqG3t3e/fv0mTpxoYWFx7949kr9nzx4LC4uZM2d6eHhMnDhRS0VuARQKhZmZmampKYfDuXjxIpP/ww8/2NnZhb5UVFRE8v/73/+2a9fu008/dXJyWrJkiZZK3QKcO3fOxMQkIiJiwoQJxsbGa9asIfllZWUeHh4DBgwYP368QCBITU0l+Tt37rS0tJw1a5a7u/snn3yivYK/Ay0+EEqlUltb25MnT9I0XVBQYGBgkJaWpu1CtWBeXl7nz59Xy9y3b5+bm5tYLKZpetWqVQMGDNBG0VqejIwMuVzu6+urGgh/++23Hj16yOVymqYXLVo0fvx4mqblcrmLi8v+/ftpmi4pKTExMUlJSdFWsd9/jx8/pmna3NxcLRDOnTtX7cyKigpjY+Pr16/TNJ2RkcHn8/Pz85uzqC1IQUFBWVkZSf/zzz+6uroSiYSm6XXr1vXp00ehUNA0HRkZOWXKFJqmZTKZg4PD0aNHaZouKioyMjJiftK1RC2+jzA5OVkoFIaGhgKApaVlcHDw33//re1CtWz37t2Li4t7/vw5k3Ps2LGIiAgejwcAo0aNOn36dHV1tfYK2GI4OTmxWOr/ix07dmzEiBEkf9SoUceOHQOABw8e5OTkhIeHA4CpqWn//v1JPqqXi4tLvfmFhYUnTpy4c+cO/XJ69IULF0xNTbt27QoATk5Onp6e//zzT/MVtEWxtLQ0MjIiaRsbG7lcLpfLAeDYsWMjR44kLZ/ME3vnzp2ioqLBgwcDgLm5eUhISIv+w9viA2FOTo6NjQ2bzSaHtra2OTk52i1Si2ZoaHjo0KHVq1d37Nhx5cqVJDMnJ4fpF7S1taVpWjVMojeidjPLysqEQuHz588FAgH5qQH4GDcJi8XKysratGnToEGD+vbtS7q6c3Jy7OzsmHPwxjbS8uXLJ0yYoKurC3We2OLi4urq6pycHGtraw6Hw+S36Bvb4gfLyOVy1U5aNpuN2/O+jYSEBPKrIiUlJTAwMCIiwsPDQy6XMzUbFotFURTe5CZTvZnkVstksrqPsUgk0k75Wqyvv/56yZIlACASifr06bN69eqlS5eq3VgOh4OP7mstXbo0NTU1Pj6eHKo9sTRNk8pia/rD2+JrhDY2NoWFhcxhfn6+jY2NFsvT0jF1ax8fn06dOpHFam1sbAoKCkh+QUEBTdPt2rXTWhFbONWbmZ+fr6enZ2JiYmNjU1RUpFAomHx8jN8U8+jy+fzhw4cnJydD7bsNAHl5efjoNuynn37as2dPXFwcMxxX7Yk1NjbW19cnf3iZJuiW/sS2+EDo4+Mjk8lu3LgBANXV1QkJCa9dXxU1RklJSVZWlr29PQCEhITExcWR/Li4OH9/fwMDA62WrgULCQlhuqmLKhBaAAARRklEQVTi4uLIzh5ubm4GBgaXLl0CAIlEcv78eXyM38bNmzfJoxsUFPTkyZOsrCwAKC0tvXHjRp8+fbRcuPfY2rVr//zzzzNnzqgurl3vE+vl5cXhcK5cuQIAYrE4Pj6+RT+xrWHR7eXLl8fExMyePfv48eMsFuvkyZPaLlFLdfv27X/961+BgYEURcXExLi6uh49epSiqMrKSm9v7x49enh5ea1atSo6Onr48OHaLmwLsH79+nv37h04cMDb29vFxWXhwoWdOnUqLCzs0qXLiBEjbG1tV61adfTo0eDgYABYs2bNr7/+On/+/NOnT1dUVMTHx7fsiVmatHTp0tzc3O3btw8cONDa2nr58uUCgWDYsGHu7u6mpqaXLl1KTEy8evUq2TUlMjIyISFhypQpe/fudXJyiomJ0Xbx31Nnz54NDQ0NCwtjelXJjc3NzfXx8Rk7dqxAIFi9evWJEyfI9mE//fTTH3/8MWfOnH/++UcqlZ45c0arxX8rrSEQAsDhw4eTkpKcnJwmT56MWxI2WVVV1cGDB1NTU1kslq+v79ChQ5m+geLi4m3btpWWlg4ZMgR30WukEydOPHv2jDkMDw8n7XLPnz/fvn27SCT68MMPfXx8mBOOHz9+8eJFOzu7qVOn8vl8LZS4hYiNjS0tLWUOx40bZ2RkdP78+cTERKFQaG9vP3bsWFNTU/IqTdN79+5NTk52c3MbP348M74DqUlPT1cLZmPHjjU2NgaA7OzsHTt2VFdXjxw5skuXLswJR48eTUxMdHBwmDJlChlZ00K1kkCIEEIINU2L7yNECCGE3gYGQoQQQm0aBkKEEEJtGgZChBBCbRoGQoQQQm0aBkKEEEJtGgZC1IY8ePBgy5YtEomEHO7Zs4esSdTGFRcXb9myJTs7WxMXVygU+/fvz8vLU82kabqysrKBd0mlUmaD6LokEolYLH7TkqSlpeHWE6heGAjRe6SwsND51by8vN7y+vHx8bNmzWLWs54zZ86ePXveutT1+O2331xe8vT07NOnz4IFCxISEjTxWQDw/PlzZ2fnX3/9tWlvf/bs2axZs+7du/duS0Vs3bp1/vz5ZH8fmUy2cuXKgIAAPp9vYGAgEAgiIyNLSkpUzy8sLBw9erSenp6hoaGrq+vBgweZl7Kzsz///HNXV1c+n6+np+fi4rJx40ayVRARHR3tUhvZoI3Q0dEZNmxYYmKiJr4matFwkQX0HuHz+Z988glzuHr1agsLiylTppBDZpeid2XJkiWqC7u8Q6WlpRkZGYsXLzY1NaVp+unTpydOnNiwYUNERMTu3bv19PTe7cdJpdLMzEzVxVbeE9XV1d9+++2iRYvIV66urv7+++9HjRo1ffp0a2vrhISE9evXJyYmJiUlkSWzFQpFREREenr6//73P3t7+7Vr144ePfrMmTNkgdDr16/v2LFj4sSJfn5+urq6MTEx8+fPf/LkyX/+8x/ycS9evMjIyFixYgWzIpKZmRlTGAcHh3Hjxi1ZsuTcuXPNfSPQe05LGwIj9Hr29vb9+/evm19dXZ2bmyuTyZicwsLC6urqei+iUCjy8vKqqqpomt60aRMAvHjxouHPLSoqEovFr3qJ2cW7AT/++CMAZGZmMjlyuZzs70g2+FYlFApLS0tfe80GkEWlly9fXvclsntcve8qLi4mt4Js1HDy5Em1EwoLC4uKit6mYDt27OBwOHl5eeRQKpVmZ2ernvDNN98AQEJCAjk8cOAAAMTExJBDsVhsb28fHBxMDgsKCiorK5n3yuXywMBAPT09spE6TdOrVq0CAKlU+qrynD9/HgCSk5Pf5kuh1gebRlHLIJfLzczM1qxZM2/ePLJvUXJyckFBwfDhww0NDS0tLfX09Nzc3FRb0gDg3LlzHTp0sLa2NjIymjhxYlVVleqrHh4eJGIBwMaNG83MzJKTk7t27WphYaGvrx8WFqZax7p//363bt0sLCyMjY379u175MgRMzOzxrd2slisr7/+esiQITt27GB64yIjI9u1a2dgYGBqamptbb1s2TKyE5NCofDx8Zk6darqFbKzsy0sLKKiol77WZs3bzYzM7tx40ZAQIC5ubmBgcGgQYOKi4uZEzIyMnr16mVubm5iYtKnT58nT56oXWH79u3Ozs6WlpYWFhadOnViFrL/888/zczMVPcij4yMtLW1ffToUb0l2b59e3BwMLOVAYfDYbZ4Jfz8/ACgrKyMHJ44cUJHRyciIoIc8ni84cOHX7p0iTSfkn9l1Vvq6+tbXV3NdPq+Vu/evS0tLXHdbaQGAyFqMUpLS1etWpWZmXnw4MEzZ860b99eKBRaWVnFxsbev38/Pj6+U6dOY8aMuX37Njn/8ePH4eHhFhYWCQkJSUlJUqmU1MkYeXl55eXlJF1dXV1aWvrRRx9Nnz79+vXra9euPXv27PLly8mrFRUVgwcPLioqOnbs2N27d/v16zdjxozS0lKpVPpGX2Hs2LFyuZwJn0Kh8JdffklJSbl58+aMGTOWLVv222+/AQCLxRo9evSuXbtU99r8/fffKyoqRo4c+dpPId/l448/njx58rVr19avXx8fH79s2TLm1bCwMHIb79y5ExISMmPGDNW3b968ecqUKcOGDbt69erVq1f9/PwiIiLIqKKpU6eGhIRMmjSJxM59+/atX7/++++/79ChQ91iSCSSxMTEhpdoP3PmDJvN9vX1JYdPnz51cHAwNDRkTvDy8lIoFA8ePKj7Xrlcfv78eXd3d319fdX8IUOG+Pn5jRw5csOGDWr/QBRFde/eHZtGkTptV0kReiXVplGy/7Wrq2sDDV8SicTGxmbJkiXkcN68eXw+Pz8/nxzK5fKOHTuCStOomZnZokWLSJr0M23bto252vjx4x0dHUl68+bNAHD58mXmVVJdO336dL0lqds0SpAdB3/++ed63zVmzJigoCCSzs3N5fF4q1evZgrv4ODw8ccf1/tGtabRtWvXAsDvv//OnDB58mQ7OzuS3rFjBwDExcWpflN42TQqEonMzMwmT57MvCqTyci+DeSwtLTU0dExODg4PT3dzMxs9OjR9RaJpmky+kb1lqqJj49ns9kLFy5kcjw9PZk7QJDG0iNHjtR9+/fffw8Ahw8fZnJWr14dFBQ0b968yMjIgIAAAOjbt69aK/eXX37J4XDkcvmrSoXaIBwsg1qSoUOHqm2jU15e/tdffz1+/Jg0r9E0nZ6eTl5KSUnp1auXQCAghywW68MPP/z5558buH5YWBiTdnd337t3L03TFEXdvn1bIBAEBgaqlmTr1q1vWn4yiIPZiV4ulx8+fPjWrVtkdkF6ejqzbZO1tfXw4cOjo6MXLlxIUdTx48efPHmyffv2xn+W6nfx8PCIiYmRy+VsNjslJcXIyGjAgAHMqyNHjty5cydJX79+vaSkxMHB4fTp08wJjo6Od+/eJWkTE5Pdu3f37t3b19dXIBD8/vvvrypAUVER1B6uourBgwejR4/29/dnqt3kzjDjXAhmEI3a23fv3v3jjz9GRkYy7agA8Nlnn33xxRckTdP0//3f/61YsWL79u3Tp09nzjE3N5fJZKWlpebm5q8qOWprsGkUtSSqG2cDQHJyspOT048//lhYWGhoaGhqasrlcpkOp+zsbGtra9XzbWxsGr4+s4kdAPB4PKlUSv4E5+XlWVhYqJ5paWnZhPI/ffoUAEipKioq/P39p06d+uDBA11dXVNTUz6fzxQeAGbPnp2amhofHw8AW7Zs6dy5M9nCt5HUvotcLie16pycHLXbSHZJJPLz8wFg7dq1Y1QkJSWpdq927949ICCgvLz8iy++IPMi6kV+spAPVfP48ePQ0FAbG5sTJ06odvvZ2NiozaYgXZsmJiaqmQcPHpw0adKkSZN++eUX1XwSNQmKor799lsul6u2xx5pLOVyua8qNmqDsEaIWhK1Tdv/+9//mpqa3r59m/ljevjwYeZVKysrUilhqHa5vRE7Ozu1jqXc3NwmXOfIkSMA0LNnTwDYt29fSkrKvXv33N3dyavz5s27du0ac3JISIinp2d0dLSrq+vx48dXr179Tvasr3tbCgoKmDTZiHXHjh2qNS01GzduvHz5sqen59KlS4cPH672a0P1g+BlJFOVlZXVv39/U1PTU6dOqUZrALC1tU1KShKLxcz22mQYDmnTJo4dOzZu3Lhx48ZFR0c3fEN0dHT09PTUZu4XFRXx+fwG4jdqg7BGiFqwzMxMNzc3JgqmpaU9fvyYedXT0zMxMZEZDgMAzOjHN9W1a9eSkpJTp04xOU2Yib93797du3cPHTqUDC3JzMzU19d3c3Mjr0ql0ri4OLW3zJw5c9++fT///DOHw5kwYULTCq/G09OztLT06tWrTI7qbQkICNDT04uNjX3V22/fvv3VV199/vnnZ8+e5XA4H330keqUdlXOzs7m5uZ37txRzXz27Fn//v11dXVPnTpVt1bdr1+/yspKpg5H0/Thw4e7dOnCVOXj4uJGjx5N2qVV63/1unDhQllZGfM7gyl/t27dGn4jamswEKIWzMfH5+zZs6dPnxaLxdevXx8zZoyuri7z6ty5cysrKydNmvT06dOioqKvvvqq3sGHjTFmzBh3d/ePP/54y5YtcXFxM2fOVK26vcrx48djY2NjY2PXrFkzaNCgcePG+fj4/Pnnn0zhKysrf/75Z5FI9OTJk8mTJ9etZU6cOJHL5f7666+jR49Wa5ttsjFjxtjY2HzyyScpKSlCoXDr1q27d+9mXjU2Nv7Xv/4VExOzaNGijIwMkUj06NGjzZs3k2kbQqFwzJgxnp6eK1eutLS03LVr14ULF1asWFHvB1EU1a9fP9WVXCoqKvr27fvs2bM5c+ZcvHgx9iWmW3fs2LHOzs6fffbZzZs3CwoKFi9efP/+fTLXEACuXr06fPhwCwuLESNGHDx4kHl7RUUF89X27t1769ate/fubdmyZcyYMUZGRp9++ilTALFYfOPGDdXlZhACwFGj6D1Wd9So2njLwsJCZnS+jo7OypUrQ0JCwsLCmBN27drFNIL16tWLjMtoYNQoMzWbyWGm7WdnZ48YMYIs/TV+/Pj9+/cDQEpKSr0lZ6YnkoLZ2dkNGTJk69atqtdXKBQzZ84kjXsURY0aNeqbb77R0dFRuxRZaoeZcl6vekeNkjUEVHOYmfXXrl1zdHQkxXN0dCSjfpgJ9QqF4j//+Y9qo6WdnR0Z/Dl+/HhjY+P09HTmykuXLmWxWGfOnKm3YKSumZqaSg4zMjLq/Sv066+/Mm958OBBly5dSD6fz1+1ahXzUnR0dL1vf/jwITlBbZ2grl27XrlyRbU8+/fvZ7PZWVlZDdxM1AZRNE03LmIi1NzIQBW1YYRqaJrOzMwsKSnp1KmT6vwzRlVV1b1790xNTV1dXeten6KopnW8/fLLLwsXLiwrK3vL3qb8/PynT5/a2dm9aiDPkCFDsrKyXrsQqFwuZ7FYjf8ucrn89u3bHA7H3d293jZGmUz24MEDkUjUrl07W1vbpt0lsjJAWFhYw4N160pNTa2oqHjVv2kDiouLc3Jy5HK5s7Mz6e9U9cEHH5iYmOzateuNrolaPQyECDXKpUuX3N3dST3p6tWrERERXl5eqr2GmnD16tXAwMDo6Ohp06Zp9IM05+zZsxERERkZGcw8Fm25ceNGz54979275+Liot2SoPcNBkKEGmXq1Kk7d+60t7cXiUTPnz/39PQ8evQo08D4zl27dm3atGlpaWm+vr7x8fHvfMHx5pSVlWVpaam2/kvzKy0traqqUlvjDSHAQIhQI8lksuvXr2dkZEgkEldX16CgoNeOWnwbz58/P3bsmEAgCAsLY+YSIIQ0AQMhQgihNg2nTyCEEGrTMBAihBBq0zAQIoQQatP+Hz51drfBF4JQAAAAAElFTkSuQmCC" />



### Next Steps
This is a single allocation event, namely at the start of the out-of-sample period. In practice, we would want to rebalance the portfolio periodically (e.g., monthly, quarterly, etc.) based on updated market data and asset performance, or following some trigger events. __This is the essence of our 2025 trade bot!__
___

## Summary
This example demonstrates how online stochastic bandit algorithms can be effectively applied to solve the combined asset selection and weight allocation problems in portfolio management through the integration of epsilon-greedy exploration with utility maximization.

> __Key Takeaways:__
> 
> * __Bandit Algorithms for Portfolio Selection:__ Multi-armed bandit algorithms like epsilon-greedy enable adaptive asset selection by balancing exploration of uncertain portfolios with exploitation of known high-utility combinations, avoiding the need to exhaustively evaluate all possible subsets.
> * __Utility Maximization for Weight Allocation:__ Once a portfolio subset is selected, Cobb-Douglas utility functions provide a principled approach to weight allocation that reflects investor preferences and risk tolerance, with the preference parameters `γ::Array{Float64,1}` distinguishing between preferred and non-preferred assets.
> * __Integration of Selection and Allocation:__ The combination of bandit algorithms for asset selection with Cobb-Douglas utility maximization for weight allocation provides a theoretically sound and computationally efficient framework for simultaneously addressing both problems in portfolio optimization.

By combining these techniques, investors can manage both the complexity of asset selection and the precision of weight allocation in a computationally efficient and theoretically sound framework.
___

## Disclaimer and Risks
__This content is offered solely for training and informational purposes__. No offer or solicitation to buy or sell securities or derivative products or any investment or trading advice or strategy is made, given, or endorsed by the teaching team. 

__Trading involves risk__. Carefully review your financial situation before investing in securities, futures contracts, options, or commodity interests. Past performance, whether actual or indicated by historical tests of strategies, is no guarantee of future performance or success. Trading is generally inappropriate for someone with limited resources, limited investment or trading experience, or low risk tolerance. Only risk capital that is not required for living expenses should be used.

__You are fully responsible for any investment or trading decisions you make__. Such decisions should be based solely on your financial circumstances, investment or trading objectives, risk tolerance, and liquidity needs.
